import HeroBanner from "@/components/home/hero-banner";
import AboutSection from "@/components/home/about-section";
import ExchangeProgram from "@/components/home/exchange-program";
import FeaturesSection from "@/components/home/features-section";
import VirtualLibrary from "@/components/home/virtual-library";
import TestimonialsSection from "@/components/home/testimonials-section";
import ContactSection from "@/components/home/contact-section";
import CTASection from "@/components/home/cta-section";
import { Helmet } from "react-helmet";

const Home = () => {
  return (
    <>
      <Helmet>
        <title>Fenda da Tundavala - Instituição de Intercâmbio Angola-China</title>
        <meta name="description" content="Uma instituição de ensino de excelência dedicada ao intercâmbio cultural entre Angola e China, formando líderes globais para o futuro." />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet" />
      </Helmet>
      <HeroBanner />
      <AboutSection />
      <ExchangeProgram />
      <FeaturesSection />
      <VirtualLibrary />
      <TestimonialsSection />
      <ContactSection />
      <CTASection />
    </>
  );
};

export default Home;
