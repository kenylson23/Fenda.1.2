import { Link } from "wouter";
import { Helmet } from "react-helmet";
import { useQuery } from "@tanstack/react-query";

const Exchange = () => {
  const { data: universities } = useQuery({
    queryKey: ['/api/universities'],
    staleTime: Infinity,
  });

  return (
    <>
      <Helmet>
        <title>Programa de Intercâmbio - Fenda da Tundavala</title>
        <meta name="description" content="Conheça o programa de intercâmbio Angola-China da Fenda da Tundavala, oferecendo experiências educacionais únicas." />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
      </Helmet>

      {/* Hero Section */}
      <div 
        className="relative py-32 bg-center bg-cover"
        style={{ 
          backgroundImage: "linear-gradient(rgba(26, 82, 118, 0.85), rgba(41, 128, 185, 0.85)), url('https://pixabay.com/get/gb225f71277549b658fafd9f5c5cc357e130468d8e4e4b66f37f1475736000ffecac845861959e3212f272f6686b0ebf19212056aa386c4f1079285c1ca3f9104_1280.jpg')" 
        }}
      >
        <div className="container mx-auto px-4 text-center text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Programa de Intercâmbio Angola-China</h1>
          <p className="text-xl max-w-2xl mx-auto mb-8">
            Uma ponte entre culturas, abrindo horizontes para um futuro global
          </p>
          <Link 
            href="/exchange/apply"
            className="inline-block bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-6 py-3 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition"
          >
            Candidate-se Agora
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2">
            <h2 className="text-3xl font-bold text-[hsl(var(--primary))] mb-6">Sobre o Programa</h2>
            <p className="mb-4">
              O Programa de Intercâmbio Angola-China da Fenda da Tundavala foi estabelecido para fortalecer os laços educacionais, culturais e econômicos entre os dois países, oferecendo uma experiência de aprendizado transformadora para os estudantes.
            </p>
            <p className="mb-4">
              Através de parcerias com renomadas instituições de ensino chinesas, proporcionamos uma imersão completa nas diversas facetas da cultura e do sistema educacional chinês, permitindo que nossos alunos desenvolvam habilidades linguísticas, acadêmicas e interculturais valiosas.
            </p>
            <p className="mb-8">
              Da mesma forma, recebemos estudantes chineses interessados em conhecer Angola, sua cultura, idioma e oportunidades, em um intercâmbio que enriquece ambas as comunidades acadêmicas.
            </p>

            <h2 className="text-3xl font-bold text-[hsl(var(--primary))] mb-6">Modalidades de Intercâmbio</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-white shadow-md rounded-lg overflow-hidden">
                <div className="h-40 bg-[hsl(var(--primary))] flex items-center justify-center">
                  <i className="fas fa-university text-white text-5xl"></i>
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-3">Graduação Internacional</h3>
                  <p className="mb-3">
                    Curse sua graduação completa em uma universidade parceira na China, com acompanhamento contínuo da nossa equipe.
                  </p>
                  <ul className="space-y-1 text-sm mb-4">
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Duração: 3-4 anos</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Curso preparatório de mandarim</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Diploma reconhecido internacionalmente</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="bg-white shadow-md rounded-lg overflow-hidden">
                <div className="h-40 bg-[hsl(var(--primary))] flex items-center justify-center">
                  <i className="fas fa-exchange-alt text-white text-5xl"></i>
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-3">Intercâmbio Semestral</h3>
                  <p className="mb-3">
                    Estude por um semestre em uma universidade chinesa enquanto mantém seu vínculo com a instituição em Angola.
                  </p>
                  <ul className="space-y-1 text-sm mb-4">
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Duração: 6 meses</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Imersão cultural intensa</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Aproveitamento de créditos acadêmicos</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="bg-white shadow-md rounded-lg overflow-hidden">
                <div className="h-40 bg-[hsl(var(--primary))] flex items-center justify-center">
                  <i className="fas fa-language text-white text-5xl"></i>
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-3">Curso Intensivo de Mandarim</h3>
                  <p className="mb-3">
                    Desenvolva fluência no idioma mandarim com professores nativos em um ambiente de imersão cultural.
                  </p>
                  <ul className="space-y-1 text-sm mb-4">
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Duração: 1-12 meses</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Vários níveis disponíveis</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Certificado HSK (padrão internacional)</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="bg-white shadow-md rounded-lg overflow-hidden">
                <div className="h-40 bg-[hsl(var(--primary))] flex items-center justify-center">
                  <i className="fas fa-briefcase text-white text-5xl"></i>
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-3">Estágio Profissional</h3>
                  <p className="mb-3">
                    Adquira experiência prática em empresas chinesas ou chinesas com operação em Angola.
                  </p>
                  <ul className="space-y-1 text-sm mb-4">
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Duração: 2-6 meses</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Mentoria profissional</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-[hsl(var(--secondary))] mt-1 mr-2"></i>
                      <span>Oportunidades em diversos setores</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-[hsl(var(--primary))] mb-6">Depoimentos de Alunos</h2>
            <div className="bg-white shadow-md rounded-lg p-6 mb-8">
              <div className="flex items-start mb-4">
                <img 
                  src="https://randomuser.me/api/portraits/men/32.jpg" 
                  alt="João Carlos" 
                  className="w-16 h-16 rounded-full mr-4 object-cover"
                />
                <div>
                  <h3 className="font-semibold text-lg">João Carlos</h3>
                  <p className="text-sm text-gray-600 mb-2">Estudante de Engenharia Civil - Intercâmbio 2022</p>
                  <p className="italic">
                    "Minha experiência na Universidade de Pequim foi transformadora. Além do conhecimento técnico adquirido, o aprendizado cultural e linguístico abriu portas que eu jamais imaginaria. Hoje trabalho em uma multinacional chinesa em Angola, utilizando diariamente os conhecimentos adquiridos."
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <img 
                  src="https://randomuser.me/api/portraits/women/44.jpg" 
                  alt="Maria Fernanda" 
                  className="w-16 h-16 rounded-full mr-4 object-cover"
                />
                <div>
                  <h3 className="font-semibold text-lg">Maria Fernanda</h3>
                  <p className="text-sm text-gray-600 mb-2">Estudante de Comércio Internacional - Intercâmbio 2021</p>
                  <p className="italic">
                    "O curso intensivo de mandarim mudou minha perspectiva profissional. Em apenas 6 meses, consegui desenvolver habilidades linguísticas suficientes para me comunicar no ambiente de negócios. O apoio da Fenda da Tundavala foi fundamental durante todo o processo."
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-[hsl(var(--secondary-yellow))] rounded-lg p-6 mb-8">
              <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-4">Processo de Inscrição</h3>
              <ol className="space-y-3">
                <li className="flex">
                  <span className="flex-shrink-0 w-7 h-7 bg-[hsl(var(--primary))] text-white rounded-full flex items-center justify-center mr-3">1</span>
                  <div>
                    <p className="font-medium">Preencha o formulário online</p>
                    <p className="text-sm text-gray-700">Complete todos os campos obrigatórios com suas informações pessoais e acadêmicas.</p>
                  </div>
                </li>
                <li className="flex">
                  <span className="flex-shrink-0 w-7 h-7 bg-[hsl(var(--primary))] text-white rounded-full flex items-center justify-center mr-3">2</span>
                  <div>
                    <p className="font-medium">Envie os documentos necessários</p>
                    <p className="text-sm text-gray-700">Histórico acadêmico, carta de motivação, cópia do passaporte e outros documentos requeridos.</p>
                  </div>
                </li>
                <li className="flex">
                  <span className="flex-shrink-0 w-7 h-7 bg-[hsl(var(--primary))] text-white rounded-full flex items-center justify-center mr-3">3</span>
                  <div>
                    <p className="font-medium">Entrevista pessoal</p>
                    <p className="text-sm text-gray-700">Participe de uma entrevista para avaliar sua motivação e adequação ao programa.</p>
                  </div>
                </li>
                <li className="flex">
                  <span className="flex-shrink-0 w-7 h-7 bg-[hsl(var(--primary))] text-white rounded-full flex items-center justify-center mr-3">4</span>
                  <div>
                    <p className="font-medium">Receba a carta de aceitação</p>
                    <p className="text-sm text-gray-700">Após aprovação, receba todos os documentos necessários para o visto e a viagem.</p>
                  </div>
                </li>
              </ol>
              <div className="mt-6">
                <Link 
                  href="/exchange/apply"
                  className="block text-center bg-[hsl(var(--primary))] text-white py-2 px-4 rounded-lg font-medium hover:bg-[hsl(var(--secondary-blue))] transition"
                >
                  Iniciar Candidatura
                </Link>
              </div>
            </div>

            <div className="bg-white shadow-md rounded-lg p-6 mb-8">
              <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-4">Bolsas de Estudo</h3>
              <p className="mb-4">
                Oferecemos diversas opções de bolsas para alunos talentosos que desejam participar do programa de intercâmbio:
              </p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <i className="fas fa-medal text-[hsl(var(--secondary))] mt-1 mr-3"></i>
                  <div>
                    <p className="font-medium">Bolsa de Mérito Acadêmico</p>
                    <p className="text-sm text-gray-600">Para estudantes com excelente desempenho acadêmico.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-medal text-[hsl(var(--secondary))] mt-1 mr-3"></i>
                  <div>
                    <p className="font-medium">Bolsa Governo Chinês</p>
                    <p className="text-sm text-gray-600">Financiada pelo governo chinês para estudantes estrangeiros.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-medal text-[hsl(var(--secondary))] mt-1 mr-3"></i>
                  <div>
                    <p className="font-medium">Bolsa Parcial</p>
                    <p className="text-sm text-gray-600">Cobre parte dos custos do programa para mais estudantes.</p>
                  </div>
                </li>
              </ul>
              <Link 
                href="/exchange/scholarships" 
                className="text-[hsl(var(--primary))] hover:text-[hsl(var(--secondary-blue))] font-medium mt-4 inline-block"
              >
                Mais informações sobre bolsas
              </Link>
            </div>

            <div className="bg-white shadow-md rounded-lg p-6">
              <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-4">Universidades Parceiras</h3>
              <p className="mb-4">
                Firmamos parcerias com algumas das melhores universidades chinesas:
              </p>
              <ul className="space-y-2">
                {universities ? (
                  universities.slice(0, 5).map((university: any) => (
                    <li key={university.id} className="flex items-center">
                      <i className="fas fa-university text-[hsl(var(--secondary))] mr-2"></i>
                      <span>{university.name}</span>
                    </li>
                  ))
                ) : (
                  <li className="text-gray-500">Carregando universidades parceiras...</li>
                )}
              </ul>
              <Link 
                href="/exchange/partners" 
                className="text-[hsl(var(--primary))] hover:text-[hsl(var(--secondary-blue))] font-medium mt-4 inline-block"
              >
                Ver todas as universidades parceiras
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-[hsl(var(--primary))] text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Pronto para vivenciar esta experiência única?</h2>
          <p className="max-w-2xl mx-auto mb-8">
            Não perca a oportunidade de expandir seus horizontes culturais e acadêmicos através do nosso programa de intercâmbio Angola-China.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link 
              href="/exchange/apply"
              className="bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-6 py-3 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition"
            >
              Candidatar-se Agora
            </Link>
            <Link 
              href="/contact"
              className="border border-white px-6 py-3 rounded-lg font-medium hover:bg-white hover:text-[hsl(var(--primary))] transition"
            >
              Fale com um Consultor
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default Exchange;
