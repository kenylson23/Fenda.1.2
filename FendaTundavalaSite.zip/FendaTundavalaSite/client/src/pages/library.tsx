import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Resource } from "@/lib/types";
import { Link } from "wouter";

const RESOURCE_TYPES = ["Todos os tipos", "Livro", "Artigo", "Vídeo", "Material"];
const CATEGORIES = ["Todas as categorias", "História", "Cultura", "Ciências", "Matemática", "Literatura", "Tecnologia"];
const LANGUAGES = ["Todos os idiomas", "Português", "Mandarim", "Inglês", "Bilíngue"];

const Library = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState(RESOURCE_TYPES[0]);
  const [categoryFilter, setCategoryFilter] = useState(CATEGORIES[0]);
  const [languageFilter, setLanguageFilter] = useState(LANGUAGES[0]);
  const [currentPage, setCurrentPage] = useState(1);

  const { data: resources, isLoading, error } = useQuery<Resource[]>({
    queryKey: ['/api/resources', searchTerm, typeFilter, categoryFilter, languageFilter, currentPage],
  });

  const renderResourceIcon = (type: string) => {
    switch (type) {
      case 'Livro':
        return <i className="fas fa-book text-4xl text-[hsl(var(--secondary))]"></i>;
      case 'Artigo':
        return <i className="fas fa-newspaper text-4xl text-[hsl(var(--secondary))]"></i>;
      case 'Vídeo':
        return <i className="fas fa-video text-4xl text-[hsl(var(--secondary))]"></i>;
      default:
        return <i className="fas fa-file-alt text-4xl text-[hsl(var(--secondary))]"></i>;
    }
  };

  return (
    <>
      <Helmet>
        <title>Biblioteca Virtual - Fenda da Tundavala</title>
        <meta name="description" content="Acesse nossa biblioteca virtual com milhares de recursos em português e mandarim sobre diversos temas acadêmicos." />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
      </Helmet>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[hsl(var(--primary))] to-[hsl(var(--secondary-blue))] text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Biblioteca Virtual</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Acesse milhares de recursos educacionais em português e mandarim para enriquecer seu conhecimento
          </p>
        </div>
      </div>

      {/* Search and Filter Section */}
      <div className="container mx-auto px-4 py-10">
        <div className="bg-white p-6 rounded-lg shadow-md mb-10">
          <h2 className="text-2xl font-bold text-[hsl(var(--primary))] mb-6">Encontre Recursos</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="col-span-1 md:col-span-2">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Pesquisar por título, autor ou assunto..." 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))] focus:ring-opacity-30 focus:outline-none" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <button className="absolute right-3 top-3 text-gray-400 hover:text-[hsl(var(--primary))]">
                  <i className="fas fa-search"></i>
                </button>
              </div>
            </div>
            
            <div>
              <select 
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:outline-none"
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
              >
                {RESOURCE_TYPES.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
            
            <div>
              <select 
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:outline-none"
                value={languageFilter}
                onChange={(e) => setLanguageFilter(e.target.value)}
              >
                {LANGUAGES.map((language) => (
                  <option key={language} value={language}>{language}</option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Categorias:</h3>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((category) => (
                <span 
                  key={category}
                  onClick={() => setCategoryFilter(category)}
                  className={`inline-block px-3 py-1 rounded-full text-sm font-medium cursor-pointer 
                    ${categoryFilter === category 
                      ? 'bg-[hsl(var(--primary))] text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                >
                  {category}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Resources Grid */}
        <h2 className="text-2xl font-bold text-[hsl(var(--primary))] mb-6">Recursos Disponíveis</h2>
        
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array(8).fill(0).map((_, index) => (
              <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md animate-pulse">
                <div className="h-40 bg-gray-200"></div>
                <div className="p-4">
                  <div className="h-5 w-16 bg-gray-200 rounded-full mb-2"></div>
                  <div className="h-6 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 w-24 bg-gray-200 rounded mb-3"></div>
                  <div className="flex justify-between items-center">
                    <div className="h-4 w-20 bg-gray-200 rounded"></div>
                    <div className="h-6 w-6 rounded-full bg-gray-200"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-10">
            <p className="text-red-500 mb-2">Não foi possível carregar os recursos.</p>
            <p>Por favor, tente novamente mais tarde.</p>
          </div>
        ) : resources && resources.length > 0 ? (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {resources.map((resource) => (
                <div key={resource.id} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition">
                  <div className="h-40 bg-[hsl(var(--primary))] flex items-center justify-center">
                    {renderResourceIcon(resource.type)}
                  </div>
                  <div className="p-4">
                    <span className="text-xs bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-2 py-1 rounded-full">
                      {resource.type}
                    </span>
                    <h3 className="font-medium mt-2">{resource.title}</h3>
                    <p className="text-sm text-gray-600 mt-1">{resource.author}</p>
                    <div className="flex justify-between items-center mt-3">
                      <span className="text-xs text-gray-500">{resource.year} • {resource.language}</span>
                      <Link href={`/library/resource/${resource.id}`} className="text-[hsl(var(--primary))] hover:text-[hsl(var(--secondary-blue))]">
                        <i className="fas fa-arrow-right"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Pagination */}
            <div className="mt-10 flex justify-center">
              <div className="flex space-x-2">
                <button 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="px-4 py-2 rounded-md border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <button 
                  onClick={() => setCurrentPage(prev => prev + 1)}
                  disabled={resources.length < 12} // Assume 12 is the page size
                  className="px-4 py-2 rounded-md border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-10 bg-white rounded-lg shadow-md">
            <i className="fas fa-book-open text-6xl text-gray-300 mb-4"></i>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Nenhum recurso encontrado</h3>
            <p className="text-gray-500">
              Tente ajustar seus filtros de pesquisa ou explore outras categorias.
            </p>
          </div>
        )}
      </div>

      {/* How to Use Section */}
      <div className="bg-[hsl(var(--secondary-yellow))] bg-opacity-30 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-[hsl(var(--primary))] mb-8 text-center">Como Utilizar a Biblioteca Virtual</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="bg-[hsl(var(--secondary))] w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <i className="fas fa-search text-[hsl(var(--primary))] text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-[hsl(var(--primary))]">Pesquise</h3>
              <p className="text-gray-600">
                Utilize os filtros e a barra de pesquisa para encontrar recursos específicos por tema, autor, idioma ou tipo de conteúdo.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="bg-[hsl(var(--secondary))] w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <i className="fas fa-download text-[hsl(var(--primary))] text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-[hsl(var(--primary))]">Acesse</h3>
              <p className="text-gray-600">
                Clique no recurso desejado para visualizar mais detalhes e acessar o conteúdo completo. Alguns recursos estão disponíveis para download.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="bg-[hsl(var(--secondary))] w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <i className="fas fa-user-graduate text-[hsl(var(--primary))] text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-[hsl(var(--primary))]">Aprenda</h3>
              <p className="text-gray-600">
                Explore recursos complementares às suas disciplinas ou descubra novos temas. A biblioteca é atualizada regularmente com novos conteúdos.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Resources by Category Section */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-2xl font-bold text-[hsl(var(--primary))] mb-8">Explore por Categoria</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES.slice(1).map((category) => (
            <div 
              key={category}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition cursor-pointer"
              onClick={() => {
                setCategoryFilter(category);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            >
              <div className="h-32 bg-[hsl(var(--primary))] flex items-center justify-center">
                <i className={`fas fa-${
                  category === 'História' ? 'landmark' : 
                  category === 'Cultura' ? 'theater-masks' :
                  category === 'Ciências' ? 'flask' :
                  category === 'Matemática' ? 'calculator' :
                  category === 'Literatura' ? 'book' : 'microchip'
                } text-4xl text-white`}></i>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold text-[hsl(var(--primary))]">{category}</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Explore recursos relacionados a {category.toLowerCase()}.
                </p>
                <div className="flex justify-end">
                  <span className="text-[hsl(var(--primary))]">
                    <i className="fas fa-arrow-right"></i>
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-[hsl(var(--primary))] text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Precisa de ajuda para encontrar recursos?</h2>
          <p className="max-w-2xl mx-auto mb-8">
            Nossa equipe de bibliotecários está disponível para ajudar você a localizar materiais específicos ou orientar sua pesquisa.
          </p>
          <Link 
            href="/contact" 
            className="inline-block bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-6 py-3 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition"
          >
            Fale com um Bibliotecário
          </Link>
        </div>
      </div>
    </>
  );
};

export default Library;
