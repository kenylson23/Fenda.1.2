import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

// Interfaces ampliadas para incluir campos adicionais
interface ExtendedUser {
  id: number;
  username: string;
  fullName?: string;
  email?: string;
  userType?: string;
  active?: boolean;
}

interface StudentData {
  enrollmentNumber: string;
  course?: string;
  semester?: number;
}

interface TeacherData {
  employeeId: string;
  department?: string;
  position?: string;
  specialization?: string;
}

export default function UsersTab() {
  const { toast } = useToast();
  const [users, setUsers] = useState<ExtendedUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddStudentDialog, setShowAddStudentDialog] = useState(false);
  const [showAddTeacherDialog, setShowAddTeacherDialog] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  
  // Estado para o formulário de novo aluno
  const [newStudent, setNewStudent] = useState({
    username: "",
    password: "",
    fullName: "",
    email: "",
    enrollmentNumber: "",
    course: "",
    semester: ""
  });
  
  // Estado para o formulário de novo professor
  const [newTeacher, setNewTeacher] = useState({
    username: "",
    password: "",
    fullName: "",
    email: "",
    employeeId: "",
    department: "",
    position: "",
    specialization: ""
  });

  useEffect(() => {
    // Carregar usuários da API
    fetch('/api/users')
      .then(response => {
        if (!response.ok) {
          throw new Error('Falha ao carregar usuários');
        }
        return response.json();
      })
      .then(data => {
        setUsers(data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Erro ao buscar usuários:', error);
        
        // Dados de exemplo para desenvolvimento/demonstração
        const mockUsers: ExtendedUser[] = [
          {
            id: 1,
            username: "admin",
            fullName: "Administrador",
            email: "admin@example.com",
            userType: "admin",
            active: true
          },
          {
            id: 2,
            username: "joao.silva",
            fullName: "João Silva",
            email: "joao@example.com",
            userType: "student",
            active: true
          },
          {
            id: 3,
            username: "maria.santos",
            fullName: "Maria Santos",
            email: "maria@example.com",
            userType: "teacher",
            active: true
          }
        ];
        
        setUsers(mockUsers);
        setLoading(false);
        
        toast({
          title: "Erro",
          description: "Não foi possível carregar os usuários. Usando dados de exemplo.",
          variant: "destructive"
        });
      });
  }, [toast]);

  // Estado para edição de usuário
  const [editingUser, setEditingUser] = useState<ExtendedUser | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editForm, setEditForm] = useState({
    username: "",
    fullName: "",
    email: "",
    userType: ""
  });

  const handleUserAction = (action: string, userId: number) => {
    if (action === "delete") {
      // Em um app real, faríamos uma chamada à API para excluir o usuário
      if (confirm("Tem certeza que deseja excluir este usuário?")) {
        setUsers(prev => prev.filter(user => user.id !== userId));
        toast({
          title: "Usuário removido",
          description: `Usuário ID ${userId} foi removido com sucesso.`
        });
      }
    } else if (action === "edit") {
      const userToEdit = users.find(user => user.id === userId);
      if (userToEdit) {
        setEditingUser(userToEdit);
        setEditForm({
          username: userToEdit.username || "",
          fullName: userToEdit.fullName || "",
          email: userToEdit.email || "",
          userType: userToEdit.userType || "student"
        });
        setShowEditDialog(true);
      } else {
        toast({
          title: "Erro",
          description: "Usuário não encontrado.",
          variant: "destructive"
        });
      }
    }
  };
  
  const handleEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingUser) return;
    
    try {
      // Em um app real, faríamos uma chamada API para atualizar o usuário
      // const response = await fetch(`/api/users/${editingUser.id}`, {
      //   method: 'PATCH',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(editForm)
      // });
      
      // if (!response.ok) throw new Error('Falha ao atualizar usuário');
      
      // Atualizar o usuário na lista local
      setUsers(prev => prev.map(user => 
        user.id === editingUser.id 
          ? { ...user, ...editForm }
          : user
      ));
      
      setShowEditDialog(false);
      setEditingUser(null);
      
      toast({
        title: "Usuário atualizado",
        description: "As informações do usuário foram atualizadas com sucesso."
      });
    } catch (error) {
      console.error('Erro ao atualizar usuário:', error);
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o usuário. Tente novamente.",
        variant: "destructive"
      });
    }
  };
  
  const handleEditInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditForm(prev => ({ ...prev, [name]: value }));
  };
  
  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Validação básica
      if (!newStudent.username || !newStudent.password || !newStudent.enrollmentNumber) {
        toast({
          title: "Erro de validação",
          description: "Preencha todos os campos obrigatórios.",
          variant: "destructive"
        });
        return;
      }
      
      // Verifica se já existe um usuário com o mesmo nome
      const existingUser = users.find(user => user.username.toLowerCase() === newStudent.username.toLowerCase());
      if (existingUser) {
        toast({
          title: "Nome de usuário já existe",
          description: "Por favor, escolha um nome de usuário diferente.",
          variant: "destructive"
        });
        return;
      }
      
      // Indica que estamos enviando o formulário
      setSubmitting(true);
      
      // Em um app real, enviaríamos os dados para a API
      const response = await fetch('/api/students', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userData: {
            username: newStudent.username,
            password: newStudent.password,
            fullName: newStudent.fullName,
            email: newStudent.email
          },
          studentData: {
            enrollmentNumber: newStudent.enrollmentNumber,
            course: newStudent.course,
            semester: newStudent.semester ? parseInt(newStudent.semester) : undefined
          }
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Falha ao criar aluno');
      }
      
      // Adicionar o novo usuário à lista
      setUsers(prev => [...prev, {
        id: data.user.id,
        username: data.user.username,
        fullName: data.user.fullName,
        email: data.user.email,
        userType: "student",
        active: true
      }]);
      
      // Limpar formulário e fechar diálogo
      setNewStudent({
        username: "",
        password: "",
        fullName: "",
        email: "",
        enrollmentNumber: "",
        course: "",
        semester: ""
      });
      
      setShowAddStudentDialog(false);
      
      toast({
        title: "Aluno adicionado",
        description: "O aluno foi adicionado com sucesso."
      });
    } catch (error: any) {
      console.error('Erro ao adicionar aluno:', error);
      toast({
        title: "Erro",
        description: error.message || "Não foi possível adicionar o aluno. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };
  
  const handleAddTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Validação básica
      if (!newTeacher.username || !newTeacher.password || !newTeacher.employeeId) {
        toast({
          title: "Erro de validação",
          description: "Preencha todos os campos obrigatórios.",
          variant: "destructive"
        });
        return;
      }
      
      // Verifica se já existe um usuário com o mesmo nome
      const existingUser = users.find(user => user.username.toLowerCase() === newTeacher.username.toLowerCase());
      if (existingUser) {
        toast({
          title: "Nome de usuário já existe",
          description: "Por favor, escolha um nome de usuário diferente.",
          variant: "destructive"
        });
        return;
      }
      
      // Indica que estamos enviando o formulário
      setSubmitting(true);
      
      // Enviar dados para a API
      const response = await fetch('/api/teachers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userData: {
            username: newTeacher.username,
            password: newTeacher.password,
            fullName: newTeacher.fullName,
            email: newTeacher.email
          },
          teacherData: {
            employeeId: newTeacher.employeeId,
            department: newTeacher.department,
            position: newTeacher.position,
            specialization: newTeacher.specialization
          }
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Falha ao criar professor');
      }
      
      // Adicionar o novo usuário à lista
      setUsers(prev => [...prev, {
        id: data.user.id,
        username: data.user.username,
        fullName: data.user.fullName,
        email: data.user.email,
        userType: "teacher",
        active: true
      }]);
      
      // Limpar formulário e fechar diálogo
      setNewTeacher({
        username: "",
        password: "",
        fullName: "",
        email: "",
        employeeId: "",
        department: "",
        position: "",
        specialization: ""
      });
      
      setShowAddTeacherDialog(false);
      
      toast({
        title: "Professor adicionado",
        description: "O professor foi adicionado com sucesso."
      });
    } catch (error: any) {
      console.error('Erro ao adicionar professor:', error);
      toast({
        title: "Erro",
        description: error.message || "Não foi possível adicionar o professor. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };
  
  const handleStudentInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewStudent(prev => ({ ...prev, [name]: value }));
  };
  
  const handleTeacherInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewTeacher(prev => ({ ...prev, [name]: value }));
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Gerenciar Usuários</CardTitle>
        <div className="space-x-2">
          <Dialog open={showAddStudentDialog} onOpenChange={setShowAddStudentDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">Adicionar Aluno</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Adicionar Novo Aluno</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddStudent}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="username">Nome de Usuário *</Label>
                      <Input
                        id="username"
                        name="username"
                        value={newStudent.username}
                        onChange={handleStudentInputChange}
                        placeholder="joao.silva"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Senha *</Label>
                      <Input
                        id="password"
                        name="password"
                        type="password"
                        value={newStudent.password}
                        onChange={handleStudentInputChange}
                        placeholder="******"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Nome Completo</Label>
                      <Input
                        id="fullName"
                        name="fullName"
                        value={newStudent.fullName}
                        onChange={handleStudentInputChange}
                        placeholder="João da Silva"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={newStudent.email}
                        onChange={handleStudentInputChange}
                        placeholder="joao@example.com"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="enrollmentNumber">Número de Matrícula *</Label>
                      <Input
                        id="enrollmentNumber"
                        name="enrollmentNumber"
                        value={newStudent.enrollmentNumber}
                        onChange={handleStudentInputChange}
                        placeholder="ANG20230001"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="course">Curso</Label>
                      <Input
                        id="course"
                        name="course"
                        value={newStudent.course}
                        onChange={handleStudentInputChange}
                        placeholder="Engenharia"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="semester">Semestre</Label>
                      <Input
                        id="semester"
                        name="semester"
                        type="number"
                        value={newStudent.semester}
                        onChange={handleStudentInputChange}
                        placeholder="1"
                      />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button type="button" variant="outline">Cancelar</Button>
                  </DialogClose>
                  <Button type="submit">Adicionar Aluno</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
          
          <Dialog open={showAddTeacherDialog} onOpenChange={setShowAddTeacherDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">Adicionar Professor</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Adicionar Novo Professor</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddTeacher}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="teacher-username">Nome de Usuário *</Label>
                      <Input
                        id="teacher-username"
                        name="username"
                        value={newTeacher.username}
                        onChange={handleTeacherInputChange}
                        placeholder="maria.santos"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="teacher-password">Senha *</Label>
                      <Input
                        id="teacher-password"
                        name="password"
                        type="password"
                        value={newTeacher.password}
                        onChange={handleTeacherInputChange}
                        placeholder="******"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="teacher-fullName">Nome Completo</Label>
                      <Input
                        id="teacher-fullName"
                        name="fullName"
                        value={newTeacher.fullName}
                        onChange={handleTeacherInputChange}
                        placeholder="Maria Santos"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="teacher-email">Email</Label>
                      <Input
                        id="teacher-email"
                        name="email"
                        type="email"
                        value={newTeacher.email}
                        onChange={handleTeacherInputChange}
                        placeholder="maria@example.com"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="employeeId">ID do Funcionário *</Label>
                      <Input
                        id="employeeId"
                        name="employeeId"
                        value={newTeacher.employeeId}
                        onChange={handleTeacherInputChange}
                        placeholder="PROF20230001"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="department">Departamento</Label>
                      <Input
                        id="department"
                        name="department"
                        value={newTeacher.department}
                        onChange={handleTeacherInputChange}
                        placeholder="Ciências Humanas"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="position">Cargo</Label>
                      <Input
                        id="position"
                        name="position"
                        value={newTeacher.position}
                        onChange={handleTeacherInputChange}
                        placeholder="Professor Adjunto"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="specialization">Especialização</Label>
                      <Input
                        id="specialization"
                        name="specialization"
                        value={newTeacher.specialization}
                        onChange={handleTeacherInputChange}
                        placeholder="História Africana"
                      />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button type="button" variant="outline" disabled={submitting}>Cancelar</Button>
                  </DialogClose>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? "Adicionando..." : "Adicionar Professor"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
          
          {/* Diálogo de Edição de Usuário */}
          <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Editar Usuário</DialogTitle>
              </DialogHeader>
              {editingUser && (
                <form onSubmit={handleEditUser}>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="edit-username">Nome de Usuário</Label>
                        <Input
                          id="edit-username"
                          name="username"
                          value={editForm.username}
                          onChange={handleEditInputChange}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-fullName">Nome Completo</Label>
                        <Input
                          id="edit-fullName"
                          name="fullName"
                          value={editForm.fullName}
                          onChange={handleEditInputChange}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="edit-email">Email</Label>
                        <Input
                          id="edit-email"
                          name="email"
                          type="email"
                          value={editForm.email}
                          onChange={handleEditInputChange}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="edit-userType">Tipo de Usuário</Label>
                        <Select 
                          value={editForm.userType} 
                          onValueChange={(value) => setEditForm(prev => ({ ...prev, userType: value }))}
                        >
                          <SelectTrigger id="edit-userType">
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="admin">Administrador</SelectItem>
                            <SelectItem value="student">Aluno</SelectItem>
                            <SelectItem value="teacher">Professor</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button type="button" variant="outline" disabled={submitting}>Cancelar</Button>
                    </DialogClose>
                    <Button type="submit" disabled={submitting}>
                      {submitting ? "Salvando..." : "Salvar Alterações"}
                    </Button>
                  </DialogFooter>
                </form>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <p>Carregando usuários...</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Nome de Usuário</TableHead>
                <TableHead>Nome Completo</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map(user => (
                <TableRow key={user.id}>
                  <TableCell>{user.id}</TableCell>
                  <TableCell>{user.username}</TableCell>
                  <TableCell>{user.fullName || "-"}</TableCell>
                  <TableCell>{user.email || "-"}</TableCell>
                  <TableCell>
                    {user.userType === "admin" && (
                      <Badge className="bg-purple-500">Administrador</Badge>
                    )}
                    {user.userType === "student" && (
                      <Badge className="bg-blue-500">Aluno</Badge>
                    )}
                    {user.userType === "teacher" && (
                      <Badge className="bg-green-500">Professor</Badge>
                    )}
                    {!user.userType && (
                      <Badge variant="outline">Não definido</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {user.active !== false ? (
                      <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                    ) : (
                      <Badge variant="outline" className="text-red-800">Inativo</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleUserAction("edit", user.id)}
                      >
                        Editar
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleUserAction("delete", user.id)}
                      >
                        Excluir
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}