import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export default function StatsTab() {
  const { toast } = useToast();
  const [stats, setStats] = useState({
    userCount: 0,
    resourceCount: 0,
    programCount: 0,
    applicationCount: 0,
    contactCount: 0,
    pendingApplications: 0,
    pendingContacts: 0
  });
  const [loading, setLoading] = useState(true);

  // Dados simulados para demonstração
  const mockStats = {
    userCount: 50,
    resourceCount: 35,
    programCount: 4,
    applicationCount: 28,
    contactCount: 42,
    pendingApplications: 12,
    pendingContacts: 8
  };

  useEffect(() => {
    // Em uma implementação real, carregaríamos da API
    setTimeout(() => {
      setStats(mockStats);
      setLoading(false);
    }, 1000);
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card className="bg-gradient-to-br from-blue-100 to-blue-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Usuários</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-[hsl(var(--primary))]">
            {loading ? "..." : stats.userCount}
          </div>
          <p className="text-sm text-gray-500 mt-1">Total de usuários cadastrados</p>
        </CardContent>
      </Card>
      
      <Card className="bg-gradient-to-br from-yellow-100 to-yellow-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Recursos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-[hsl(var(--primary))]">
            {loading ? "..." : stats.resourceCount}
          </div>
          <p className="text-sm text-gray-500 mt-1">Itens na biblioteca virtual</p>
        </CardContent>
      </Card>
      
      <Card className="bg-gradient-to-br from-green-100 to-green-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Programas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-[hsl(var(--primary))]">
            {loading ? "..." : stats.programCount}
          </div>
          <p className="text-sm text-gray-500 mt-1">Programas de intercâmbio ativos</p>
        </CardContent>
      </Card>
      
      <Card className="bg-gradient-to-br from-purple-100 to-purple-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Aplicações</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-[hsl(var(--primary))]">
            {loading ? "..." : stats.applicationCount}
          </div>
          <p className="text-sm text-gray-500 mt-1">Total de aplicações recebidas</p>
        </CardContent>
      </Card>
      
      <Card className="md:col-span-2 bg-gradient-to-br from-orange-100 to-orange-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Pendentes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-around">
            <div className="text-center">
              <div className="text-3xl font-bold text-[hsl(var(--primary))]">
                {loading ? "..." : stats.pendingApplications}
              </div>
              <p className="text-sm text-gray-500 mt-1">Aplicações pendentes</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-[hsl(var(--primary))]">
                {loading ? "..." : stats.pendingContacts}
              </div>
              <p className="text-sm text-gray-500 mt-1">Contatos não respondidos</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="md:col-span-2 bg-gradient-to-br from-cyan-100 to-cyan-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Atividade Recente</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            <li className="text-sm text-gray-600 pb-2 border-b border-gray-100">
              <span className="font-medium">João Silva</span> se cadastrou há 2 horas
            </li>
            <li className="text-sm text-gray-600 pb-2 border-b border-gray-100">
              <span className="font-medium">Maria Oliveira</span> enviou uma aplicação há 5 horas
            </li>
            <li className="text-sm text-gray-600 pb-2 border-b border-gray-100">
              <span className="font-medium">Carlos Santos</span> enviou um contato há 1 dia
            </li>
            <li className="text-sm text-gray-600">
              <span className="font-medium">Ana Pereira</span> se cadastrou há 2 dias
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}