import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Testimonial } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export default function TestimonialsTab() {
  const { toast } = useToast();
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Carregar depoimentos da API
    fetch('/api/testimonials')
      .then(response => {
        if (!response.ok) {
          throw new Error('Falha ao carregar depoimentos');
        }
        return response.json();
      })
      .then(data => {
        setTestimonials(data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Erro ao buscar depoimentos:', error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os depoimentos.",
          variant: "destructive"
        });
        setLoading(false);
      });
  }, [toast]);

  const handleTestimonialAction = (action: string, testimonialId: number) => {
    if (action === "delete") {
      toast({
        title: "Remover depoimento",
        description: "Esta funcionalidade será implementada em breve."
      });
    } else if (action === "edit") {
      toast({
        title: "Editar depoimento",
        description: "Esta funcionalidade será implementada em breve."
      });
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Gerenciar Depoimentos</CardTitle>
        <Button onClick={() => toast({
          title: "Novo depoimento",
          description: "Funcionalidade em desenvolvimento."
        })}>
          Adicionar Depoimento
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <p>Carregando depoimentos...</p>
          </div>
        ) : (
          <>
            {testimonials.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-gray-500">Nenhum depoimento encontrado.</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Função</TableHead>
                    <TableHead>Avaliação</TableHead>
                    <TableHead>Depoimento</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {testimonials.map(testimonial => (
                    <TableRow key={testimonial.id}>
                      <TableCell>{testimonial.id}</TableCell>
                      <TableCell className="font-medium">{testimonial.name}</TableCell>
                      <TableCell>{testimonial.role}</TableCell>
                      <TableCell>
                        <div className="flex text-yellow-500">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <span key={i}>
                              {i < Math.floor(Number(testimonial.rating)) ? "★" : "☆"}
                            </span>
                          ))}
                          <span className="ml-1 text-gray-600">
                            ({testimonial.rating})
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="max-w-md truncate">
                        {testimonial.testimonial.substring(0, 50)}...
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleTestimonialAction("edit", testimonial.id)}
                          >
                            Editar
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleTestimonialAction("delete", testimonial.id)}
                          >
                            Excluir
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}