import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Edit, Trash2, Plus, X, UserPlus, BookOpen } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Schema para validação do formulário de turma
const classFormSchema = z.object({
  name: z.string().min(2, "Nome da turma deve ter pelo menos 2 caracteres"),
  year: z.coerce.number().min(2023, "Ano deve ser válido"),
  semester: z.string().min(1, "Semestre é obrigatório"),
  startDate: z.date({
    required_error: "Data de início é obrigatória",
  }),
  endDate: z.date({
    required_error: "Data de término é obrigatória",
  }).refine(date => date > new Date(), {
    message: "Data de término deve ser no futuro",
  }),
  description: z.string().min(10, "Descrição deve ter pelo menos 10 caracteres"),
  status: z.string().default("active"),
  maxStudents: z.coerce.number().min(1, "Número mínimo de alunos deve ser 1"),
});

// Interface para os dados da turma
interface ClassData {
  id: number;
  name: string;
  year: number;
  semester: string;
  startDate: Date;
  endDate: Date;
  description: string;
  status: string;
  maxStudents: number;
  createdAt: Date;
}

// Interface para professores
interface Teacher {
  id: number;
  userId: number;
  employeeId: string;
  department?: string;
  position?: string;
  specialization?: string;
  education?: string;
  user: {
    id: number;
    username: string;
    fullName?: string;
    email?: string;
  };
}

// Interface para alunos
interface Student {
  id: number;
  userId: number;
  enrollmentNumber: string;
  course?: string;
  semester?: number;
  user: {
    id: number;
    username: string;
    fullName?: string;
    email?: string;
  };
}

// Interface para disciplinas
interface Subject {
  id: number;
  name: string;
  description?: string;
  credits: number;
  schedule: string;
}

// Tipo para o formulário
type ClassFormValues = z.infer<typeof classFormSchema>;

export default function ClassesTab() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isManageTeachersDialogOpen, setIsManageTeachersDialogOpen] = useState(false);
  const [isManageStudentsDialogOpen, setIsManageStudentsDialogOpen] = useState(false);
  const [isManageSubjectsDialogOpen, setIsManageSubjectsDialogOpen] = useState(false);
  const [currentClassId, setCurrentClassId] = useState<number | null>(null);
  const [selectedTeachers, setSelectedTeachers] = useState<number[]>([]);
  const [selectedStudents, setSelectedStudents] = useState<number[]>([]);
  const [classSubjectForm, setClassSubjectForm] = useState({
    name: "",
    description: "",
    credits: 4,
    schedule: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Formulário para turmas
  const form = useForm<ClassFormValues>({
    resolver: zodResolver(classFormSchema),
    defaultValues: {
      name: "",
      year: new Date().getFullYear(),
      semester: "1º Semestre",
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)),
      description: "",
      status: "active",
      maxStudents: 30,
    },
  });

  // Consulta para obter todas as turmas
  const { data: classes, isLoading: isLoadingClasses } = useQuery({
    queryKey: ["/api/classes"],
    queryFn: async () => {
      try {
        const response = await apiRequest("/api/classes");
        return response.json();
      } catch (error) {
        console.error("Erro ao carregar turmas:", error);
        return [];
      }
    },
  });

  // Consulta para obter todos os professores
  const { data: teachers, isLoading: isLoadingTeachers } = useQuery({
    queryKey: ["/api/teachers"],
    queryFn: async () => {
      try {
        const response = await apiRequest("/api/teachers");
        return response.json();
      } catch (error) {
        console.error("Erro ao carregar professores:", error);
        return [];
      }
    },
  });

  // Consulta para obter todos os alunos
  const { data: students, isLoading: isLoadingStudents } = useQuery({
    queryKey: ["/api/students"],
    queryFn: async () => {
      try {
        const response = await apiRequest("/api/students");
        return response.json();
      } catch (error) {
        console.error("Erro ao carregar alunos:", error);
        return [];
      }
    },
  });

  // Consulta para obter os professores de uma turma específica
  const { data: classTeachers, refetch: refetchClassTeachers } = useQuery({
    queryKey: ["/api/classes/teachers", currentClassId],
    queryFn: async () => {
      if (!currentClassId) return [];
      try {
        const response = await apiRequest(`/api/classes/${currentClassId}/teachers`);
        return response.json();
      } catch (error) {
        console.error("Erro ao carregar professores da turma:", error);
        return [];
      }
    },
    enabled: !!currentClassId && isManageTeachersDialogOpen,
  });

  // Consulta para obter os alunos de uma turma específica
  const { data: classStudents, refetch: refetchClassStudents } = useQuery({
    queryKey: ["/api/classes/students", currentClassId],
    queryFn: async () => {
      if (!currentClassId) return [];
      try {
        const response = await apiRequest(`/api/classes/${currentClassId}/students`);
        return response.json();
      } catch (error) {
        console.error("Erro ao carregar alunos da turma:", error);
        return [];
      }
    },
    enabled: !!currentClassId && isManageStudentsDialogOpen,
  });

  // Consulta para obter as disciplinas de uma turma específica
  const { data: classSubjects, refetch: refetchClassSubjects } = useQuery({
    queryKey: ["/api/classes/subjects", currentClassId],
    queryFn: async () => {
      if (!currentClassId) return [];
      try {
        const response = await apiRequest(`/api/classes/${currentClassId}/subjects`);
        return response.json();
      } catch (error) {
        console.error("Erro ao carregar disciplinas da turma:", error);
        return [];
      }
    },
    enabled: !!currentClassId && isManageSubjectsDialogOpen,
  });

  // Mutação para adicionar uma nova turma
  const addClassMutation = useMutation({
    mutationFn: async (data: ClassFormValues) => {
      const response = await fetch("/api/classes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error("Falha ao adicionar turma");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Turma adicionada",
        description: "A turma foi adicionada com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      setIsAddDialogOpen(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao adicionar turma",
        description: "Não foi possível adicionar a turma. Tente novamente.",
        variant: "destructive",
      });
      console.error("Erro ao adicionar turma:", error);
    },
  });

  // Mutação para atualizar uma turma existente
  const updateClassMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: ClassFormValues }) => {
      const response = await fetch(`/api/classes/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error("Falha ao atualizar turma");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Turma atualizada",
        description: "A turma foi atualizada com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      setIsEditDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar turma",
        description: "Não foi possível atualizar a turma. Tente novamente.",
        variant: "destructive",
      });
      console.error("Erro ao atualizar turma:", error);
    },
  });

  // Mutação para excluir uma turma
  const deleteClassMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/classes/${id}`, {
        method: "DELETE",
      });
      
      if (!response.ok) {
        throw new Error("Falha ao excluir turma");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Turma excluída",
        description: "A turma foi excluída com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      setIsDeleteDialogOpen(false);
      setCurrentClassId(null);
    },
    onError: (error) => {
      toast({
        title: "Erro ao excluir turma",
        description: "Não foi possível excluir a turma. Tente novamente.",
        variant: "destructive",
      });
      console.error("Erro ao excluir turma:", error);
    },
  });

  // Mutação para adicionar professores a uma turma
  const addTeachersToClassMutation = useMutation({
    mutationFn: async ({ classId, teacherIds }: { classId: number; teacherIds: number[] }) => {
      const response = await fetch(`/api/classes/${classId}/teachers`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ teacherIds }),
      });
      
      if (!response.ok) {
        throw new Error("Falha ao adicionar professores à turma");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Professores adicionados",
        description: "Os professores foram adicionados à turma com sucesso.",
      });
      refetchClassTeachers();
      setSelectedTeachers([]);
    },
    onError: (error) => {
      toast({
        title: "Erro ao adicionar professores",
        description: "Não foi possível adicionar os professores à turma. Tente novamente.",
        variant: "destructive",
      });
      console.error("Erro ao adicionar professores:", error);
    },
  });

  // Mutação para remover um professor de uma turma
  const removeTeacherFromClassMutation = useMutation({
    mutationFn: async ({ classId, teacherId }: { classId: number; teacherId: number }) => {
      const response = await fetch(`/api/classes/${classId}/teachers/${teacherId}`, {
        method: "DELETE",
      });
      
      if (!response.ok) {
        throw new Error("Falha ao remover professor da turma");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Professor removido",
        description: "O professor foi removido da turma com sucesso.",
      });
      refetchClassTeachers();
    },
    onError: (error) => {
      toast({
        title: "Erro ao remover professor",
        description: "Não foi possível remover o professor da turma. Tente novamente.",
        variant: "destructive",
      });
      console.error("Erro ao remover professor:", error);
    },
  });

  // Mutação para adicionar alunos a uma turma
  const addStudentsToClassMutation = useMutation({
    mutationFn: async ({ classId, studentIds }: { classId: number; studentIds: number[] }) => {
      const response = await fetch(`/api/classes/${classId}/students`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ studentIds }),
      });
      
      if (!response.ok) {
        throw new Error("Falha ao adicionar alunos à turma");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Alunos adicionados",
        description: "Os alunos foram adicionados à turma com sucesso.",
      });
      refetchClassStudents();
      setSelectedStudents([]);
    },
    onError: (error) => {
      toast({
        title: "Erro ao adicionar alunos",
        description: "Não foi possível adicionar os alunos à turma. Tente novamente.",
        variant: "destructive",
      });
      console.error("Erro ao adicionar alunos:", error);
    },
  });

  // Mutação para remover um aluno de uma turma
  const removeStudentFromClassMutation = useMutation({
    mutationFn: async ({ classId, studentId }: { classId: number; studentId: number }) => {
      const response = await fetch(`/api/classes/${classId}/students/${studentId}`, {
        method: "DELETE",
      });
      
      if (!response.ok) {
        throw new Error("Falha ao remover aluno da turma");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Aluno removido",
        description: "O aluno foi removido da turma com sucesso.",
      });
      refetchClassStudents();
    },
    onError: (error) => {
      toast({
        title: "Erro ao remover aluno",
        description: "Não foi possível remover o aluno da turma. Tente novamente.",
        variant: "destructive",
      });
      console.error("Erro ao remover aluno:", error);
    },
  });

  // Mutação para adicionar uma disciplina a uma turma
  const addSubjectToClassMutation = useMutation({
    mutationFn: async ({ classId, subjectData }: { classId: number; subjectData: Omit<Subject, "id"> }) => {
      const response = await fetch(`/api/classes/${classId}/subjects`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(subjectData),
      });
      
      if (!response.ok) {
        throw new Error("Falha ao adicionar disciplina à turma");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Disciplina adicionada",
        description: "A disciplina foi adicionada à turma com sucesso.",
      });
      refetchClassSubjects();
      setClassSubjectForm({
        name: "",
        description: "",
        credits: 4,
        schedule: ""
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao adicionar disciplina",
        description: "Não foi possível adicionar a disciplina à turma. Tente novamente.",
        variant: "destructive",
      });
      console.error("Erro ao adicionar disciplina:", error);
    },
  });

  // Mutação para remover uma disciplina de uma turma
  const removeSubjectFromClassMutation = useMutation({
    mutationFn: async ({ classId, subjectId }: { classId: number; subjectId: number }) => {
      const response = await fetch(`/api/classes/${classId}/subjects/${subjectId}`, {
        method: "DELETE",
      });
      
      if (!response.ok) {
        throw new Error("Falha ao remover disciplina da turma");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Disciplina removida",
        description: "A disciplina foi removida da turma com sucesso.",
      });
      refetchClassSubjects();
    },
    onError: (error) => {
      toast({
        title: "Erro ao remover disciplina",
        description: "Não foi possível remover a disciplina da turma. Tente novamente.",
        variant: "destructive",
      });
      console.error("Erro ao remover disciplina:", error);
    },
  });

  // Função para preparar o formulário para edição
  const handleEditClass = (classData: ClassData) => {
    setCurrentClassId(classData.id);
    form.reset({
      name: classData.name,
      year: classData.year,
      semester: classData.semester,
      startDate: new Date(classData.startDate),
      endDate: new Date(classData.endDate),
      description: classData.description,
      status: classData.status,
      maxStudents: classData.maxStudents,
    });
    setIsEditDialogOpen(true);
  };

  // Função para submeter o formulário de adição
  const onSubmitAdd = (data: ClassFormValues) => {
    addClassMutation.mutate(data);
  };

  // Função para submeter o formulário de edição
  const onSubmitEdit = (data: ClassFormValues) => {
    if (currentClassId) {
      updateClassMutation.mutate({ id: currentClassId, data });
    }
  };

  // Função para confirmar exclusão
  const handleDeleteClass = (id: number) => {
    setCurrentClassId(id);
    setIsDeleteDialogOpen(true);
  };

  // Função para confirmar exclusão definitiva
  const confirmDeleteClass = () => {
    if (currentClassId) {
      deleteClassMutation.mutate(currentClassId);
    }
  };

  // Função para abrir o diálogo de gerenciamento de professores
  const handleManageTeachers = (id: number) => {
    setCurrentClassId(id);
    setIsManageTeachersDialogOpen(true);
  };

  // Função para adicionar professores selecionados à turma
  const handleAddTeachersToClass = () => {
    if (currentClassId && selectedTeachers.length > 0) {
      addTeachersToClassMutation.mutate({
        classId: currentClassId,
        teacherIds: selectedTeachers
      });
    }
  };

  // Função para remover um professor da turma
  const handleRemoveTeacherFromClass = (teacherId: number) => {
    if (currentClassId) {
      removeTeacherFromClassMutation.mutate({
        classId: currentClassId,
        teacherId
      });
    }
  };

  // Função para abrir o diálogo de gerenciamento de alunos
  const handleManageStudents = (id: number) => {
    setCurrentClassId(id);
    setIsManageStudentsDialogOpen(true);
  };

  // Função para adicionar alunos selecionados à turma
  const handleAddStudentsToClass = () => {
    if (currentClassId && selectedStudents.length > 0) {
      addStudentsToClassMutation.mutate({
        classId: currentClassId,
        studentIds: selectedStudents
      });
    }
  };

  // Função para remover um aluno da turma
  const handleRemoveStudentFromClass = (studentId: number) => {
    if (currentClassId) {
      removeStudentFromClassMutation.mutate({
        classId: currentClassId,
        studentId
      });
    }
  };

  // Função para abrir o diálogo de gerenciamento de disciplinas
  const handleManageSubjects = (id: number) => {
    setCurrentClassId(id);
    setIsManageSubjectsDialogOpen(true);
  };

  // Função para adicionar uma disciplina à turma
  const handleAddSubjectToClass = () => {
    if (currentClassId && classSubjectForm.name && classSubjectForm.schedule) {
      addSubjectToClassMutation.mutate({
        classId: currentClassId,
        subjectData: {
          name: classSubjectForm.name,
          description: classSubjectForm.description,
          credits: classSubjectForm.credits,
          schedule: classSubjectForm.schedule
        }
      });
    }
  };

  // Função para remover uma disciplina da turma
  const handleRemoveSubjectFromClass = (subjectId: number) => {
    if (currentClassId) {
      removeSubjectFromClassMutation.mutate({
        classId: currentClassId,
        subjectId
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">Gestão de Turmas</h2>
        <Button 
          onClick={() => {
            form.reset();
            setIsAddDialogOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" /> Nova Turma
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Turmas</CardTitle>
          <CardDescription>
            Gerencie as turmas, professores, alunos e disciplinas.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingClasses ? (
            <div className="flex justify-center py-6">Carregando turmas...</div>
          ) : classes && classes.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Ano/Semestre</TableHead>
                  <TableHead>Período</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Vagas</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {classes && classes.map((classItem: ClassData) => (
                  <TableRow key={classItem.id}>
                    <TableCell className="font-medium">{classItem.name}</TableCell>
                    <TableCell>{classItem.year}/{classItem.semester}</TableCell>
                    <TableCell>
                      {format(new Date(classItem.startDate), "dd/MM/yyyy")} até {format(new Date(classItem.endDate), "dd/MM/yyyy")}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={classItem.status === "active" ? "default" : 
                                classItem.status === "completed" ? "secondary" : "destructive"}
                      >
                        {classItem.status === "active" ? "Ativa" : 
                         classItem.status === "completed" ? "Concluída" : "Cancelada"}
                      </Badge>
                    </TableCell>
                    <TableCell>{classItem.maxStudents}</TableCell>
                    <TableCell className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => handleEditClass(classItem)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => handleDeleteClass(classItem.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleManageTeachers(classItem.id)}
                      >
                        <UserPlus className="mr-2 h-4 w-4" /> Professores
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleManageStudents(classItem.id)}
                      >
                        <UserPlus className="mr-2 h-4 w-4" /> Alunos
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleManageSubjects(classItem.id)}
                      >
                        <BookOpen className="mr-2 h-4 w-4" /> Disciplinas
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-6">
              <p className="text-muted-foreground">Nenhuma turma encontrada.</p>
              <Button 
                variant="link" 
                onClick={() => {
                  form.reset();
                  setIsAddDialogOpen(true);
                }}
              >
                Criar primeira turma
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Diálogo para adicionar turma */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Adicionar Nova Turma</DialogTitle>
            <DialogDescription>
              Preencha os detalhes para criar uma nova turma.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmitAdd)} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome da Turma</FormLabel>
                      <FormControl>
                        <Input placeholder="Ex: Turma A" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ano</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="2023"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="semester"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Semestre</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione..." />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="1º Semestre">1º Semestre</SelectItem>
                            <SelectItem value="2º Semestre">2º Semestre</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Data de Início</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className="pl-3 text-left font-normal"
                            >
                              {field.value ? (
                                format(field.value, "dd/MM/yyyy")
                              ) : (
                                <span>Selecione uma data</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Data de Término</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className="pl-3 text-left font-normal"
                            >
                              {field.value ? (
                                format(field.value, "dd/MM/yyyy")
                              ) : (
                                <span>Selecione uma data</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Ativa</SelectItem>
                          <SelectItem value="completed">Concluída</SelectItem>
                          <SelectItem value="canceled">Cancelada</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="maxStudents"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Máximo de Alunos</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="1"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Descreva detalhes sobre a turma..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={addClassMutation.isPending}>
                  {addClassMutation.isPending ? "Adicionando..." : "Adicionar Turma"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Diálogo para editar turma */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Turma</DialogTitle>
            <DialogDescription>
              Atualize os detalhes da turma.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmitEdit)} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome da Turma</FormLabel>
                      <FormControl>
                        <Input placeholder="Ex: Turma A" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ano</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="2023"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="semester"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Semestre</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione..." />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="1º Semestre">1º Semestre</SelectItem>
                            <SelectItem value="2º Semestre">2º Semestre</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Data de Início</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className="pl-3 text-left font-normal"
                            >
                              {field.value ? (
                                format(field.value, "dd/MM/yyyy")
                              ) : (
                                <span>Selecione uma data</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Data de Término</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className="pl-3 text-left font-normal"
                            >
                              {field.value ? (
                                format(field.value, "dd/MM/yyyy")
                              ) : (
                                <span>Selecione uma data</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Ativa</SelectItem>
                          <SelectItem value="completed">Concluída</SelectItem>
                          <SelectItem value="canceled">Cancelada</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="maxStudents"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Máximo de Alunos</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="1"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Descreva detalhes sobre a turma..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={updateClassMutation.isPending}>
                  {updateClassMutation.isPending ? "Atualizando..." : "Salvar Alterações"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Diálogo para confirmar exclusão */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir esta turma? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={confirmDeleteClass}
              disabled={deleteClassMutation.isPending}
            >
              {deleteClassMutation.isPending ? "Excluindo..." : "Confirmar Exclusão"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para gerenciar professores */}
      <Dialog open={isManageTeachersDialogOpen} onOpenChange={setIsManageTeachersDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Gerenciar Professores da Turma</DialogTitle>
            <DialogDescription>
              Adicione ou remova professores desta turma.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="current">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="current">Professores Atuais</TabsTrigger>
              <TabsTrigger value="add">Adicionar Professores</TabsTrigger>
            </TabsList>
            <TabsContent value="current" className="py-4">
              {classTeachers && classTeachers.length > 0 ? (
                <div className="space-y-4">
                  {classTeachers.map((teacher) => (
                    <div key={teacher.id} className="flex items-center justify-between border p-3 rounded-md">
                      <div>
                        <p className="font-medium">{teacher.user.fullName || teacher.user.username}</p>
                        <p className="text-sm text-muted-foreground">
                          {teacher.department || "Sem departamento"} | {teacher.specialization || "Sem especialização"}
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleRemoveTeacherFromClass(teacher.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhum professor associado a esta turma.</p>
                </div>
              )}
            </TabsContent>
            <TabsContent value="add" className="py-4">
              {isLoadingTeachers ? (
                <div className="flex justify-center py-6">Carregando professores...</div>
              ) : teachers && teachers.length > 0 ? (
                <>
                  <div className="space-y-4 mb-4 max-h-64 overflow-y-auto">
                    {teachers
                      .filter(teacher => !classTeachers?.some(ct => ct.id === teacher.id))
                      .map((teacher) => (
                        <div key={teacher.id} className="flex items-center space-x-2 border p-3 rounded-md">
                          <input
                            type="checkbox"
                            id={`teacher-${teacher.id}`}
                            checked={selectedTeachers.includes(teacher.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedTeachers([...selectedTeachers, teacher.id]);
                              } else {
                                setSelectedTeachers(selectedTeachers.filter(id => id !== teacher.id));
                              }
                            }}
                            className="w-4 h-4"
                          />
                          <label htmlFor={`teacher-${teacher.id}`} className="flex-1">
                            <p className="font-medium">{teacher.user.fullName || teacher.user.username}</p>
                            <p className="text-sm text-muted-foreground">
                              {teacher.department || "Sem departamento"} | {teacher.specialization || "Sem especialização"}
                            </p>
                          </label>
                        </div>
                      ))}
                  </div>
                  <div className="flex justify-end">
                    <Button
                      onClick={handleAddTeachersToClass}
                      disabled={selectedTeachers.length === 0}
                    >
                      Adicionar Professores Selecionados
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhum professor disponível.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Diálogo para gerenciar alunos */}
      <Dialog open={isManageStudentsDialogOpen} onOpenChange={setIsManageStudentsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Gerenciar Alunos da Turma</DialogTitle>
            <DialogDescription>
              Adicione ou remova alunos desta turma.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="current">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="current">Alunos Atuais</TabsTrigger>
              <TabsTrigger value="add">Adicionar Alunos</TabsTrigger>
            </TabsList>
            <TabsContent value="current" className="py-4">
              {classStudents && classStudents.length > 0 ? (
                <div className="space-y-4">
                  {classStudents.map((student) => (
                    <div key={student.id} className="flex items-center justify-between border p-3 rounded-md">
                      <div>
                        <p className="font-medium">{student.user.fullName || student.user.username}</p>
                        <p className="text-sm text-muted-foreground">
                          Matrícula: {student.enrollmentNumber} | {student.course || "Sem curso"} | {student.semester ? `${student.semester}º semestre` : "Sem semestre"}
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleRemoveStudentFromClass(student.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhum aluno associado a esta turma.</p>
                </div>
              )}
            </TabsContent>
            <TabsContent value="add" className="py-4">
              {isLoadingStudents ? (
                <div className="flex justify-center py-6">Carregando alunos...</div>
              ) : students && students.length > 0 ? (
                <>
                  <div className="space-y-4 mb-4 max-h-64 overflow-y-auto">
                    {students
                      .filter(student => !classStudents?.some(cs => cs.id === student.id))
                      .map((student) => (
                        <div key={student.id} className="flex items-center space-x-2 border p-3 rounded-md">
                          <input
                            type="checkbox"
                            id={`student-${student.id}`}
                            checked={selectedStudents.includes(student.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedStudents([...selectedStudents, student.id]);
                              } else {
                                setSelectedStudents(selectedStudents.filter(id => id !== student.id));
                              }
                            }}
                            className="w-4 h-4"
                          />
                          <label htmlFor={`student-${student.id}`} className="flex-1">
                            <p className="font-medium">{student.user.fullName || student.user.username}</p>
                            <p className="text-sm text-muted-foreground">
                              Matrícula: {student.enrollmentNumber} | {student.course || "Sem curso"} | {student.semester ? `${student.semester}º semestre` : "Sem semestre"}
                            </p>
                          </label>
                        </div>
                      ))}
                  </div>
                  <div className="flex justify-end">
                    <Button
                      onClick={handleAddStudentsToClass}
                      disabled={selectedStudents.length === 0}
                    >
                      Adicionar Alunos Selecionados
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhum aluno disponível.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Diálogo para gerenciar disciplinas */}
      <Dialog open={isManageSubjectsDialogOpen} onOpenChange={setIsManageSubjectsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Gerenciar Disciplinas da Turma</DialogTitle>
            <DialogDescription>
              Adicione ou remova disciplinas desta turma.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="current">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="current">Disciplinas Atuais</TabsTrigger>
              <TabsTrigger value="add">Adicionar Disciplina</TabsTrigger>
            </TabsList>
            <TabsContent value="current" className="py-4">
              {classSubjects && classSubjects.length > 0 ? (
                <div className="space-y-4">
                  {classSubjects.map((subject) => (
                    <div key={subject.id} className="flex items-center justify-between border p-3 rounded-md">
                      <div>
                        <p className="font-medium">{subject.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {subject.description || "Sem descrição"} | Créditos: {subject.credits}
                        </p>
                        <p className="text-sm mt-1">Horário: {subject.schedule}</p>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleRemoveSubjectFromClass(subject.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhuma disciplina associada a esta turma.</p>
                </div>
              )}
            </TabsContent>
            <TabsContent value="add" className="py-4">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="subject-name" className="text-sm font-medium">
                      Nome da Disciplina
                    </label>
                    <Input
                      id="subject-name"
                      value={classSubjectForm.name}
                      onChange={(e) => setClassSubjectForm({ ...classSubjectForm, name: e.target.value })}
                      placeholder="Ex: Matemática"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="subject-credits" className="text-sm font-medium">
                      Créditos
                    </label>
                    <Input
                      id="subject-credits"
                      type="number"
                      min="1"
                      value={classSubjectForm.credits}
                      onChange={(e) => setClassSubjectForm({ ...classSubjectForm, credits: parseInt(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject-schedule" className="text-sm font-medium">
                    Horário
                  </label>
                  <Input
                    id="subject-schedule"
                    value={classSubjectForm.schedule}
                    onChange={(e) => setClassSubjectForm({ ...classSubjectForm, schedule: e.target.value })}
                    placeholder="Ex: Segunda 10:00-12:00, Quarta 10:00-12:00"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject-description" className="text-sm font-medium">
                    Descrição
                  </label>
                  <Textarea
                    id="subject-description"
                    value={classSubjectForm.description}
                    onChange={(e) => setClassSubjectForm({ ...classSubjectForm, description: e.target.value })}
                    placeholder="Descrição da disciplina..."
                  />
                </div>
                <div className="flex justify-end">
                  <Button
                    onClick={handleAddSubjectToClass}
                    disabled={!classSubjectForm.name || !classSubjectForm.schedule}
                  >
                    Adicionar Disciplina
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}