import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Importações dos componentes existentes para os submódulos da Área Pedagógica
import EducationLevels from "@/pages/admin/components/education-levels-tab";
import ClassesComponent from "@/pages/admin/components/classes-tab";
import Courses from "@/pages/admin/components/courses-tab";
import Subjects from "@/pages/admin/components/subjects-tab";

export default function PedagogicalArea() {
  const [activeTab, setActiveTab] = useState("education-levels");

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Área Pedagógica</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-4 mb-6">
              <TabsTrigger value="education-levels">Níveis de Ensino</TabsTrigger>
              <TabsTrigger value="courses">Cursos</TabsTrigger>
              <TabsTrigger value="classes">Turmas</TabsTrigger>
              <TabsTrigger value="subjects">Disciplinas</TabsTrigger>
            </TabsList>
            
            <TabsContent value="education-levels">
              <EducationLevels />
            </TabsContent>
            
            <TabsContent value="courses">
              <Courses />
            </TabsContent>
            
            <TabsContent value="classes">
              <ClassesComponent />
            </TabsContent>
            
            <TabsContent value="subjects">
              <Subjects />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}