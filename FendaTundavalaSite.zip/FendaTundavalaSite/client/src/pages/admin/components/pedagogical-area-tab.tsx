import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Importações dos componentes de submódulos
import EducationLevels from "./pedagogical/education-levels";
import Courses from "./pedagogical/courses";
import Classes from "./pedagogical/classes";
import Subjects from "./pedagogical/subjects";

export default function PedagogicalAreaTab() {
  const [activeTab, setActiveTab] = useState("education-levels");

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Área Pedagógica</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-4 mb-6">
              <TabsTrigger value="education-levels">Níveis de Ensino</TabsTrigger>
              <TabsTrigger value="courses">Cursos</TabsTrigger>
              <TabsTrigger value="classes">Turmas</TabsTrigger>
              <TabsTrigger value="subjects">Disciplinas</TabsTrigger>
            </TabsList>
            
            <TabsContent value="education-levels">
              <EducationLevels />
            </TabsContent>
            
            <TabsContent value="courses">
              <Courses />
            </TabsContent>
            
            <TabsContent value="classes">
              <Classes />
            </TabsContent>
            
            <TabsContent value="subjects">
              <Subjects />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}