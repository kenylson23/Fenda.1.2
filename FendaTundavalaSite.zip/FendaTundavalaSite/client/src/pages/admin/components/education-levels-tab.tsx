import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Pencil, Plus, Trash, FolderOpen, FileEdit, FilePlus2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";

// Definição do tipo EducationLevel
interface EducationLevel {
  id: number;
  name: string;
  description: string;
  levelOrder: number;
  active: boolean;
  createdAt?: string;
  classCount?: number;
}

// Form data type
interface EducationLevelFormData {
  name: string;
  description: string;
  levelOrder: number;
  active: boolean;
}

// Definição do tipo Class
interface Class {
  id: number;
  name: string;
  year: number;
  semester: string;
  startDate: string;
  endDate: string;
  description?: string;
  status: string;
  maxStudents: number;
  educationLevelId: number;
  createdAt: string;
}

// Form data type para Classes
interface ClassFormData {
  name: string;
  year: number;
  semester: string;
  startDate: Date;
  endDate: Date;
  description: string;
  status: string;
  maxStudents: number;
  educationLevelId: number;
}

export function EducationLevelsTab() {
  const { toast } = useToast();
  const [educationLevels, setEducationLevels] = useState<EducationLevel[]>([]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState<EducationLevelFormData>({
    name: "",
    description: "",
    levelOrder: 1,
    active: true
  });
  
  // Estados para gerenciamento de classes
  const [isViewClassesDialogOpen, setIsViewClassesDialogOpen] = useState(false);
  const [isAddClassDialogOpen, setIsAddClassDialogOpen] = useState(false);
  const [isEditClassDialogOpen, setIsEditClassDialogOpen] = useState(false);
  const [isDeleteClassDialogOpen, setIsDeleteClassDialogOpen] = useState(false);
  const [selectedClassId, setSelectedClassId] = useState<number | null>(null);
  const [selectedClass, setSelectedClass] = useState<Class | null>(null);
  const [currentLevelClasses, setCurrentLevelClasses] = useState<Class[]>([]);
  const [currentLevelName, setCurrentLevelName] = useState<string>("");
  const [classFormData, setClassFormData] = useState<ClassFormData>({
    name: "",
    year: new Date().getFullYear(),
    semester: "1º Semestre",
    startDate: new Date(),
    endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)),
    description: "",
    status: "active",
    maxStudents: 30,
    educationLevelId: 0
  });
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedLevelId, setSelectedLevelId] = useState<number | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<EducationLevel | null>(null);

  // Fetch education levels
  const fetchEducationLevels = async () => {
    try {
      setLoading(true);
      // Usar fetch diretamente para diagnosticar
      const response = await fetch('/api/education-levels');
      const data = await response.json();
      
      console.log("Dados recebidos da API:", data);
      
      if (Array.isArray(data)) {
        setEducationLevels(data);
        console.log("Níveis de ensino carregados:", data.length);
      } else {
        console.error("Resposta da API não é um array:", data);
        setEducationLevels([]);
      }
    } catch (error) {
      console.error("Error fetching education levels:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os níveis de ensino.",
        variant: "destructive"
      });
      setEducationLevels([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEducationLevels();
  }, []);

  // Reset form
  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      levelOrder: 1,
      active: true
    });
  };

  // Open add dialog
  const handleAddClick = () => {
    resetForm();
    setIsAddDialogOpen(true);
  };

  // Open edit dialog
  const handleEditClick = (level: EducationLevel) => {
    setSelectedLevel(level);
    setFormData({
      name: level.name,
      description: level.description || "",
      levelOrder: level.levelOrder,
      active: level.active
    });
    setIsEditDialogOpen(true);
  };

  // Open delete dialog
  const handleDeleteClick = (id: number) => {
    setSelectedLevelId(id);
    setIsDeleteDialogOpen(true);
  };

  // Handle form input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === "levelOrder" ? parseInt(value) || 1 : value
    }));
  };

  // Handle switch change
  const handleSwitchChange = (checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      active: checked
    }));
  };

  // Create education level
  const handleCreateLevel = async () => {
    try {
      const response = await apiRequest({
        method: "POST",
        url: "/api/education-levels",
        data: formData
      });

      if (response) {
        setEducationLevels(prev => [...prev, response as EducationLevel]);
        setIsAddDialogOpen(false);
        resetForm();

        toast({
          title: "Sucesso",
          description: "Nível de ensino criado com sucesso.",
        });
      }
    } catch (error) {
      console.error("Error creating education level:", error);
      toast({
        title: "Erro",
        description: "Não foi possível criar o nível de ensino.",
        variant: "destructive"
      });
    }
  };

  // Update education level
  const handleUpdateLevel = async () => {
    if (!selectedLevel) return;

    try {
      const response = await apiRequest({
        method: "PUT",
        url: `/api/education-levels/${selectedLevel.id}`,
        data: formData
      });

      if (response) {
        setEducationLevels(prev => 
          prev.map(level => level.id === selectedLevel.id ? response as EducationLevel : level)
        );
        setIsEditDialogOpen(false);
        resetForm();

        toast({
          title: "Sucesso",
          description: "Nível de ensino atualizado com sucesso.",
        });
      }
    } catch (error) {
      console.error("Error updating education level:", error);
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o nível de ensino.",
        variant: "destructive"
      });
    }
  };

  // Delete education level
  const handleDeleteLevel = async () => {
    if (!selectedLevelId) return;

    try {
      await apiRequest({
        method: "DELETE",
        url: `/api/education-levels/${selectedLevelId}`
      });

      setEducationLevels(prev => 
        prev.filter(level => level.id !== selectedLevelId)
      );
      setIsDeleteDialogOpen(false);
      setSelectedLevelId(null);

      toast({
        title: "Sucesso",
        description: "Nível de ensino excluído com sucesso.",
      });
    } catch (error: any) {
      console.error("Error deleting education level:", error);
      toast({
        title: "Erro",
        description: error.message || "Não foi possível excluir o nível de ensino.",
        variant: "destructive"
      });
    }
  };

  // Ordenar níveis de ensino por levelOrder
  const sortedLevels = [...educationLevels].sort((a, b) => a.levelOrder - b.levelOrder);
  
  // Função para carregar as classes de um nível de ensino
  const handleViewClasses = async (levelId: number) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/classes?educationLevelId=${levelId}`);
      const data = await response.json();
      
      // Encontrar o nome do nível de ensino selecionado
      const level = educationLevels.find(level => level.id === levelId);
      if (level) {
        setCurrentLevelName(level.name);
      }
      
      if (Array.isArray(data)) {
        setCurrentLevelClasses(data);
        setClassFormData(prev => ({
          ...prev,
          educationLevelId: levelId
        }));
        setIsViewClassesDialogOpen(true);
      } else {
        console.error("Resposta da API não é um array:", data);
        toast({
          title: "Erro",
          description: "Não foi possível carregar as classes.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Erro ao carregar classes:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar as classes.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Função para abrir o modal de adicionar classe
  const handleAddClassClick = () => {
    const currentEducationLevelId = educationLevels.find(level => level.name === currentLevelName)?.id || 0;
    
    setClassFormData({
      name: "",
      year: new Date().getFullYear(),
      semester: "1º Semestre",
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)),
      description: "",
      status: "active",
      maxStudents: 30,
      educationLevelId: currentEducationLevelId
    });
    setIsAddClassDialogOpen(true);
  };
  
  // Função para abrir o modal de editar classe
  const handleEditClassClick = (classItem: Class) => {
    setSelectedClass(classItem);
    setClassFormData({
      name: classItem.name,
      year: classItem.year,
      semester: classItem.semester,
      startDate: new Date(classItem.startDate),
      endDate: new Date(classItem.endDate),
      description: classItem.description || "",
      status: classItem.status,
      maxStudents: classItem.maxStudents,
      educationLevelId: classItem.educationLevelId
    });
    setIsEditClassDialogOpen(true);
  };
  
  // Função para abrir o modal de excluir classe
  const handleDeleteClassClick = (classId: number) => {
    setSelectedClassId(classId);
    setIsDeleteClassDialogOpen(true);
  };
  
  // Função para lidar com mudanças nos campos do formulário de classe
  const handleClassInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setClassFormData(prev => ({
      ...prev,
      [name]: name === "year" || name === "maxStudents" ? parseInt(value) || 0 : value
    }));
  };
  
  // Função para lidar com mudanças nas datas
  const handleDateChange = (date: Date | undefined, field: 'startDate' | 'endDate') => {
    if (date) {
      setClassFormData(prev => ({
        ...prev,
        [field]: date
      }));
    }
  };
  
  // Função para criar uma nova classe
  const handleCreateClass = async () => {
    try {
      const formattedData = {
        ...classFormData,
        startDate: classFormData.startDate.toISOString().split('T')[0],
        endDate: classFormData.endDate.toISOString().split('T')[0]
      };
      
      const response = await fetch('/api/classes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formattedData)
      });
      
      if (!response.ok) {
        throw new Error('Falha ao criar classe');
      }
      
      const newClass = await response.json();
      
      setCurrentLevelClasses(prev => [...prev, newClass]);
      setIsAddClassDialogOpen(false);
      
      toast({
        title: "Sucesso",
        description: "Classe criada com sucesso.",
      });
      
      // Atualizar a contagem de classes no nível de ensino
      handleViewClasses(classFormData.educationLevelId);
    } catch (error) {
      console.error("Erro ao criar classe:", error);
      toast({
        title: "Erro",
        description: "Não foi possível criar a classe.",
        variant: "destructive"
      });
    }
  };
  
  // Função para atualizar uma classe
  const handleUpdateClass = async () => {
    if (!selectedClass) return;
    
    try {
      const formattedData = {
        ...classFormData,
        startDate: classFormData.startDate.toISOString().split('T')[0],
        endDate: classFormData.endDate.toISOString().split('T')[0]
      };
      
      const response = await fetch(`/api/classes/${selectedClass.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formattedData)
      });
      
      if (!response.ok) {
        throw new Error('Falha ao atualizar classe');
      }
      
      const updatedClass = await response.json();
      
      setCurrentLevelClasses(prev => 
        prev.map(cls => cls.id === selectedClass.id ? updatedClass : cls)
      );
      setIsEditClassDialogOpen(false);
      
      toast({
        title: "Sucesso",
        description: "Classe atualizada com sucesso.",
      });
    } catch (error) {
      console.error("Erro ao atualizar classe:", error);
      toast({
        title: "Erro",
        description: "Não foi possível atualizar a classe.",
        variant: "destructive"
      });
    }
  };
  
  // Função para excluir uma classe
  const handleDeleteClass = async () => {
    if (!selectedClassId) return;
    
    try {
      const response = await fetch(`/api/classes/${selectedClassId}`, {
        method: 'DELETE'
      });
      
      if (!response.ok) {
        throw new Error('Falha ao excluir classe');
      }
      
      setCurrentLevelClasses(prev => 
        prev.filter(cls => cls.id !== selectedClassId)
      );
      setIsDeleteClassDialogOpen(false);
      setSelectedClassId(null);
      
      toast({
        title: "Sucesso",
        description: "Classe excluída com sucesso.",
      });
    } catch (error) {
      console.error("Erro ao excluir classe:", error);
      toast({
        title: "Erro",
        description: "Não foi possível excluir a classe.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Níveis de Ensino</h2>
        <Button onClick={handleAddClick}>
          <Plus className="h-4 w-4 mr-2" />
          Adicionar Nível
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Níveis de Ensino</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <p>Carregando níveis de ensino...</p>
            </div>
          ) : educationLevels.length === 0 ? (
            <div className="text-center p-4">
              <p>Nenhum nível de ensino cadastrado.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Ordem</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {educationLevels.map(level => (
                  <TableRow key={level.id}>
                    <TableCell className="font-medium">{level.name}</TableCell>
                    <TableCell>{level.levelOrder}</TableCell>
                    <TableCell>{level.description || "-"}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${level.active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                        {level.active ? "Ativo" : "Inativo"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right flex justify-end items-center space-x-1">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 px-2 py-0"
                        onClick={() => handleViewClasses(level.id)}
                      >
                        Ver Classes {level.classCount && level.classCount > 0 && <span className="ml-1 bg-red-500 text-white rounded-full h-5 w-5 flex items-center justify-center text-xs">{level.classCount}</span>}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditClick(level)}
                      >
                        <Pencil className="h-4 w-4" />
                        <span className="sr-only">Editar</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteClick(level.id)}
                      >
                        <Trash className="h-4 w-4" />
                        <span className="sr-only">Excluir</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Add Education Level Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Nível de Ensino</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Ex: Ensino Fundamental"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                placeholder="Descreva o nível de ensino"
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="levelOrder">Ordem</Label>
              <Input
                id="levelOrder"
                name="levelOrder"
                type="number"
                min="1"
                value={formData.levelOrder}
                onChange={handleInputChange}
              />
              <p className="text-sm text-muted-foreground">
                A ordem determina a posição de exibição do nível.
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="active"
                checked={formData.active}
                onCheckedChange={handleSwitchChange}
              />
              <Label htmlFor="active">Ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreateLevel}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Education Level Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Nível de Ensino</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Nome</Label>
              <Input
                id="edit-name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Descrição</Label>
              <Textarea
                id="edit-description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-levelOrder">Ordem</Label>
              <Input
                id="edit-levelOrder"
                name="levelOrder"
                type="number"
                min="1"
                value={formData.levelOrder}
                onChange={handleInputChange}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="edit-active"
                checked={formData.active}
                onCheckedChange={handleSwitchChange}
              />
              <Label htmlFor="edit-active">Ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleUpdateLevel}>Atualizar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este nível de ensino? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteLevel}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Modal para visualizar classes de um nível de ensino */}
      <Dialog open={isViewClassesDialogOpen} onOpenChange={setIsViewClassesDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Classes do {currentLevelName}</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Lista de Classes</h3>
              <Button onClick={handleAddClassClick}>
                <Plus className="h-4 w-4 mr-2" />
                Nova Classe
              </Button>
            </div>
            
            {currentLevelClasses.length === 0 ? (
              <div className="text-center p-8 border rounded-md bg-muted/20">
                <p>Nenhuma classe cadastrada para este nível de ensino.</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={handleAddClassClick}
                >
                  Adicionar Classe
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="font-semibold text-sm pl-10">
                  📚 Classes do {currentLevelName}
                </div>
                {currentLevelClasses.map(classItem => (
                  <div 
                    key={classItem.id} 
                    className="flex items-center p-2 border rounded-md hover:bg-muted/20"
                  >
                    <div className="flex-1 pl-2">
                      - {classItem.name} 
                    </div>
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditClassClick(classItem)}
                      >
                        <FileEdit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteClassClick(classItem.id)}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                <div className="pt-2 pl-10">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleAddClassClick}
                  >
                    [ + Nova Classe ]
                  </Button>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViewClassesDialogOpen(false)}>
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para adicionar classe */}
      <Dialog open={isAddClassDialogOpen} onOpenChange={setIsAddClassDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Classe</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome da Classe</Label>
              <Input
                id="name"
                name="name"
                value={classFormData.name}
                onChange={handleClassInputChange}
                placeholder="Ex: 1ª classe"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="year">Ano</Label>
                <Input
                  id="year"
                  name="year"
                  type="number"
                  value={classFormData.year}
                  onChange={handleClassInputChange}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="semester">Semestre</Label>
                <Input
                  id="semester"
                  name="semester"
                  value={classFormData.semester}
                  onChange={handleClassInputChange}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="maxStudents">Máximo de Alunos</Label>
                <Input
                  id="maxStudents"
                  name="maxStudents"
                  type="number"
                  value={classFormData.maxStudents}
                  onChange={handleClassInputChange}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <select
                  id="status"
                  name="status"
                  value={classFormData.status}
                  onChange={handleClassInputChange as any}
                  className="w-full p-2 border rounded"
                >
                  <option value="active">Ativo</option>
                  <option value="inactive">Inativo</option>
                  <option value="planned">Planejado</option>
                  <option value="completed">Concluído</option>
                </select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                name="description"
                value={classFormData.description}
                onChange={handleClassInputChange}
                placeholder="Descreva a classe"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddClassDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreateClass}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para editar classe */}
      <Dialog open={isEditClassDialogOpen} onOpenChange={setIsEditClassDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Classe</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Nome da Classe</Label>
              <Input
                id="edit-name"
                name="name"
                value={classFormData.name}
                onChange={handleClassInputChange}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-year">Ano</Label>
                <Input
                  id="edit-year"
                  name="year"
                  type="number"
                  value={classFormData.year}
                  onChange={handleClassInputChange}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-semester">Semestre</Label>
                <Input
                  id="edit-semester"
                  name="semester"
                  value={classFormData.semester}
                  onChange={handleClassInputChange}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-maxStudents">Máximo de Alunos</Label>
                <Input
                  id="edit-maxStudents"
                  name="maxStudents"
                  type="number"
                  value={classFormData.maxStudents}
                  onChange={handleClassInputChange}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-status">Status</Label>
                <select
                  id="edit-status"
                  name="status"
                  value={classFormData.status}
                  onChange={handleClassInputChange as any}
                  className="w-full p-2 border rounded"
                >
                  <option value="active">Ativo</option>
                  <option value="inactive">Inativo</option>
                  <option value="planned">Planejado</option>
                  <option value="completed">Concluído</option>
                </select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edit-description">Descrição</Label>
              <Textarea
                id="edit-description"
                name="description"
                value={classFormData.description}
                onChange={handleClassInputChange}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditClassDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleUpdateClass}>Atualizar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para confirmar exclusão de classe */}
      <AlertDialog open={isDeleteClassDialogOpen} onOpenChange={setIsDeleteClassDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta classe? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteClass}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default EducationLevelsTab;