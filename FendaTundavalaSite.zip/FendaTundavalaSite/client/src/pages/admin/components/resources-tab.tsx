import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Resource } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

export default function ResourcesTab() {
  const { toast } = useToast();
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Carregar recursos da API
    fetch('/api/resources')
      .then(response => {
        if (!response.ok) {
          throw new Error('Falha ao carregar recursos');
        }
        return response.json();
      })
      .then(data => {
        setResources(data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Erro ao buscar recursos:', error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os recursos da biblioteca.",
          variant: "destructive"
        });
        setLoading(false);
      });
  }, [toast]);

  const handleResourceAction = (action: string, resourceId: number) => {
    if (action === "delete") {
      toast({
        title: "Remover recurso",
        description: "Esta funcionalidade será implementada em breve."
      });
    } else if (action === "edit") {
      toast({
        title: "Editar recurso",
        description: "Esta funcionalidade será implementada em breve."
      });
    } else if (action === "toggle-featured") {
      toast({
        title: "Alternar destaque",
        description: "Esta funcionalidade será implementada em breve."
      });
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Gerenciar Recursos da Biblioteca</CardTitle>
        <Button onClick={() => toast({
          title: "Novo recurso",
          description: "Funcionalidade em desenvolvimento."
        })}>
          Adicionar Recurso
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <p>Carregando recursos...</p>
          </div>
        ) : (
          <>
            {resources.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-gray-500">Nenhum recurso encontrado.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Título</TableHead>
                      <TableHead>Autor</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Destaque</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {resources.map(resource => (
                      <TableRow key={resource.id}>
                        <TableCell>{resource.id}</TableCell>
                        <TableCell className="font-medium">{resource.title}</TableCell>
                        <TableCell>{resource.author}</TableCell>
                        <TableCell>{resource.type}</TableCell>
                        <TableCell>{resource.category}</TableCell>
                        <TableCell>
                          {resource.featured ? (
                            <Badge className="bg-yellow-500">Destaque</Badge>
                          ) : (
                            <Badge variant="outline">Normal</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleResourceAction("edit", resource.id)}
                            >
                              Editar
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleResourceAction("toggle-featured", resource.id)}
                            >
                              {resource.featured ? "Remover destaque" : "Destacar"}
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleResourceAction("delete", resource.id)}
                            >
                              Excluir
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}