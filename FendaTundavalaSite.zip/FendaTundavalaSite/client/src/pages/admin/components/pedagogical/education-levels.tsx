import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Pencil, Plus, Trash } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { EducationLevel } from "@/lib/types";

// Form data type
interface EducationLevelFormData {
  name: string;
  description: string;
  levelOrder: number;
  active: boolean;
}

export default function EducationLevelsTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedLevelId, setSelectedLevelId] = useState<number | null>(null);
  const [formData, setFormData] = useState<EducationLevelFormData>({
    name: "",
    description: "",
    levelOrder: 1,
    active: true
  });

  // Fetch education levels
  const { data: educationLevels = [], isLoading } = useQuery({
    queryKey: ['/api/education-levels'],
    queryFn: async () => {
      const response = await apiRequest('/api/education-levels');
      return response as unknown as EducationLevel[];
    }
  });

  // Handlers for CRUD operations
  const handleAddLevel = async () => {
    try {
      await apiRequest('/api/education-levels', {
        method: 'POST',
        data: formData
      });
      
      toast({
        title: "Nível de ensino adicionado",
        description: "O nível de ensino foi criado com sucesso."
      });
      
      setIsAddDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['/api/education-levels'] });
    } catch (error) {
      toast({
        title: "Erro ao adicionar",
        description: "Não foi possível adicionar o nível de ensino.",
        variant: "destructive"
      });
    }
  };

  const handleEditLevel = async () => {
    if (!selectedLevelId) return;
    
    try {
      await apiRequest(`/api/education-levels/${selectedLevelId}`, {
        method: 'PATCH',
        data: formData
      });
      
      toast({
        title: "Nível de ensino atualizado",
        description: "As alterações foram salvas com sucesso."
      });
      
      setIsEditDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['/api/education-levels'] });
    } catch (error) {
      toast({
        title: "Erro ao atualizar",
        description: "Não foi possível atualizar o nível de ensino.",
        variant: "destructive"
      });
    }
  };

  const handleDeleteLevel = async () => {
    if (!selectedLevelId) return;
    
    try {
      await apiRequest(`/api/education-levels/${selectedLevelId}`, {
        method: 'DELETE'
      });
      
      toast({
        title: "Nível de ensino excluído",
        description: "O nível de ensino foi removido com sucesso."
      });
      
      setIsDeleteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/education-levels'] });
    } catch (error) {
      toast({
        title: "Erro ao excluir",
        description: "Não foi possível excluir o nível de ensino.",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      levelOrder: 1,
      active: true
    });
    setSelectedLevelId(null);
  };

  const openEditDialog = (level: EducationLevel) => {
    setSelectedLevelId(level.id);
    setFormData({
      name: level.name,
      description: level.description,
      levelOrder: level.levelOrder,
      active: level.active
    });
    setIsEditDialogOpen(true);
  };

  const confirmDelete = (id: number) => {
    setSelectedLevelId(id);
    setIsDeleteDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end mb-4">
        <Button 
          onClick={() => {
            resetForm();
            setIsAddDialogOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" />
          Adicionar Nível
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <p>Carregando níveis de ensino...</p>
            </div>
          ) : educationLevels.length === 0 ? (
            <div className="text-center p-4">
              <p>Nenhum nível de ensino cadastrado.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Ordem</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {educationLevels.map(level => (
                  <TableRow key={level.id}>
                    <TableCell className="font-medium">{level.name}</TableCell>
                    <TableCell>{level.levelOrder}</TableCell>
                    <TableCell>{level.description || "-"}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${level.active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                        {level.active ? "Ativo" : "Inativo"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => openEditDialog(level)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => confirmDelete(level.id)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Diálogo para adicionar nível */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Nível de Ensino</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Ex: Ensino Médio"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Descrição do nível de ensino"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="levelOrder">Ordem</Label>
              <Input
                id="levelOrder"
                type="number"
                min="1"
                value={formData.levelOrder}
                onChange={(e) => setFormData({...formData, levelOrder: parseInt(e.target.value)})}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="active"
                checked={formData.active}
                onCheckedChange={(checked) => setFormData({...formData, active: checked})}
              />
              <Label htmlFor="active">Ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleAddLevel}>Adicionar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para editar nível */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Nível de Ensino</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name-edit">Nome</Label>
              <Input
                id="name-edit"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description-edit">Descrição</Label>
              <Textarea
                id="description-edit"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="levelOrder-edit">Ordem</Label>
              <Input
                id="levelOrder-edit"
                type="number"
                min="1"
                value={formData.levelOrder}
                onChange={(e) => setFormData({...formData, levelOrder: parseInt(e.target.value)})}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="active-edit"
                checked={formData.active}
                onCheckedChange={(checked) => setFormData({...formData, active: checked})}
              />
              <Label htmlFor="active-edit">Ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleEditLevel}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para confirmar exclusão */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este nível de ensino? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteLevel}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}