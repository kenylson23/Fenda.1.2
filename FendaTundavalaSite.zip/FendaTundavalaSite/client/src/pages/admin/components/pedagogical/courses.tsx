import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pencil, Plus, Trash } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { EducationLevel } from "@/lib/types";

// Tipo para representar um curso
interface Course {
  id: number;
  name: string;
  code: string;
  description: string;
  educationLevelId: number;
  duration: string;
  coordinator: string;
  active: boolean;
  createdAt?: string;
}

// Tipo para o formulário de curso
interface CourseFormData {
  name: string;
  code: string;
  description: string;
  educationLevelId: number;
  duration: string;
  coordinator: string;
  active: boolean;
}

export default function CoursesTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedCourseId, setSelectedCourseId] = useState<number | null>(null);
  const [formData, setFormData] = useState<CourseFormData>({
    name: "",
    code: "",
    description: "",
    educationLevelId: 0,
    duration: "",
    coordinator: "",
    active: true
  });

  // Buscar cursos
  const { data: courses = [], isLoading } = useQuery({
    queryKey: ['/api/courses'],
    queryFn: async () => {
      const response = await apiRequest('/api/courses');
      return response as unknown as Course[];
    }
  });

  // Buscar níveis de ensino para o select
  const { data: educationLevels = [] } = useQuery({
    queryKey: ['/api/education-levels'],
    queryFn: async () => {
      const response = await apiRequest('/api/education-levels');
      return response as unknown as EducationLevel[];
    }
  });

  // Handlers para operações CRUD
  const handleAddCourse = async () => {
    try {
      await apiRequest('/api/courses', {
        method: 'POST',
        data: formData
      });
      
      toast({
        title: "Curso adicionado",
        description: "O curso foi criado com sucesso."
      });
      
      setIsAddDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
    } catch (error) {
      toast({
        title: "Erro ao adicionar",
        description: "Não foi possível adicionar o curso.",
        variant: "destructive"
      });
    }
  };

  const handleEditCourse = async () => {
    if (!selectedCourseId) return;
    
    try {
      await apiRequest(`/api/courses/${selectedCourseId}`, {
        method: 'PATCH',
        data: formData
      });
      
      toast({
        title: "Curso atualizado",
        description: "As alterações foram salvas com sucesso."
      });
      
      setIsEditDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
    } catch (error) {
      toast({
        title: "Erro ao atualizar",
        description: "Não foi possível atualizar o curso.",
        variant: "destructive"
      });
    }
  };

  const handleDeleteCourse = async () => {
    if (!selectedCourseId) return;
    
    try {
      await apiRequest(`/api/courses/${selectedCourseId}`, {
        method: 'DELETE'
      });
      
      toast({
        title: "Curso excluído",
        description: "O curso foi removido com sucesso."
      });
      
      setIsDeleteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
    } catch (error) {
      toast({
        title: "Erro ao excluir",
        description: "Não foi possível excluir o curso.",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      code: "",
      description: "",
      educationLevelId: 0,
      duration: "",
      coordinator: "",
      active: true
    });
    setSelectedCourseId(null);
  };

  const openEditDialog = (course: Course) => {
    setSelectedCourseId(course.id);
    setFormData({
      name: course.name,
      code: course.code,
      description: course.description,
      educationLevelId: course.educationLevelId,
      duration: course.duration,
      coordinator: course.coordinator,
      active: course.active
    });
    setIsEditDialogOpen(true);
  };

  const confirmDelete = (id: number) => {
    setSelectedCourseId(id);
    setIsDeleteDialogOpen(true);
  };

  // Função para encontrar o nome do nível de ensino pelo ID
  const getEducationLevelName = (levelId: number) => {
    const level = educationLevels.find(level => level.id === levelId);
    return level ? level.name : "Desconhecido";
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end mb-4">
        <Button 
          onClick={() => {
            resetForm();
            setIsAddDialogOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" />
          Adicionar Curso
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <p>Carregando cursos...</p>
            </div>
          ) : courses.length === 0 ? (
            <div className="text-center p-4">
              <p>Nenhum curso cadastrado.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Código</TableHead>
                  <TableHead>Nome</TableHead>
                  <TableHead>Nível de Ensino</TableHead>
                  <TableHead>Duração</TableHead>
                  <TableHead>Coordenador</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {courses.map(course => (
                  <TableRow key={course.id}>
                    <TableCell>{course.code}</TableCell>
                    <TableCell className="font-medium">{course.name}</TableCell>
                    <TableCell>{getEducationLevelName(course.educationLevelId)}</TableCell>
                    <TableCell>{course.duration}</TableCell>
                    <TableCell>{course.coordinator || "-"}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${course.active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                        {course.active ? "Ativo" : "Inativo"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => openEditDialog(course)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => confirmDelete(course.id)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Diálogo para adicionar curso */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar Curso</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="code">Código do Curso</Label>
              <Input
                id="code"
                value={formData.code}
                onChange={(e) => setFormData({...formData, code: e.target.value})}
                placeholder="Ex: ENG001"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Nome do Curso</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Ex: Engenharia Civil"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Descrição do curso"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="educationLevel">Nível de Ensino</Label>
              <Select 
                value={formData.educationLevelId.toString()} 
                onValueChange={(value) => setFormData({...formData, educationLevelId: parseInt(value)})}
              >
                <SelectTrigger id="educationLevel">
                  <SelectValue placeholder="Selecione o nível de ensino" />
                </SelectTrigger>
                <SelectContent>
                  {educationLevels.map(level => (
                    <SelectItem key={level.id} value={level.id.toString()}>
                      {level.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration">Duração</Label>
              <Input
                id="duration"
                value={formData.duration}
                onChange={(e) => setFormData({...formData, duration: e.target.value})}
                placeholder="Ex: 4 anos"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="coordinator">Coordenador</Label>
              <Input
                id="coordinator"
                value={formData.coordinator}
                onChange={(e) => setFormData({...formData, coordinator: e.target.value})}
                placeholder="Nome do coordenador"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="active"
                checked={formData.active}
                onCheckedChange={(checked) => setFormData({...formData, active: checked})}
              />
              <Label htmlFor="active">Ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleAddCourse}>Adicionar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para editar curso */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Curso</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="code-edit">Código do Curso</Label>
              <Input
                id="code-edit"
                value={formData.code}
                onChange={(e) => setFormData({...formData, code: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name-edit">Nome do Curso</Label>
              <Input
                id="name-edit"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description-edit">Descrição</Label>
              <Textarea
                id="description-edit"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="educationLevel-edit">Nível de Ensino</Label>
              <Select 
                value={formData.educationLevelId.toString()} 
                onValueChange={(value) => setFormData({...formData, educationLevelId: parseInt(value)})}
              >
                <SelectTrigger id="educationLevel-edit">
                  <SelectValue placeholder="Selecione o nível de ensino" />
                </SelectTrigger>
                <SelectContent>
                  {educationLevels.map(level => (
                    <SelectItem key={level.id} value={level.id.toString()}>
                      {level.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration-edit">Duração</Label>
              <Input
                id="duration-edit"
                value={formData.duration}
                onChange={(e) => setFormData({...formData, duration: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="coordinator-edit">Coordenador</Label>
              <Input
                id="coordinator-edit"
                value={formData.coordinator}
                onChange={(e) => setFormData({...formData, coordinator: e.target.value})}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="active-edit"
                checked={formData.active}
                onCheckedChange={(checked) => setFormData({...formData, active: checked})}
              />
              <Label htmlFor="active-edit">Ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleEditCourse}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para confirmar exclusão */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este curso? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteCourse}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}