import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarIcon, Pencil, Plus, Trash, UserPlus, Users, BookOpen } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

// Tipos para representar uma turma e entidades relacionadas
interface Class {
  id: number;
  name: string;
  year: number;
  semester: string;
  startDate: string;
  endDate: string;
  description: string;
  status: string;
  maxStudents: number;
  educationLevelId: number;
  courseId: number;
  createdAt?: string;
}

interface ClassFormData {
  name: string;
  year: number;
  semester: string;
  startDate: Date;
  endDate: Date;
  description: string;
  status: string;
  maxStudents: number;
  educationLevelId: number;
  courseId: number;
}

interface EducationLevel {
  id: number;
  name: string;
}

interface Course {
  id: number;
  name: string;
  educationLevelId: number;
}

interface Teacher {
  id: number;
  name: string;
  department: string;
}

interface Student {
  id: number;
  name: string;
  enrollmentNumber: string;
}

interface Subject {
  id: number;
  name: string;
  description: string;
  credits: number;
  schedule: string;
}

export default function ClassesTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isManageTeachersDialogOpen, setIsManageTeachersDialogOpen] = useState(false);
  const [isManageStudentsDialogOpen, setIsManageStudentsDialogOpen] = useState(false);
  const [isManageSubjectsDialogOpen, setIsManageSubjectsDialogOpen] = useState(false);
  const [selectedClassId, setSelectedClassId] = useState<number | null>(null);
  const [selectedTeachers, setSelectedTeachers] = useState<number[]>([]);
  const [selectedStudents, setSelectedStudents] = useState<number[]>([]);
  const [subjectForm, setSubjectForm] = useState({
    name: "",
    description: "",
    credits: 4,
    schedule: ""
  });
  const [formData, setFormData] = useState<ClassFormData>({
    name: "",
    year: new Date().getFullYear(),
    semester: "1º Semestre",
    startDate: new Date(),
    endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)),
    description: "",
    status: "active",
    maxStudents: 30,
    educationLevelId: 0,
    courseId: 0
  });

  // Consultas para buscar dados
  const { data: classes = [], isLoading } = useQuery({
    queryKey: ['/api/classes'],
    queryFn: async () => {
      const response = await apiRequest('/api/classes');
      return response as unknown as Class[];
    }
  });

  const { data: educationLevels = [] } = useQuery({
    queryKey: ['/api/education-levels'],
    queryFn: async () => {
      const response = await apiRequest('/api/education-levels');
      return response as unknown as EducationLevel[];
    }
  });

  const { data: courses = [] } = useQuery({
    queryKey: ['/api/courses'],
    queryFn: async () => {
      const response = await apiRequest('/api/courses');
      return response as unknown as Course[];
    }
  });

  const { data: teachers = [], isLoading: isLoadingTeachers } = useQuery({
    queryKey: ['/api/teachers'],
    queryFn: async () => {
      const response = await apiRequest('/api/teachers');
      return response as unknown as Teacher[];
    }
  });

  const { data: students = [], isLoading: isLoadingStudents } = useQuery({
    queryKey: ['/api/students'],
    queryFn: async () => {
      const response = await apiRequest('/api/students');
      return response as unknown as Student[];
    }
  });

  const { data: classTeachers = [] } = useQuery({
    queryKey: ['/api/classes', selectedClassId, 'teachers'],
    queryFn: async () => {
      if (!selectedClassId) return [];
      const response = await apiRequest(`/api/classes/${selectedClassId}/teachers`);
      return response as unknown as Teacher[];
    },
    enabled: !!selectedClassId && isManageTeachersDialogOpen
  });

  const { data: classStudents = [] } = useQuery({
    queryKey: ['/api/classes', selectedClassId, 'students'],
    queryFn: async () => {
      if (!selectedClassId) return [];
      const response = await apiRequest(`/api/classes/${selectedClassId}/students`);
      return response as unknown as Student[];
    },
    enabled: !!selectedClassId && isManageStudentsDialogOpen
  });

  const { data: classSubjects = [] } = useQuery({
    queryKey: ['/api/classes', selectedClassId, 'subjects'],
    queryFn: async () => {
      if (!selectedClassId) return [];
      const response = await apiRequest(`/api/classes/${selectedClassId}/subjects`);
      return response as unknown as Subject[];
    },
    enabled: !!selectedClassId && isManageSubjectsDialogOpen
  });

  // Handlers para operações CRUD
  const handleAddClass = async () => {
    try {
      const payload = {
        ...formData,
        startDate: formData.startDate.toISOString(),
        endDate: formData.endDate.toISOString()
      };
      
      await apiRequest('/api/classes', {
        method: 'POST',
        data: payload
      });
      
      toast({
        title: "Turma adicionada",
        description: "A turma foi criada com sucesso."
      });
      
      setIsAddDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['/api/classes'] });
    } catch (error) {
      toast({
        title: "Erro ao adicionar",
        description: "Não foi possível adicionar a turma.",
        variant: "destructive"
      });
    }
  };

  const handleEditClass = async () => {
    if (!selectedClassId) return;
    
    try {
      const payload = {
        ...formData,
        startDate: formData.startDate.toISOString(),
        endDate: formData.endDate.toISOString()
      };
      
      await apiRequest(`/api/classes/${selectedClassId}`, {
        method: 'PATCH',
        data: payload
      });
      
      toast({
        title: "Turma atualizada",
        description: "As alterações foram salvas com sucesso."
      });
      
      setIsEditDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['/api/classes'] });
    } catch (error) {
      toast({
        title: "Erro ao atualizar",
        description: "Não foi possível atualizar a turma.",
        variant: "destructive"
      });
    }
  };

  const handleDeleteClass = async () => {
    if (!selectedClassId) return;
    
    try {
      await apiRequest(`/api/classes/${selectedClassId}`, {
        method: 'DELETE'
      });
      
      toast({
        title: "Turma excluída",
        description: "A turma foi removida com sucesso."
      });
      
      setIsDeleteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/classes'] });
    } catch (error) {
      toast({
        title: "Erro ao excluir",
        description: "Não foi possível excluir a turma.",
        variant: "destructive"
      });
    }
  };

  // Funções para gerenciar professores
  const handleAddTeachersToClass = async () => {
    if (!selectedClassId || selectedTeachers.length === 0) return;
    
    try {
      await apiRequest(`/api/classes/${selectedClassId}/teachers`, {
        method: 'POST',
        data: { teacherIds: selectedTeachers }
      });
      
      toast({
        title: "Professores adicionados",
        description: "Os professores foram adicionados à turma com sucesso."
      });
      
      setSelectedTeachers([]);
      queryClient.invalidateQueries({ queryKey: ['/api/classes', selectedClassId, 'teachers'] });
    } catch (error) {
      toast({
        title: "Erro ao adicionar professores",
        description: "Não foi possível adicionar os professores à turma.",
        variant: "destructive"
      });
    }
  };

  const handleRemoveTeacherFromClass = async (teacherId: number) => {
    if (!selectedClassId) return;
    
    try {
      await apiRequest(`/api/classes/${selectedClassId}/teachers/${teacherId}`, {
        method: 'DELETE'
      });
      
      toast({
        title: "Professor removido",
        description: "O professor foi removido da turma com sucesso."
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/classes', selectedClassId, 'teachers'] });
    } catch (error) {
      toast({
        title: "Erro ao remover professor",
        description: "Não foi possível remover o professor da turma.",
        variant: "destructive"
      });
    }
  };

  // Funções para gerenciar alunos
  const handleAddStudentsToClass = async () => {
    if (!selectedClassId || selectedStudents.length === 0) return;
    
    try {
      await apiRequest(`/api/classes/${selectedClassId}/students`, {
        method: 'POST',
        data: { studentIds: selectedStudents }
      });
      
      toast({
        title: "Alunos adicionados",
        description: "Os alunos foram adicionados à turma com sucesso."
      });
      
      setSelectedStudents([]);
      queryClient.invalidateQueries({ queryKey: ['/api/classes', selectedClassId, 'students'] });
    } catch (error) {
      toast({
        title: "Erro ao adicionar alunos",
        description: "Não foi possível adicionar os alunos à turma.",
        variant: "destructive"
      });
    }
  };

  const handleRemoveStudentFromClass = async (studentId: number) => {
    if (!selectedClassId) return;
    
    try {
      await apiRequest(`/api/classes/${selectedClassId}/students/${studentId}`, {
        method: 'DELETE'
      });
      
      toast({
        title: "Aluno removido",
        description: "O aluno foi removido da turma com sucesso."
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/classes', selectedClassId, 'students'] });
    } catch (error) {
      toast({
        title: "Erro ao remover aluno",
        description: "Não foi possível remover o aluno da turma.",
        variant: "destructive"
      });
    }
  };

  // Funções para gerenciar disciplinas
  const handleAddSubjectToClass = async () => {
    if (!selectedClassId || !subjectForm.name || !subjectForm.schedule) return;
    
    try {
      await apiRequest(`/api/classes/${selectedClassId}/subjects`, {
        method: 'POST',
        data: subjectForm
      });
      
      toast({
        title: "Disciplina adicionada",
        description: "A disciplina foi adicionada à turma com sucesso."
      });
      
      setSubjectForm({
        name: "",
        description: "",
        credits: 4,
        schedule: ""
      });
      queryClient.invalidateQueries({ queryKey: ['/api/classes', selectedClassId, 'subjects'] });
    } catch (error) {
      toast({
        title: "Erro ao adicionar disciplina",
        description: "Não foi possível adicionar a disciplina à turma.",
        variant: "destructive"
      });
    }
  };

  const handleRemoveSubjectFromClass = async (subjectId: number) => {
    if (!selectedClassId) return;
    
    try {
      await apiRequest(`/api/classes/${selectedClassId}/subjects/${subjectId}`, {
        method: 'DELETE'
      });
      
      toast({
        title: "Disciplina removida",
        description: "A disciplina foi removida da turma com sucesso."
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/classes', selectedClassId, 'subjects'] });
    } catch (error) {
      toast({
        title: "Erro ao remover disciplina",
        description: "Não foi possível remover a disciplina da turma.",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      year: new Date().getFullYear(),
      semester: "1º Semestre",
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)),
      description: "",
      status: "active",
      maxStudents: 30,
      educationLevelId: 0,
      courseId: 0
    });
    setSelectedClassId(null);
  };

  const openEditDialog = (classItem: Class) => {
    setSelectedClassId(classItem.id);
    setFormData({
      name: classItem.name,
      year: classItem.year,
      semester: classItem.semester,
      startDate: new Date(classItem.startDate),
      endDate: new Date(classItem.endDate),
      description: classItem.description,
      status: classItem.status,
      maxStudents: classItem.maxStudents,
      educationLevelId: classItem.educationLevelId,
      courseId: classItem.courseId
    });
    setIsEditDialogOpen(true);
  };

  const confirmDelete = (id: number) => {
    setSelectedClassId(id);
    setIsDeleteDialogOpen(true);
  };

  const handleManageTeachers = (id: number) => {
    setSelectedClassId(id);
    setIsManageTeachersDialogOpen(true);
  };

  const handleManageStudents = (id: number) => {
    setSelectedClassId(id);
    setIsManageStudentsDialogOpen(true);
  };

  const handleManageSubjects = (id: number) => {
    setSelectedClassId(id);
    setIsManageSubjectsDialogOpen(true);
  };

  // Função para encontrar o nome do nível de ensino pelo ID
  const getEducationLevelName = (levelId: number) => {
    const level = educationLevels.find(level => level.id === levelId);
    return level ? level.name : "Desconhecido";
  };

  // Função para encontrar o nome do curso pelo ID
  const getCourseName = (courseId: number) => {
    const course = courses.find(course => course.id === courseId);
    return course ? course.name : "Desconhecido";
  };

  // Filtrar cursos por nível de ensino
  const filteredCourses = formData.educationLevelId 
    ? courses.filter(course => course.educationLevelId === formData.educationLevelId)
    : courses;

  return (
    <div className="space-y-6">
      <div className="flex justify-end mb-4">
        <Button 
          onClick={() => {
            resetForm();
            setIsAddDialogOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" />
          Adicionar Turma
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <p>Carregando turmas...</p>
            </div>
          ) : classes.length === 0 ? (
            <div className="text-center p-4">
              <p>Nenhuma turma cadastrada.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Curso</TableHead>
                  <TableHead>Período</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Alunos</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {classes.map(classItem => (
                  <TableRow key={classItem.id}>
                    <TableCell className="font-medium">{classItem.name}</TableCell>
                    <TableCell>{getCourseName(classItem.courseId)}</TableCell>
                    <TableCell>{classItem.year} - {classItem.semester}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        classItem.status === "active" 
                          ? "bg-green-100 text-green-800" 
                          : classItem.status === "planned" 
                            ? "bg-blue-100 text-blue-800"
                            : "bg-red-100 text-red-800"
                      }`}>
                        {classItem.status === "active" 
                          ? "Ativa" 
                          : classItem.status === "planned" 
                            ? "Planejada"
                            : "Encerrada"
                        }
                      </span>
                    </TableCell>
                    <TableCell>
                      {classItem.maxStudents}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => handleManageTeachers(classItem.id)}
                          title="Gerenciar Professores"
                        >
                          <Users className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => handleManageStudents(classItem.id)}
                          title="Gerenciar Alunos"
                        >
                          <UserPlus className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => handleManageSubjects(classItem.id)}
                          title="Gerenciar Disciplinas"
                        >
                          <BookOpen className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => openEditDialog(classItem)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => confirmDelete(classItem.id)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Diálogo para adicionar turma */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar Turma</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome da Turma</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Ex: Turma A - Manhã"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="educationLevel">Nível de Ensino</Label>
              <Select 
                value={formData.educationLevelId.toString() || "0"} 
                onValueChange={(value) => setFormData({
                  ...formData, 
                  educationLevelId: parseInt(value),
                  courseId: 0 // Reset curso ao mudar nível
                })}
              >
                <SelectTrigger id="educationLevel">
                  <SelectValue placeholder="Selecione o nível de ensino" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Selecione...</SelectItem>
                  {educationLevels.map(level => (
                    <SelectItem key={level.id} value={level.id.toString()}>
                      {level.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="course">Curso</Label>
              <Select 
                value={formData.courseId.toString() || "0"} 
                onValueChange={(value) => setFormData({...formData, courseId: parseInt(value)})}
                disabled={!formData.educationLevelId}
              >
                <SelectTrigger id="course">
                  <SelectValue placeholder="Selecione o curso" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Selecione...</SelectItem>
                  {filteredCourses.map(course => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="year">Ano</Label>
                <Input
                  id="year"
                  type="number"
                  value={formData.year}
                  onChange={(e) => setFormData({...formData, year: parseInt(e.target.value)})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="semester">Semestre</Label>
                <Select 
                  value={formData.semester} 
                  onValueChange={(value) => setFormData({...formData, semester: value})}
                >
                  <SelectTrigger id="semester">
                    <SelectValue placeholder="Selecione o semestre" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1º Semestre">1º Semestre</SelectItem>
                    <SelectItem value="2º Semestre">2º Semestre</SelectItem>
                    <SelectItem value="Anual">Anual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">Data de Início</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.startDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.startDate ? (
                        format(formData.startDate, "dd/MM/yyyy")
                      ) : (
                        <span>Selecione uma data</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.startDate}
                      onSelect={(date) => date && setFormData({...formData, startDate: date})}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate">Data de Término</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.endDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.endDate ? (
                        format(formData.endDate, "dd/MM/yyyy")
                      ) : (
                        <span>Selecione uma data</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.endDate}
                      onSelect={(date) => date && setFormData({...formData, endDate: date})}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value) => setFormData({...formData, status: value})}
              >
                <SelectTrigger id="status">
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planned">Planejada</SelectItem>
                  <SelectItem value="active">Ativa</SelectItem>
                  <SelectItem value="finished">Encerrada</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="maxStudents">Máximo de Alunos</Label>
              <Input
                id="maxStudents"
                type="number"
                value={formData.maxStudents}
                onChange={(e) => setFormData({...formData, maxStudents: parseInt(e.target.value)})}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Descrição da turma"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleAddClass}>Adicionar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para editar turma */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Turma</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name-edit">Nome da Turma</Label>
              <Input
                id="name-edit"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="educationLevel-edit">Nível de Ensino</Label>
              <Select 
                value={formData.educationLevelId.toString()} 
                onValueChange={(value) => setFormData({
                  ...formData, 
                  educationLevelId: parseInt(value),
                  courseId: 0 // Reset curso ao mudar nível
                })}
              >
                <SelectTrigger id="educationLevel-edit">
                  <SelectValue placeholder="Selecione o nível de ensino" />
                </SelectTrigger>
                <SelectContent>
                  {educationLevels.map(level => (
                    <SelectItem key={level.id} value={level.id.toString()}>
                      {level.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="course-edit">Curso</Label>
              <Select 
                value={formData.courseId.toString()} 
                onValueChange={(value) => setFormData({...formData, courseId: parseInt(value)})}
                disabled={!formData.educationLevelId}
              >
                <SelectTrigger id="course-edit">
                  <SelectValue placeholder="Selecione o curso" />
                </SelectTrigger>
                <SelectContent>
                  {filteredCourses.map(course => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="year-edit">Ano</Label>
                <Input
                  id="year-edit"
                  type="number"
                  value={formData.year}
                  onChange={(e) => setFormData({...formData, year: parseInt(e.target.value)})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="semester-edit">Semestre</Label>
                <Select 
                  value={formData.semester} 
                  onValueChange={(value) => setFormData({...formData, semester: value})}
                >
                  <SelectTrigger id="semester-edit">
                    <SelectValue placeholder="Selecione o semestre" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1º Semestre">1º Semestre</SelectItem>
                    <SelectItem value="2º Semestre">2º Semestre</SelectItem>
                    <SelectItem value="Anual">Anual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate-edit">Data de Início</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.startDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.startDate ? (
                        format(formData.startDate, "dd/MM/yyyy")
                      ) : (
                        <span>Selecione uma data</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.startDate}
                      onSelect={(date) => date && setFormData({...formData, startDate: date})}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate-edit">Data de Término</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !formData.endDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.endDate ? (
                        format(formData.endDate, "dd/MM/yyyy")
                      ) : (
                        <span>Selecione uma data</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={formData.endDate}
                      onSelect={(date) => date && setFormData({...formData, endDate: date})}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="status-edit">Status</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value) => setFormData({...formData, status: value})}
              >
                <SelectTrigger id="status-edit">
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planned">Planejada</SelectItem>
                  <SelectItem value="active">Ativa</SelectItem>
                  <SelectItem value="finished">Encerrada</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="maxStudents-edit">Máximo de Alunos</Label>
              <Input
                id="maxStudents-edit"
                type="number"
                value={formData.maxStudents}
                onChange={(e) => setFormData({...formData, maxStudents: parseInt(e.target.value)})}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description-edit">Descrição</Label>
              <Textarea
                id="description-edit"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleEditClass}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para confirmar exclusão */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta turma? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteClass}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Diálogo para gerenciar professores */}
      <Dialog open={isManageTeachersDialogOpen} onOpenChange={setIsManageTeachersDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Gerenciar Professores da Turma</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="current">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="current">Professores Atuais</TabsTrigger>
              <TabsTrigger value="add">Adicionar Professores</TabsTrigger>
            </TabsList>
            <TabsContent value="current" className="py-4">
              {classTeachers && classTeachers.length > 0 ? (
                <div className="space-y-4">
                  {classTeachers.map((teacher) => (
                    <div key={teacher.id} className="flex items-center justify-between border p-3 rounded-md">
                      <div>
                        <p className="font-medium">{teacher.name}</p>
                        <p className="text-sm text-muted-foreground">
                          Departamento: {teacher.department || "Não especificado"}
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleRemoveTeacherFromClass(teacher.id)}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhum professor associado a esta turma.</p>
                </div>
              )}
            </TabsContent>
            <TabsContent value="add" className="py-4">
              {isLoadingTeachers ? (
                <div className="flex justify-center py-6">Carregando professores...</div>
              ) : teachers && teachers.length > 0 ? (
                <>
                  <div className="space-y-4 mb-4 max-h-64 overflow-y-auto">
                    {teachers
                      .filter(teacher => !classTeachers?.some(ct => ct.id === teacher.id))
                      .map((teacher) => (
                        <div key={teacher.id} className="flex items-center space-x-2 border p-3 rounded-md">
                          <input
                            type="checkbox"
                            id={`teacher-${teacher.id}`}
                            checked={selectedTeachers.includes(teacher.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedTeachers([...selectedTeachers, teacher.id]);
                              } else {
                                setSelectedTeachers(selectedTeachers.filter(id => id !== teacher.id));
                              }
                            }}
                            className="h-4 w-4"
                          />
                          <label htmlFor={`teacher-${teacher.id}`} className="flex-1">
                            <p className="font-medium">{teacher.name}</p>
                            <p className="text-sm text-muted-foreground">
                              Departamento: {teacher.department || "Não especificado"}
                            </p>
                          </label>
                        </div>
                      ))}
                  </div>
                  <div className="flex justify-end">
                    <Button 
                      onClick={handleAddTeachersToClass}
                      disabled={selectedTeachers.length === 0}
                    >
                      Adicionar Selecionados
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhum professor disponível.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Diálogo para gerenciar alunos */}
      <Dialog open={isManageStudentsDialogOpen} onOpenChange={setIsManageStudentsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Gerenciar Alunos da Turma</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="current">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="current">Alunos Atuais</TabsTrigger>
              <TabsTrigger value="add">Adicionar Alunos</TabsTrigger>
            </TabsList>
            <TabsContent value="current" className="py-4">
              {classStudents && classStudents.length > 0 ? (
                <div className="space-y-4">
                  {classStudents.map((student) => (
                    <div key={student.id} className="flex items-center justify-between border p-3 rounded-md">
                      <div>
                        <p className="font-medium">{student.name}</p>
                        <p className="text-sm text-muted-foreground">
                          Matrícula: {student.enrollmentNumber}
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleRemoveStudentFromClass(student.id)}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhum aluno associado a esta turma.</p>
                </div>
              )}
            </TabsContent>
            <TabsContent value="add" className="py-4">
              {isLoadingStudents ? (
                <div className="flex justify-center py-6">Carregando alunos...</div>
              ) : students && students.length > 0 ? (
                <>
                  <div className="space-y-4 mb-4 max-h-64 overflow-y-auto">
                    {students
                      .filter(student => !classStudents?.some(cs => cs.id === student.id))
                      .map((student) => (
                        <div key={student.id} className="flex items-center space-x-2 border p-3 rounded-md">
                          <input
                            type="checkbox"
                            id={`student-${student.id}`}
                            checked={selectedStudents.includes(student.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedStudents([...selectedStudents, student.id]);
                              } else {
                                setSelectedStudents(selectedStudents.filter(id => id !== student.id));
                              }
                            }}
                            className="h-4 w-4"
                          />
                          <label htmlFor={`student-${student.id}`} className="flex-1">
                            <p className="font-medium">{student.name}</p>
                            <p className="text-sm text-muted-foreground">
                              Matrícula: {student.enrollmentNumber}
                            </p>
                          </label>
                        </div>
                      ))}
                  </div>
                  <div className="flex justify-end">
                    <Button 
                      onClick={handleAddStudentsToClass}
                      disabled={selectedStudents.length === 0}
                    >
                      Adicionar Selecionados
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhum aluno disponível.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Diálogo para gerenciar disciplinas */}
      <Dialog open={isManageSubjectsDialogOpen} onOpenChange={setIsManageSubjectsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Gerenciar Disciplinas da Turma</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="current">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="current">Disciplinas Atuais</TabsTrigger>
              <TabsTrigger value="add">Adicionar Disciplina</TabsTrigger>
            </TabsList>
            <TabsContent value="current" className="py-4">
              {classSubjects && classSubjects.length > 0 ? (
                <div className="space-y-4">
                  {classSubjects.map((subject) => (
                    <div key={subject.id} className="flex items-center justify-between border p-3 rounded-md">
                      <div>
                        <p className="font-medium">{subject.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {subject.description}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Créditos: {subject.credits} | Horário: {subject.schedule}
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleRemoveSubjectFromClass(subject.id)}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">Nenhuma disciplina associada a esta turma.</p>
                </div>
              )}
            </TabsContent>
            <TabsContent value="add" className="py-4">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="subject-name">Nome da Disciplina</Label>
                    <Input
                      id="subject-name"
                      value={subjectForm.name}
                      onChange={(e) => setSubjectForm({ ...subjectForm, name: e.target.value })}
                      placeholder="Ex: Matemática"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject-credits">Créditos</Label>
                    <Input
                      id="subject-credits"
                      type="number"
                      value={subjectForm.credits}
                      onChange={(e) => setSubjectForm({ ...subjectForm, credits: parseInt(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject-description">Descrição</Label>
                  <Textarea
                    id="subject-description"
                    value={subjectForm.description}
                    onChange={(e) => setSubjectForm({ ...subjectForm, description: e.target.value })}
                    placeholder="Descrição da disciplina"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject-schedule">Horário</Label>
                  <Input
                    id="subject-schedule"
                    value={subjectForm.schedule}
                    onChange={(e) => setSubjectForm({ ...subjectForm, schedule: e.target.value })}
                    placeholder="Ex: Segunda e Quarta, 14h-16h"
                  />
                </div>
                <div className="flex justify-end">
                  <Button 
                    onClick={handleAddSubjectToClass}
                    disabled={!subjectForm.name || !subjectForm.schedule}
                  >
                    Adicionar Disciplina
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}