import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ExchangeProgram, ExchangeApplication } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export default function ExchangeTab() {
  const { toast } = useToast();
  const [programs, setPrograms] = useState<ExchangeProgram[]>([]);
  const [applications, setApplications] = useState<ExchangeApplication[]>([]);
  const [loading, setLoading] = useState({
    programs: true,
    applications: true
  });

  useEffect(() => {
    // Carregar programas de intercâmbio
    fetch('/api/exchange/programs')
      .then(response => {
        if (!response.ok) {
          throw new Error('Falha ao carregar programas de intercâmbio');
        }
        return response.json();
      })
      .then(data => {
        setPrograms(data);
        setLoading(prev => ({ ...prev, programs: false }));
      })
      .catch(error => {
        console.error('Erro ao buscar programas:', error);
        setLoading(prev => ({ ...prev, programs: false }));
      });

    // Dados simulados para aplicações
    const mockApplications: ExchangeApplication[] = [
      {
        id: 1,
        fullName: "Ana Cristina Oliveira",
        email: "ana.oliveira@example.com",
        phone: "+244 923 456 789",
        nationality: "Angolana",
        programId: 2,
        educationLevel: "Graduação",
        motivation: "Desejo aprofundar meus conhecimentos na cultura chinesa e...",
        status: "pending",
        submittedAt: new Date()
      },
      {
        id: 2,
        fullName: "Pedro Mendes",
        email: "pedro.mendes@example.com",
        phone: "+244 945 678 123",
        nationality: "Angolana",
        programId: 1,
        educationLevel: "Mestrado",
        motivation: "Tenho interesse em pesquisar as relações econômicas...",
        status: "approved",
        submittedAt: new Date(Date.now() - 604800000) // 7 dias atrás
      },
      {
        id: 3,
        fullName: "Sofia Santos",
        email: "sofia.santos@example.com",
        phone: "+244 912 345 678",
        nationality: "Angolana",
        programId: 3,
        educationLevel: "Doutorado",
        motivation: "Minha pesquisa foca na linguística comparativa...",
        status: "rejected",
        submittedAt: new Date(Date.now() - 1209600000) // 14 dias atrás
      }
    ];

    // Simulação de carregamento de aplicações
    setTimeout(() => {
      setApplications(mockApplications);
      setLoading(prev => ({ ...prev, applications: false }));
    }, 1000);
  }, []);

  const handleProgramAction = (action: string, programId: number) => {
    if (action === "edit") {
      toast({
        title: "Editar programa",
        description: "Funcionalidade em desenvolvimento."
      });
    } else if (action === "delete") {
      toast({
        title: "Excluir programa",
        description: "Funcionalidade em desenvolvimento."
      });
    }
  };

  const handleApplicationAction = (action: string, applicationId: number) => {
    if (action === "view") {
      toast({
        title: "Ver detalhes",
        description: "Funcionalidade em desenvolvimento."
      });
    } else if (action === "approve") {
      setApplications(prev => 
        prev.map(app => 
          app.id === applicationId ? { ...app, status: "approved" as const } : app
        )
      );
      
      toast({
        title: "Aplicação aprovada",
        description: "A aplicação foi aprovada com sucesso."
      });
    } else if (action === "reject") {
      setApplications(prev => 
        prev.map(app => 
          app.id === applicationId ? { ...app, status: "rejected" as const } : app
        )
      );
      
      toast({
        title: "Aplicação rejeitada",
        description: "A aplicação foi rejeitada com sucesso."
      });
    }
  };

  return (
    <Tabs defaultValue="programs" className="w-full">
      <TabsList className="w-full grid grid-cols-2 mb-4">
        <TabsTrigger value="programs">Programas</TabsTrigger>
        <TabsTrigger value="applications">Aplicações</TabsTrigger>
      </TabsList>
      
      <TabsContent value="programs">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Gerenciar Programas de Intercâmbio</CardTitle>
            <Button onClick={() => toast({
              title: "Novo programa",
              description: "Funcionalidade em desenvolvimento."
            })}>
              Adicionar Programa
            </Button>
          </CardHeader>
          <CardContent>
            {loading.programs ? (
              <div className="flex justify-center items-center h-64">
                <p>Carregando programas...</p>
              </div>
            ) : (
              <>
                {programs.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-gray-500">Nenhum programa encontrado.</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Título</TableHead>
                        <TableHead>Duração</TableHead>
                        <TableHead>Prazo de Inscrição</TableHead>
                        <TableHead>Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {programs.map(program => (
                        <TableRow key={program.id}>
                          <TableCell>{program.id}</TableCell>
                          <TableCell className="font-medium">{program.title}</TableCell>
                          <TableCell>{program.duration}</TableCell>
                          <TableCell>
                            {new Date(program.applicationDeadline).toLocaleDateString('pt-BR')}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleProgramAction("edit", program.id)}
                              >
                                Editar
                              </Button>
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleProgramAction("delete", program.id)}
                              >
                                Excluir
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </TabsContent>
      
      <TabsContent value="applications">
        <Card>
          <CardHeader>
            <CardTitle>Gerenciar Aplicações</CardTitle>
          </CardHeader>
          <CardContent>
            {loading.applications ? (
              <div className="flex justify-center items-center h-64">
                <p>Carregando aplicações...</p>
              </div>
            ) : (
              <>
                {applications.length === 0 ? (
                  <div className="text-center py-10">
                    <p className="text-gray-500">Nenhuma aplicação encontrada.</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Nome</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Programa</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {applications.map(application => (
                        <TableRow key={application.id}>
                          <TableCell>{application.id}</TableCell>
                          <TableCell className="font-medium">{application.fullName}</TableCell>
                          <TableCell>{application.email}</TableCell>
                          <TableCell>
                            {programs.find(p => p.id === application.programId)?.title || 
                             `Programa #${application.programId}`}
                          </TableCell>
                          <TableCell>
                            {new Date(application.submittedAt).toLocaleDateString('pt-BR')}
                          </TableCell>
                          <TableCell>
                            {application.status === "approved" ? (
                              <Badge className="bg-green-500">Aprovada</Badge>
                            ) : application.status === "rejected" ? (
                              <Badge className="bg-red-500">Rejeitada</Badge>
                            ) : (
                              <Badge className="bg-yellow-500">Pendente</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleApplicationAction("view", application.id)}
                              >
                                Ver
                              </Button>
                              
                              {application.status === "pending" && (
                                <>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="bg-green-50 text-green-600 hover:bg-green-100"
                                    onClick={() => handleApplicationAction("approve", application.id)}
                                  >
                                    Aprovar
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="bg-red-50 text-red-600 hover:bg-red-100"
                                    onClick={() => handleApplicationAction("reject", application.id)}
                                  >
                                    Rejeitar
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}