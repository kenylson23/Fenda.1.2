import { useState, useMemo } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pencil, Plus, Trash } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";

// Definição dos tipos de dados
interface Subject {
  id: number;
  name: string;
  code: string;
  description: string;
  courseId: number;
  credits: number;
  active: boolean;
  createdAt?: string;
  course?: {
    id: number;
    name: string;
  };
}

interface Course {
  id: number;
  name: string;
  code: string;
  educationLevelId: number;
}

interface EducationLevel {
  id: number;
  name: string;
}

// Form data type
interface SubjectFormData {
  name: string;
  code: string;
  description: string;
  courseId: number;
  credits: number;
  active: boolean;
}

export default function SubjectsTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [selectedEducationLevelId, setSelectedEducationLevelId] = useState<number>(0);
  const [formData, setFormData] = useState<SubjectFormData>({
    name: "",
    code: "",
    description: "",
    courseId: 0,
    credits: 4,
    active: true
  });

  // Buscar disciplinas
  const { data: subjectsResponse, isLoading: isLoadingSubjects } = useQuery({
    queryKey: ['/api/subjects'],
    queryFn: async () => {
      const response = await apiRequest('/api/subjects');
      return response;
    }
  });

  // Buscar cursos
  const { data: coursesResponse, isLoading: isLoadingCourses } = useQuery({
    queryKey: ['/api/courses'],
    queryFn: async () => {
      const response = await apiRequest('/api/courses');
      return response;
    }
  });

  // Buscar níveis de ensino
  const { data: educationLevelsResponse, isLoading: isLoadingLevels } = useQuery({
    queryKey: ['/api/education-levels'],
    queryFn: async () => {
      const response = await apiRequest('/api/education-levels');
      return response;
    }
  });
  
  // Garantir que subjects seja sempre um array
  const subjects = useMemo(() => {
    if (!subjectsResponse) return [];
    if (Array.isArray(subjectsResponse)) return subjectsResponse;
    if (subjectsResponse && 'data' in subjectsResponse && Array.isArray(subjectsResponse.data)) {
      return subjectsResponse.data;
    }
    console.error("Formato inesperado de dados (disciplinas):", subjectsResponse);
    return [];
  }, [subjectsResponse]);
  
  // Garantir que courses seja sempre um array
  const courses = useMemo(() => {
    if (!coursesResponse) return [];
    if (Array.isArray(coursesResponse)) return coursesResponse;
    if (coursesResponse && 'data' in coursesResponse && Array.isArray(coursesResponse.data)) {
      return coursesResponse.data;
    }
    console.error("Formato inesperado de dados (cursos):", coursesResponse);
    return [];
  }, [coursesResponse]);
  
  // Garantir que educationLevels seja sempre um array
  const educationLevels = useMemo(() => {
    if (!educationLevelsResponse) return [];
    if (Array.isArray(educationLevelsResponse)) return educationLevelsResponse;
    if (educationLevelsResponse && 'data' in educationLevelsResponse && Array.isArray(educationLevelsResponse.data)) {
      return educationLevelsResponse.data;
    }
    console.error("Formato inesperado de dados (níveis):", educationLevelsResponse);
    return [];
  }, [educationLevelsResponse]);
  
  const isLoading = isLoadingSubjects || isLoadingCourses || isLoadingLevels;

  // Handlers para operações CRUD
  const handleAddSubject = async () => {
    try {
      await apiRequest('/api/subjects', {
        method: 'POST',
        data: formData
      });
      
      toast({
        title: "Disciplina adicionada",
        description: "A disciplina foi criada com sucesso."
      });
      
      setIsAddDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['/api/subjects'] });
    } catch (error) {
      toast({
        title: "Erro ao adicionar",
        description: "Não foi possível adicionar a disciplina.",
        variant: "destructive"
      });
    }
  };

  const handleEditSubject = async () => {
    if (!selectedSubjectId) return;
    
    try {
      await apiRequest(`/api/subjects/${selectedSubjectId}`, {
        method: 'PATCH',
        data: formData
      });
      
      toast({
        title: "Disciplina atualizada",
        description: "As alterações foram salvas com sucesso."
      });
      
      setIsEditDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['/api/subjects'] });
    } catch (error) {
      toast({
        title: "Erro ao atualizar",
        description: "Não foi possível atualizar a disciplina.",
        variant: "destructive"
      });
    }
  };

  const handleDeleteSubject = async () => {
    if (!selectedSubjectId) return;
    
    try {
      await apiRequest(`/api/subjects/${selectedSubjectId}`, {
        method: 'DELETE'
      });
      
      toast({
        title: "Disciplina excluída",
        description: "A disciplina foi removida com sucesso."
      });
      
      setIsDeleteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/subjects'] });
    } catch (error: any) {
      toast({
        title: "Erro ao excluir",
        description: error.message || "Não foi possível excluir a disciplina.",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      code: "",
      description: "",
      courseId: 0,
      credits: 4,
      active: true
    });
    setSelectedSubjectId(null);
    setSelectedEducationLevelId(0);
  };

  const openEditDialog = (subject: Subject) => {
    setSelectedSubjectId(subject.id);
    
    // Encontrar o curso para determinar o nível de ensino
    const course = courses.find(c => c.id === subject.courseId);
    if (course) {
      setSelectedEducationLevelId(course.educationLevelId);
    }
    
    setFormData({
      name: subject.name,
      code: subject.code,
      description: subject.description || "",
      courseId: subject.courseId,
      credits: subject.credits,
      active: subject.active
    });
    
    setIsEditDialogOpen(true);
  };

  const confirmDelete = (id: number) => {
    setSelectedSubjectId(id);
    setIsDeleteDialogOpen(true);
  };

  // Função para encontrar o nome do curso pelo ID
  const getCourseName = (courseId: number) => {
    const course = courses.find(course => course.id === courseId);
    return course ? course.name : "Desconhecido";
  };

  // Filtrar cursos por nível de ensino
  const filteredCourses = selectedEducationLevelId 
    ? courses.filter(course => course.educationLevelId === selectedEducationLevelId)
    : courses;

  return (
    <div className="space-y-6">
      <div className="flex justify-end mb-4">
        <Button 
          onClick={() => {
            resetForm();
            setIsAddDialogOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" />
          Adicionar Disciplina
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <p>Carregando disciplinas...</p>
            </div>
          ) : subjects.length === 0 ? (
            <div className="text-center p-4">
              <p>Nenhuma disciplina cadastrada.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Código</TableHead>
                  <TableHead>Nome</TableHead>
                  <TableHead>Curso</TableHead>
                  <TableHead>Créditos</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {subjects.map(subject => (
                  <TableRow key={subject.id}>
                    <TableCell>{subject.code}</TableCell>
                    <TableCell className="font-medium">{subject.name}</TableCell>
                    <TableCell>{subject.course?.name || getCourseName(subject.courseId)}</TableCell>
                    <TableCell>{subject.credits}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${subject.active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                        {subject.active ? "Ativa" : "Inativa"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => openEditDialog(subject)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => confirmDelete(subject.id)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Diálogo para adicionar disciplina */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar Disciplina</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="code">Código da Disciplina</Label>
              <Input
                id="code"
                value={formData.code}
                onChange={(e) => setFormData({...formData, code: e.target.value})}
                placeholder="Ex: MAT001"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Nome da Disciplina</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Ex: Cálculo I"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Descrição da disciplina"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="educationLevel">Nível de Ensino</Label>
              <Select 
                value={selectedEducationLevelId.toString() || "0"} 
                onValueChange={(value) => {
                  const levelId = parseInt(value);
                  setSelectedEducationLevelId(levelId);
                  setFormData({...formData, courseId: 0}); // Reset curso ao mudar nível
                }}
              >
                <SelectTrigger id="educationLevel">
                  <SelectValue placeholder="Selecione o nível de ensino" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Selecione...</SelectItem>
                  {educationLevels.map(level => (
                    <SelectItem key={level.id} value={level.id.toString()}>
                      {level.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="course">Curso</Label>
              <Select 
                value={formData.courseId.toString() || "0"} 
                onValueChange={(value) => setFormData({...formData, courseId: parseInt(value)})}
                disabled={!selectedEducationLevelId}
              >
                <SelectTrigger id="course">
                  <SelectValue placeholder="Selecione o curso" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Selecione...</SelectItem>
                  {filteredCourses.map(course => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="credits">Créditos</Label>
              <Input
                id="credits"
                type="number"
                min="1"
                value={formData.credits}
                onChange={(e) => setFormData({...formData, credits: parseInt(e.target.value)})}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="active"
                checked={formData.active}
                onCheckedChange={(checked) => setFormData({...formData, active: checked})}
              />
              <Label htmlFor="active">Ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancelar</Button>
            <Button 
              onClick={handleAddSubject}
              disabled={!formData.name || !formData.code || !formData.courseId}
            >
              Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para editar disciplina */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Disciplina</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="code-edit">Código da Disciplina</Label>
              <Input
                id="code-edit"
                value={formData.code}
                onChange={(e) => setFormData({...formData, code: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name-edit">Nome da Disciplina</Label>
              <Input
                id="name-edit"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description-edit">Descrição</Label>
              <Textarea
                id="description-edit"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="educationLevel-edit">Nível de Ensino</Label>
              <Select 
                value={selectedEducationLevelId.toString()} 
                onValueChange={(value) => {
                  const levelId = parseInt(value);
                  setSelectedEducationLevelId(levelId);
                  setFormData({...formData, courseId: 0}); // Reset curso ao mudar nível
                }}
              >
                <SelectTrigger id="educationLevel-edit">
                  <SelectValue placeholder="Selecione o nível de ensino" />
                </SelectTrigger>
                <SelectContent>
                  {educationLevels.map(level => (
                    <SelectItem key={level.id} value={level.id.toString()}>
                      {level.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="course-edit">Curso</Label>
              <Select 
                value={formData.courseId.toString()} 
                onValueChange={(value) => setFormData({...formData, courseId: parseInt(value)})}
                disabled={!selectedEducationLevelId}
              >
                <SelectTrigger id="course-edit">
                  <SelectValue placeholder="Selecione o curso" />
                </SelectTrigger>
                <SelectContent>
                  {filteredCourses.map(course => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="credits-edit">Créditos</Label>
              <Input
                id="credits-edit"
                type="number"
                min="1"
                value={formData.credits}
                onChange={(e) => setFormData({...formData, credits: parseInt(e.target.value)})}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="active-edit"
                checked={formData.active}
                onCheckedChange={(checked) => setFormData({...formData, active: checked})}
              />
              <Label htmlFor="active-edit">Ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancelar</Button>
            <Button 
              onClick={handleEditSubject}
              disabled={!formData.name || !formData.code || !formData.courseId}
            >
              Salvar Alterações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para confirmar exclusão */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta disciplina? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteSubject}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}