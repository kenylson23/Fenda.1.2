import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ContactSubmission } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export default function ContactTab() {
  const { toast } = useToast();
  const [submissions, setSubmissions] = useState<ContactSubmission[]>([]);
  const [loading, setLoading] = useState(true);

  // Dados simulados para demonstração
  const mockSubmissions: ContactSubmission[] = [
    {
      id: 1,
      name: "Maria Oliveira",
      email: "maria@example.com",
      subject: "Informações sobre Admissão",
      message: "Gostaria de mais informações sobre o processo de admissão para o próximo semestre.",
      submittedAt: new Date(),
      responded: false
    },
    {
      id: 2,
      name: "João Santos",
      email: "joao@example.com",
      subject: "Programa de Intercâmbio",
      message: "Tenho interesse no programa de intercâmbio para a China. Quais são os requisitos?",
      submittedAt: new Date(Date.now() - 86400000), // Ontem
      responded: true
    },
    {
      id: 3,
      name: "Carla Silva",
      email: "carla@example.com",
      subject: "Biblioteca Virtual",
      message: "Estou tendo dificuldades para acessar alguns materiais da biblioteca virtual. Podem me ajudar?",
      submittedAt: new Date(Date.now() - 172800000), // 2 dias atrás
      responded: false
    }
  ];

  useEffect(() => {
    // Em uma implementação real, carregaríamos da API
    setTimeout(() => {
      setSubmissions(mockSubmissions);
      setLoading(false);
    }, 1000);
  }, []);

  const handleSubmissionAction = (action: string, submissionId: number) => {
    if (action === "mark-responded") {
      // Atualizar estado local
      setSubmissions(prev => 
        prev.map(sub => 
          sub.id === submissionId ? { ...sub, responded: true } : sub
        )
      );
      
      toast({
        title: "Marcado como respondido",
        description: "O contato foi marcado como respondido com sucesso."
      });
    } else if (action === "delete") {
      // Remover do estado local
      setSubmissions(prev => prev.filter(sub => sub.id !== submissionId));
      
      toast({
        title: "Contato removido",
        description: "O contato foi removido com sucesso."
      });
    } else if (action === "view") {
      toast({
        title: "Ver detalhes",
        description: "Funcionalidade em desenvolvimento."
      });
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Gerenciar Contatos</CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <p>Carregando contatos...</p>
          </div>
        ) : (
          <>
            {submissions.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-gray-500">Nenhum contato encontrado.</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Assunto</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {submissions.map(submission => (
                    <TableRow key={submission.id}>
                      <TableCell>{submission.id}</TableCell>
                      <TableCell className="font-medium">{submission.name}</TableCell>
                      <TableCell>{submission.email}</TableCell>
                      <TableCell>{submission.subject}</TableCell>
                      <TableCell>
                        {new Date(submission.submittedAt).toLocaleDateString('pt-BR')}
                      </TableCell>
                      <TableCell>
                        {submission.responded ? (
                          <Badge className="bg-green-500">Respondido</Badge>
                        ) : (
                          <Badge className="bg-yellow-500">Pendente</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleSubmissionAction("view", submission.id)}
                          >
                            Ver
                          </Button>
                          {!submission.responded && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleSubmissionAction("mark-responded", submission.id)}
                            >
                              Marcar como respondido
                            </Button>
                          )}
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleSubmissionAction("delete", submission.id)}
                          >
                            Excluir
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}