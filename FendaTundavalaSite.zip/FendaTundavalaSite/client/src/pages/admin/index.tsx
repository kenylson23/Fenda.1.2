import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

// Componentes para cada seção do painel administrativo
import UsersTab from "@/pages/admin/components/users-tab";
import ResourcesTab from "@/pages/admin/components/resources-tab";
import TestimonialsTab from "@/pages/admin/components/testimonials-tab";
import ContactTab from "@/pages/admin/components/contact-tab";
import ExchangeTab from "@/pages/admin/components/exchange-tab";
import StatsTab from "@/pages/admin/components/stats-tab";
import ClassesTab from "@/pages/admin/components/classes-tab";
import EducationLevelsTab from "@/pages/admin/components/education-levels-tab";
import PedagogicalArea from "@/pages/admin/components/pedagogical-area";

// Credenciais fixas do administrador
const ADMIN_CREDENTIALS = {
  username: "admin",
  password: "admin123",
  name: "Administrador",
};

export default function AdminPanel() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    password: ""
  });

  // Verifica se o administrador já está autenticado (via localStorage)
  useEffect(() => {
    const checkAuth = () => {
      const adminAuth = localStorage.getItem("adminAuth");
      if (adminAuth) {
        try {
          const parsed = JSON.parse(adminAuth);
          if (parsed.isAuthenticated) {
            setIsAuthenticated(true);
          }
        } catch (error) {
          console.error("Erro ao verificar autenticação:", error);
          localStorage.removeItem("adminAuth"); // Remove dados inválidos
        }
      }
    };
    
    checkAuth();
  }, []);

  // Atualiza os campos do formulário
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Realiza o login do administrador (verificação local, sem API)
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simula uma autenticação mais realista com um pequeno atraso
    setTimeout(() => {
      // Verifica se as credenciais correspondem às credenciais fixas
      if (formData.username === ADMIN_CREDENTIALS.username && 
          formData.password === ADMIN_CREDENTIALS.password) {
        
        // Salva o estado de autenticação no localStorage
        localStorage.setItem("adminAuth", JSON.stringify({
          isAuthenticated: true,
          name: ADMIN_CREDENTIALS.name,
          timestamp: new Date().toISOString()
        }));
        
        // Atualiza o estado e notifica o usuário
        setIsAuthenticated(true);
        toast({
          title: "Login realizado com sucesso",
          description: "Bem-vindo ao painel administrativo.",
          variant: "default"
        });
      } else {
        // Notifica o usuário sobre falha de autenticação
        toast({
          title: "Erro de autenticação",
          description: "Nome de usuário ou senha incorretos.",
          variant: "destructive"
        });
      }
      
      setIsLoading(false);
    }, 500); // Atraso de 500ms para simular processamento
  };

  // Realiza o logout do administrador
  const handleLogout = () => {
    localStorage.removeItem("adminAuth");
    setIsAuthenticated(false);
    setFormData({ username: "", password: "" });
    
    toast({
      title: "Logout realizado",
      description: "Você saiu do painel administrativo com sucesso.",
      variant: "default"
    });
  };

  // Página de login do administrador
  if (!isAuthenticated) {
    return (
      <div className="container mx-auto py-10 px-4">
        <div className="max-w-md mx-auto">
          <h1 className="text-3xl font-bold text-center text-primary mb-8">
            Painel Administrativo
          </h1>
          
          <Card>
            <CardHeader>
              <CardTitle>Login de Administrador</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="username">Nome de usuário</Label>
                  <Input
                    id="username"
                    name="username"
                    type="text"
                    value={formData.username}
                    onChange={handleChange}
                    placeholder="Digite seu nome de usuário"
                    disabled={isLoading}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Senha</Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Digite sua senha"
                    disabled={isLoading}
                    required
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? "Entrando..." : "Entrar"}
                </Button>
              </form>
              
              <div className="mt-4 text-center">
                <Button variant="link" onClick={() => navigate("/")} disabled={isLoading}>
                  ← Voltar para o site
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Interface do painel administrativo (após autenticação)
  return (
    <div className="container mx-auto py-6 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-primary">Painel Administrativo</h1>
        
        <div className="flex items-center gap-4">
          <span className="text-sm text-muted-foreground">
            Logado como: <strong>{ADMIN_CREDENTIALS.name}</strong>
          </span>
          <Button variant="outline" onClick={() => navigate("/")}>
            Ver Site
          </Button>
          <Button 
            variant="destructive" 
            onClick={handleLogout}
          >
            Sair
          </Button>
        </div>
      </div>

      <Tabs defaultValue="stats" className="w-full">
        <TabsList className="grid grid-cols-8 mb-6">
          <TabsTrigger value="stats">Dashboard</TabsTrigger>
          <TabsTrigger value="users">Usuários</TabsTrigger>
          <TabsTrigger value="pedagogical">Área Pedagógica</TabsTrigger>
          <TabsTrigger value="resources">Biblioteca</TabsTrigger>
          <TabsTrigger value="testimonials">Depoimentos</TabsTrigger>
          <TabsTrigger value="exchange">Intercâmbio</TabsTrigger>
          <TabsTrigger value="contact">Contatos</TabsTrigger>
        </TabsList>
        
        <TabsContent value="stats">
          <StatsTab />
        </TabsContent>
        
        <TabsContent value="users">
          <UsersTab />
        </TabsContent>
        
        <TabsContent value="pedagogical">
          <PedagogicalArea />
        </TabsContent>
        
        <TabsContent value="resources">
          <ResourcesTab />
        </TabsContent>
        
        <TabsContent value="testimonials">
          <TestimonialsTab />
        </TabsContent>
        
        <TabsContent value="exchange">
          <ExchangeTab />
        </TabsContent>
        
        <TabsContent value="contact">
          <ContactTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}