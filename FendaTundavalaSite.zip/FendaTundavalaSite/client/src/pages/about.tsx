import { Link } from "wouter";
import { Helmet } from "react-helmet";

const About = () => {
  return (
    <>
      <Helmet>
        <title>Sobre Nós - Fenda da Tundavala</title>
        <meta name="description" content="Conheça a história, missão e valores da Fenda da Tundavala, instituição de intercâmbio Angola-China." />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
      </Helmet>

      {/* Hero Section */}
      <div className="bg-[hsl(var(--primary))] text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Sobre a Fenda da Tundavala</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Uma instituição comprometida com a excelência educacional e a cooperação internacional
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2">
            <h2 className="text-3xl font-bold text-[hsl(var(--primary))] mb-6">Nossa História</h2>
            <p className="mb-4">
              Fundada em 2008, a Fenda da Tundavala nasceu da visão de criar uma ponte educacional entre Angola e China, proporcionando oportunidades únicas para estudantes de ambos os países expandirem seus horizontes culturais e acadêmicos.
            </p>
            <p className="mb-4">
              O nome da nossa instituição foi inspirado pela maravilhosa formação geológica localizada na província de Huíla, em Angola. A Fenda da Tundavala representa não apenas um símbolo nacional de Angola, mas também a abertura para novas perspectivas – valor que consideramos essencial em nossa missão educacional.
            </p>
            <p className="mb-4">
              Ao longo dos anos, temos cultivado parcerias sólidas com instituições educacionais de renome na China, permitindo intercâmbios estudantis enriquecedores e o desenvolvimento de programas acadêmicos de excelência que integram o melhor de ambas as culturas.
            </p>
            <p className="mb-8">
              Hoje, a Fenda da Tundavala é reconhecida como referência em educação intercultural, com centenas de alunos formados que atuam como embaixadores culturais e profissionais qualificados em diversos setores, contribuindo para o fortalecimento das relações Angola-China.
            </p>

            <h2 className="text-3xl font-bold text-[hsl(var(--primary))] mb-6">Missão e Valores</h2>
            <div className="bg-[#f5f5f5] p-6 rounded-lg mb-8">
              <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-3">Nossa Missão</h3>
              <p>
                Proporcionar educação de excelência com perspectiva global, formando cidadãos preparados para atuar em um mundo multicultural, com ênfase especial nas relações entre Angola e China.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-white shadow-md rounded-lg p-5">
                <div className="flex items-start mb-3">
                  <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                    <i className="fas fa-globe text-[hsl(var(--primary))]"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-[hsl(var(--primary))]">Interculturalidade</h3>
                </div>
                <p>Valorização e respeito às diferentes culturas, promovendo a integração e o aprendizado mútuo.</p>
              </div>
              
              <div className="bg-white shadow-md rounded-lg p-5">
                <div className="flex items-start mb-3">
                  <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                    <i className="fas fa-award text-[hsl(var(--primary))]"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-[hsl(var(--primary))]">Excelência</h3>
                </div>
                <p>Compromisso com os mais altos padrões educacionais e de desenvolvimento humano.</p>
              </div>
              
              <div className="bg-white shadow-md rounded-lg p-5">
                <div className="flex items-start mb-3">
                  <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                    <i className="fas fa-lightbulb text-[hsl(var(--primary))]"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-[hsl(var(--primary))]">Inovação</h3>
                </div>
                <p>Busca constante por novas metodologias e abordagens educacionais que potencializem o aprendizado.</p>
              </div>
              
              <div className="bg-white shadow-md rounded-lg p-5">
                <div className="flex items-start mb-3">
                  <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                    <i className="fas fa-hands-helping text-[hsl(var(--primary))]"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-[hsl(var(--primary))]">Cooperação</h3>
                </div>
                <p>Fomento à colaboração e às parcerias que enriquecem a experiência educacional.</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
              <img 
                src="https://pixabay.com/get/g7b595512f93e2ed136cf729c831cbdbdbbb1cb13390ad24121ae3fbb796cb94fa6f6d348841e4385ff4d93512d171062_1280.jpg" 
                alt="Fenda da Tundavala" 
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-3">A Fenda da Tundavala</h3>
                <p className="mb-3">
                  A impressionante formação geológica que inspirou o nome da nossa instituição é uma das maravilhas naturais de Angola.
                </p>
                <p className="text-sm">
                  Localizada a aproximadamente 18 km da cidade do Lubango, na província de Huíla, a fenda representa uma abertura abrupta na escarpa da Serra da Leba, com um desnível de mais de 1.000 metros.
                </p>
              </div>
            </div>

            <div className="bg-[hsl(var(--primary))] text-white rounded-lg p-6 mb-8">
              <h3 className="text-xl font-semibold mb-4">Fatos Rápidos</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <i className="fas fa-check-circle mt-1 mr-2 text-[hsl(var(--secondary))]"></i>
                  <span>Fundada em 2008</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle mt-1 mr-2 text-[hsl(var(--secondary))]"></i>
                  <span>Mais de 500 alunos formados em programas de intercâmbio</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle mt-1 mr-2 text-[hsl(var(--secondary))]"></i>
                  <span>Parcerias com 20+ universidades na China</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle mt-1 mr-2 text-[hsl(var(--secondary))]"></i>
                  <span>Corpo docente bilíngue internacional</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle mt-1 mr-2 text-[hsl(var(--secondary))]"></i>
                  <span>Biblioteca virtual com mais de 10.000 recursos</span>
                </li>
              </ul>
            </div>

            <div className="bg-[hsl(var(--secondary-yellow))] rounded-lg p-6">
              <h3 className="text-xl font-semibold text-[hsl(var(--primary))] mb-4">Quer Saber Mais?</h3>
              <p className="text-[#333333] mb-4">
                Entre em contato conosco para conhecer mais sobre nossa instituição e os programas que oferecemos.
              </p>
              <Link 
                href="/contact" 
                className="block text-center bg-[hsl(var(--primary))] text-white py-2 px-4 rounded-lg font-medium hover:bg-[hsl(var(--secondary-blue))] transition"
              >
                Contacte-nos
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default About;
