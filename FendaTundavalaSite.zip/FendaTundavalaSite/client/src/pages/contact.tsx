import { useState } from "react";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Helmet } from "react-helmet";
import { ContactFormData } from "@/lib/types";

const Contact = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ContactFormData>();
  
  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/contact", data);
      toast({
        title: "Mensagem enviada",
        description: "Obrigado pelo seu contato. Responderemos o mais breve possível.",
      });
      reset();
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível enviar sua mensagem. Tente novamente mais tarde.",
        variant: "destructive",
      });
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Contacto - Fenda da Tundavala</title>
        <meta name="description" content="Entre em contacto com a Fenda da Tundavala para informações sobre nossos programas e serviços." />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
      </Helmet>

      {/* Hero Section */}
      <div className="bg-[hsl(var(--primary))] text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Entre em Contacto</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Estamos aqui para responder a todas as suas perguntas sobre a nossa instituição
          </p>
        </div>
      </div>

      {/* Contact Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div>
            <h2 className="text-2xl font-bold text-[hsl(var(--primary))] mb-6">Envie-nos uma Mensagem</h2>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Nome Completo
                    </label>
                    <input 
                      id="name" 
                      {...register("name", { required: "Nome é obrigatório" })}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))] focus:ring-opacity-30 focus:outline-none" 
                    />
                    {errors.name && (
                      <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input 
                      type="email" 
                      id="email" 
                      {...register("email", { 
                        required: "Email é obrigatório",
                        pattern: {
                          value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                          message: "Endereço de email inválido"
                        }
                      })}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))] focus:ring-opacity-30 focus:outline-none" 
                    />
                    {errors.email && (
                      <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>
                    )}
                  </div>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                    Assunto
                  </label>
                  <select 
                    id="subject" 
                    {...register("subject", { required: "Assunto é obrigatório" })}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:outline-none"
                  >
                    <option value="Informações sobre Admissão">Informações sobre Admissão</option>
                    <option value="Programa de Intercâmbio">Programa de Intercâmbio</option>
                    <option value="Biblioteca Virtual">Biblioteca Virtual</option>
                    <option value="Parcerias Institucionais">Parcerias Institucionais</option>
                    <option value="Outros Assuntos">Outros Assuntos</option>
                  </select>
                  {errors.subject && (
                    <p className="text-red-500 text-xs mt-1">{errors.subject.message}</p>
                  )}
                </div>
                
                <div className="mb-4">
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                    Mensagem
                  </label>
                  <textarea 
                    id="message" 
                    rows={6} 
                    {...register("message", { 
                      required: "Mensagem é obrigatória",
                      minLength: {
                        value: 10,
                        message: "Mensagem deve ter pelo menos 10 caracteres"
                      }
                    })}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))] focus:ring-opacity-30 focus:outline-none"
                  ></textarea>
                  {errors.message && (
                    <p className="text-red-500 text-xs mt-1">{errors.message.message}</p>
                  )}
                </div>
                
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="bg-[hsl(var(--primary))] text-white px-6 py-3 rounded-lg font-medium hover:bg-[hsl(var(--secondary-blue))] transition w-full disabled:opacity-70"
                >
                  {isSubmitting ? "Enviando..." : "Enviar Mensagem"}
                </button>
              </form>
            </div>
          </div>
          
          <div>
            <h2 className="text-2xl font-bold text-[hsl(var(--primary))] mb-6">Informações de Contacto</h2>
            
            <div className="bg-white p-6 rounded-lg shadow-md mb-8">
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-[hsl(var(--secondary))] p-3 rounded-lg mr-4">
                    <i className="fas fa-map-marker-alt text-[hsl(var(--primary))] text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg text-[hsl(var(--primary))]">Endereço</h3>
                    <p className="text-gray-600 mt-1">
                      Avenida Principal<br />
                      Lubango, Huíla<br />
                      Angola
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[hsl(var(--secondary))] p-3 rounded-lg mr-4">
                    <i className="fas fa-phone-alt text-[hsl(var(--primary))] text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg text-[hsl(var(--primary))]">Telefones</h3>
                    <p className="text-gray-600 mt-1">
                      +244 123 456 789<br />
                      +244 987 654 321
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[hsl(var(--secondary))] p-3 rounded-lg mr-4">
                    <i className="fas fa-envelope text-[hsl(var(--primary))] text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg text-[hsl(var(--primary))]">Email</h3>
                    <p className="text-gray-600 mt-1">
                      info@fendadatundavala.ao<br />
                      admissoes@fendadatundavala.ao
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[hsl(var(--secondary))] p-3 rounded-lg mr-4">
                    <i className="fas fa-clock text-[hsl(var(--primary))] text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg text-[hsl(var(--primary))]">Horário de Funcionamento</h3>
                    <p className="text-gray-600 mt-1">
                      Segunda a Sexta: 8:00 - 17:00<br />
                      Sábado: 8:00 - 12:00<br />
                      Domingo: Fechado
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md mb-8">
              <h3 className="font-semibold text-lg text-[hsl(var(--primary))] mb-4">Siga-nos nas Redes Sociais</h3>
              <div className="flex space-x-4">
                <a href="#" className="bg-[hsl(var(--primary))] text-white w-12 h-12 rounded-full flex items-center justify-center hover:bg-[hsl(var(--secondary-blue))] transition">
                  <i className="fab fa-facebook-f text-lg"></i>
                </a>
                <a href="#" className="bg-[hsl(var(--primary))] text-white w-12 h-12 rounded-full flex items-center justify-center hover:bg-[hsl(var(--secondary-blue))] transition">
                  <i className="fab fa-instagram text-lg"></i>
                </a>
                <a href="#" className="bg-[hsl(var(--primary))] text-white w-12 h-12 rounded-full flex items-center justify-center hover:bg-[hsl(var(--secondary-blue))] transition">
                  <i className="fab fa-twitter text-lg"></i>
                </a>
                <a href="#" className="bg-[hsl(var(--primary))] text-white w-12 h-12 rounded-full flex items-center justify-center hover:bg-[hsl(var(--secondary-blue))] transition">
                  <i className="fab fa-linkedin-in text-lg"></i>
                </a>
              </div>
            </div>
            
            {/* Map Placeholder */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-semibold text-lg text-[hsl(var(--primary))] mb-4">Nossa Localização</h3>
              <div className="bg-gray-100 h-64 flex items-center justify-center rounded">
                <div className="text-center">
                  <i className="fas fa-map-marked-alt text-5xl text-[hsl(var(--primary))] mb-3"></i>
                  <p className="text-gray-600">Mapa interativo da localização da escola</p>
                </div>
              </div>
              <p className="text-sm text-gray-600 mt-4">
                Estamos localizados em uma área de fácil acesso na cidade de Lubango, próximo às principais vias e pontos de referência.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Frequently Asked Questions */}
      <div className="bg-[hsl(var(--secondary-yellow))] bg-opacity-30 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-[hsl(var(--primary))] mb-8 text-center">Perguntas Frequentes</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-semibold text-[hsl(var(--primary))] mb-2">Como posso me inscrever no programa de intercâmbio?</h3>
              <p className="text-gray-600">
                Para se inscrever, acesse a seção de Intercâmbio em nosso site e preencha o formulário de candidatura. Nossa equipe entrará em contato para os próximos passos.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-semibold text-[hsl(var(--primary))] mb-2">Quais são os custos do programa de intercâmbio?</h3>
              <p className="text-gray-600">
                Os custos variam de acordo com a modalidade e duração do programa. Temos opções de bolsas disponíveis para estudantes qualificados. Entre em contato para detalhes específicos.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-semibold text-[hsl(var(--primary))] mb-2">Preciso saber mandarim para participar do intercâmbio?</h3>
              <p className="text-gray-600">
                Não é um requisito inicial. Oferecemos cursos preparatórios de mandarim antes da viagem e cursos intensivos na chegada à China.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="font-semibold text-[hsl(var(--primary))] mb-2">Como funciona a biblioteca virtual?</h3>
              <p className="text-gray-600">
                Nossa biblioteca virtual oferece acesso a milhares de recursos digitais. Alunos registrados podem acessar através de nosso portal com seu login e senha.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-[hsl(var(--primary))] text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Venha Nos Visitar</h2>
          <p className="max-w-2xl mx-auto mb-8">
            Agende uma visita guiada pela nossa instituição e conheça de perto nossos programas e instalações.
          </p>
          <button className="inline-block bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-6 py-3 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition">
            Agendar Visita
          </button>
        </div>
      </div>
    </>
  );
};

export default Contact;
