import { useState } from "react";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

export default function Portal() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Login form state
  const [loginForm, setLoginForm] = useState({
    username: "",
    password: "",
  });

  // Register form state
  const [registerForm, setRegisterForm] = useState({
    name: "",
    email: "",
    username: "",
    password: "",
    confirmPassword: "",
  });

  // Handle login form input changes
  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLoginForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle register form input changes
  const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setRegisterForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle login form submission
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!loginForm.username || !loginForm.password) {
      toast({
        title: "Erro de validação",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
      });
      return;
    }

    // Verificação especial para o administrador (credenciais hardcoded)
    if (loginForm.username === 'admin' && loginForm.password === 'admin123') {
      // Autenticação de administrador bem-sucedida
      toast({
        title: "Login de administrador bem-sucedido",
        description: "Redirecionando para o painel administrativo...",
      });
      
      // Configurar autenticação de administrador no localStorage
      localStorage.setItem('adminAuth', JSON.stringify({
        isAuthenticated: true,
        name: "Administrador",
        timestamp: new Date().toISOString()
      }));
      
      // Redirecionar para o painel administrativo
      setTimeout(() => {
        navigate('/admin');
      }, 500);
      
      return;
    }

    try {
      // Make API call to login para usuários regulares
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: loginForm.username,
          password: loginForm.password
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        toast({
          title: "Erro de login",
          description: data.message || "Falha ao fazer login. Verifique suas credenciais.",
          variant: "destructive",
        });
        return;
      }

      // Successful login
      toast({
        title: "Login realizado com sucesso",
        description: "Bem-vindo ao Portal do Aluno!",
      });

      // Save user data in localStorage
      localStorage.setItem('userAuth', JSON.stringify({
        isLoggedIn: true,
        user: data.user
      }));

      // Reset form
      setLoginForm({
        username: "",
        password: "",
      });

      // Redirect to the student dashboard
      if (data.user.username === 'admin') {
        // If user is admin, redirect to admin panel
        navigate('/admin');
      } else {
        // For regular users, we would redirect to a student portal page
        // For now, we'll just show a success message
        toast({
          title: "Acesso de Aluno",
          description: "Futuramente aqui será exibido o painel do aluno.",
        });
      }
    } catch (error) {
      console.error('Erro ao fazer login:', error);
      toast({
        title: "Erro de conexão",
        description: "Não foi possível conectar ao servidor. Tente novamente mais tarde.",
        variant: "destructive",
      });
    }
  };

  // Handle register form submission
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!registerForm.name || !registerForm.email || !registerForm.username || !registerForm.password) {
      toast({
        title: "Erro de validação",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
      });
      return;
    }

    if (registerForm.password !== registerForm.confirmPassword) {
      toast({
        title: "Erro de validação",
        description: "As senhas não coincidem",
        variant: "destructive",
      });
      return;
    }

    // Email validation
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    if (!emailRegex.test(registerForm.email)) {
      toast({
        title: "Erro de validação",
        description: "Por favor, insira um email válido",
        variant: "destructive",
      });
      return;
    }

    try {
      // Make API call to register
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: registerForm.username,
          password: registerForm.password,
          // Note: email and name are not part of the current schema
          // We would need to extend the users table to include these fields
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        toast({
          title: "Erro de cadastro",
          description: data.message || "Falha ao realizar o cadastro.",
          variant: "destructive",
        });
        return;
      }

      // Successful registration
      toast({
        title: "Cadastro realizado com sucesso",
        description: "Agora você pode fazer login com suas credenciais.",
      });
      
      // Reset form
      setRegisterForm({
        name: "",
        email: "",
        username: "",
        password: "",
        confirmPassword: "",
      });
    } catch (error) {
      console.error('Erro ao fazer cadastro:', error);
      toast({
        title: "Erro de conexão",
        description: "Não foi possível conectar ao servidor. Tente novamente mais tarde.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto py-10 px-4">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-center text-[hsl(var(--primary))] mb-8">Portal do Aluno</h1>
        
        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Cadastro</TabsTrigger>
          </TabsList>
          
          {/* Login Form */}
          <TabsContent value="login">
            <Card>
              <CardHeader>
                <CardTitle>Login</CardTitle>
                <CardDescription>
                  Entre com suas credenciais para acessar o portal do aluno.
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleLoginSubmit}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Nome de usuário</Label>
                    <Input 
                      id="username"
                      name="username"
                      value={loginForm.username}
                      onChange={handleLoginChange}
                      placeholder="Digite seu nome de usuário" 
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Senha</Label>
                      <button 
                        type="button"
                        onClick={() => toast({
                          title: "Recuperação de senha",
                          description: "Funcionalidade em desenvolvimento!"
                        })}
                        className="text-sm text-[hsl(var(--secondary-blue))] hover:underline"
                      >
                        Esqueceu a senha?
                      </button>
                    </div>
                    <Input 
                      id="password"
                      name="password"
                      type="password"
                      value={loginForm.password}
                      onChange={handleLoginChange}
                      placeholder="Digite sua senha" 
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    type="submit" 
                    className="w-full bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90"
                  >
                    Entrar
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>
          
          {/* Register Form */}
          <TabsContent value="register">
            <Card>
              <CardHeader>
                <CardTitle>Novo Cadastro</CardTitle>
                <CardDescription>
                  Crie sua conta para acessar o portal do aluno e a biblioteca virtual.
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleRegisterSubmit}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Completo</Label>
                    <Input 
                      id="name"
                      name="name"
                      value={registerForm.name}
                      onChange={handleRegisterChange}
                      placeholder="Digite seu nome completo" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email"
                      name="email"
                      type="email"
                      value={registerForm.email}
                      onChange={handleRegisterChange}
                      placeholder="Digite seu email" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-username">Nome de usuário</Label>
                    <Input 
                      id="register-username"
                      name="username"
                      value={registerForm.username}
                      onChange={handleRegisterChange}
                      placeholder="Escolha um nome de usuário" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-password">Senha</Label>
                    <Input 
                      id="register-password"
                      name="password"
                      type="password"
                      value={registerForm.password}
                      onChange={handleRegisterChange}
                      placeholder="Crie uma senha segura" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirmar Senha</Label>
                    <Input 
                      id="confirm-password"
                      name="confirmPassword"
                      type="password"
                      value={registerForm.confirmPassword}
                      onChange={handleRegisterChange}
                      placeholder="Confirme sua senha" 
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    type="submit" 
                    className="w-full bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))]/90"
                  >
                    Cadastrar
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>
        </Tabs>
        
        <div className="mt-6 text-center">
          <Button variant="link" onClick={() => navigate("/")}>
            ← Voltar para a página inicial
          </Button>
        </div>
      </div>
    </div>
  );
}