// User Types
export interface User {
  id: number;
  username: string;
  password: string;
}

// University Partners
export interface University {
  id: number;
  name: string;
  country: string;
  city: string;
  description: string;
  imageUrl?: string;
  website?: string;
}

// Library Resources
export interface Resource {
  id: number;
  title: string;
  author: string;
  type: string; // "Livro" | "Artigo" | "Vídeo" | "Material"
  category: string;
  language: string;
  year: number;
  description: string;
  contentUrl?: string;
  thumbnailUrl?: string;
  featured: boolean;
}

// Testimonials
export interface Testimonial {
  id: number;
  name: string;
  role: string;
  rating: number;
  testimonial: string;
  imageUrl?: string;
}

// Contact Form Data
export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface ContactSubmission {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  submittedAt: Date;
  responded: boolean;
}

// Exchange Program Types
export interface ExchangeProgram {
  id: number;
  title: string;
  description: string;
  duration: string;
  requirements: string[];
  benefits: string[];
  applicationDeadline: string;
}

export interface ExchangeApplication {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  nationality: string;
  programId: number;
  educationLevel: string;
  motivation: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: Date;
}

export interface EducationLevel {
  id: number;
  name: string;
  description: string;
  levelOrder: number;
  active: boolean;
  createdAt: string;
}
