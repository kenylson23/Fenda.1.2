import { createClient } from '@supabase/supabase-js';

// Configuração do cliente Supabase
let supabaseUrl: string;
let supabaseAnonKey: string;

// Verificar se estamos em um ambiente de navegador (Vite) ou Node.js
if (typeof process !== 'undefined' && process.env) {
  // Ambiente Node.js
  supabaseUrl = process.env.SUPABASE_URL || '';
  supabaseAnonKey = process.env.SUPABASE_ANON_KEY || '';
} else {
  // Ambiente navegador (Vite)
  supabaseUrl = import.meta.env?.VITE_SUPABASE_URL || '';
  supabaseAnonKey = import.meta.env?.VITE_SUPABASE_ANON_KEY || '';
}

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Supabase URL ou chave anônima não definidas no ambiente');
}

// Criação do cliente Supabase
export const supabase = createClient(supabaseUrl, supabaseAnonKey);