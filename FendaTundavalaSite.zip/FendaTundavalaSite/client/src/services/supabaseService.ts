import { supabase } from '../lib/supabaseClient';
import type { 
  InsertUser, User,
  InsertStudent, Student,
  InsertTeacher, Teacher,
  InsertCourse, Course,
  InsertSubject, Subject,
  InsertClass, Class,
  InsertClassTeacher, ClassTeacher,
  InsertClassStudent, ClassStudent,
  InsertClassSubject, ClassSubject,
  InsertEducationLevel, EducationLevel,
  InsertUniversity, University,
  InsertResource, Resource,
  InsertExchangeProgram, ExchangeProgram,
  InsertExchangeApplication, ExchangeApplication,
  InsertContactSubmission, ContactSubmission
} from '@shared/schema';

// === USUÁRIOS ===
export const userService = {
  // Listar todos os usuários
  getAll: async (): Promise<User[]> => {
    const { data, error } = await supabase
      .from('users')
      .select('*');
    
    if (error) {
      console.error('Erro ao buscar usuários:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar usuário por ID
  getById: async (id: number): Promise<User | null> => {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar usuário com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Buscar usuário por nome de usuário
  getByUsername: async (username: string): Promise<User | null> => {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('username', username)
      .single();
    
    if (error && error.code !== 'PGRST116') { // PGRST116 é o código para "nenhum resultado encontrado"
      console.error(`Erro ao buscar usuário com username ${username}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar novo usuário
  create: async (user: InsertUser): Promise<User> => {
    const { data, error } = await supabase
      .from('users')
      .insert(user)
      .select()
      .single();
    
    if (error) {
      console.error('Erro ao criar usuário:', error);
      throw error;
    }
    
    return data;
  },
  
  // Atualizar usuário existente
  update: async (id: number, user: Partial<InsertUser>): Promise<User> => {
    const { data, error } = await supabase
      .from('users')
      .update(user)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar usuário com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Remover usuário
  remove: async (id: number): Promise<void> => {
    const { error } = await supabase
      .from('users')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error(`Erro ao remover usuário com ID ${id}:`, error);
      throw error;
    }
  }
};

// === ESTUDANTES ===
export const studentService = {
  // Listar todos os estudantes
  getAll: async (): Promise<Student[]> => {
    const { data, error } = await supabase
      .from('students')
      .select('*, user:users(*)');
    
    if (error) {
      console.error('Erro ao buscar estudantes:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar estudante por ID
  getById: async (id: number): Promise<Student | null> => {
    const { data, error } = await supabase
      .from('students')
      .select('*, user:users(*)')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar estudante com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar novo estudante (com usuário associado)
  create: async (userData: InsertUser, studentData: Omit<InsertStudent, "userId">): Promise<Student> => {
    // Primeiro criamos o usuário
    const user = await userService.create(userData);
    
    // Em seguida, criamos o estudante associado ao usuário
    const { data, error } = await supabase
      .from('students')
      .insert({ ...studentData, userId: user.id })
      .select('*, user:users(*)')
      .single();
    
    if (error) {
      console.error('Erro ao criar estudante:', error);
      // Em caso de erro, tentar limpar o usuário criado para evitar órfãos
      try {
        await userService.remove(user.id);
      } catch (cleanupError) {
        console.error('Erro ao limpar usuário após falha na criação do estudante:', cleanupError);
      }
      throw error;
    }
    
    return data;
  },
  
  // Atualizar estudante existente
  update: async (id: number, studentData: Partial<Omit<InsertStudent, "userId">>): Promise<Student> => {
    const { data, error } = await supabase
      .from('students')
      .update(studentData)
      .eq('id', id)
      .select('*, user:users(*)')
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar estudante com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  }
};

// === PROFESSORES ===
export const teacherService = {
  // Listar todos os professores
  getAll: async (): Promise<Teacher[]> => {
    const { data, error } = await supabase
      .from('teachers')
      .select('*, user:users(*)');
    
    if (error) {
      console.error('Erro ao buscar professores:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar professor por ID
  getById: async (id: number): Promise<Teacher | null> => {
    const { data, error } = await supabase
      .from('teachers')
      .select('*, user:users(*)')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar professor com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar novo professor (com usuário associado)
  create: async (userData: InsertUser, teacherData: Omit<InsertTeacher, "userId">): Promise<Teacher> => {
    // Primeiro criamos o usuário
    const user = await userService.create(userData);
    
    // Em seguida, criamos o professor associado ao usuário
    const { data, error } = await supabase
      .from('teachers')
      .insert({ ...teacherData, userId: user.id })
      .select('*, user:users(*)')
      .single();
    
    if (error) {
      console.error('Erro ao criar professor:', error);
      // Em caso de erro, tentar limpar o usuário criado para evitar órfãos
      try {
        await userService.remove(user.id);
      } catch (cleanupError) {
        console.error('Erro ao limpar usuário após falha na criação do professor:', cleanupError);
      }
      throw error;
    }
    
    return data;
  },
  
  // Atualizar professor existente
  update: async (id: number, teacherData: Partial<Omit<InsertTeacher, "userId">>): Promise<Teacher> => {
    const { data, error } = await supabase
      .from('teachers')
      .update(teacherData)
      .eq('id', id)
      .select('*, user:users(*)')
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar professor com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  }
};

// === CURSOS ===
export const courseService = {
  // Listar todos os cursos
  getAll: async (): Promise<Course[]> => {
    const { data, error } = await supabase
      .from('courses')
      .select('*, educationLevel:education_levels(*)');
    
    if (error) {
      console.error('Erro ao buscar cursos:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar curso por ID
  getById: async (id: number): Promise<Course | null> => {
    const { data, error } = await supabase
      .from('courses')
      .select('*, educationLevel:education_levels(*)')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar curso com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar novo curso
  create: async (course: InsertCourse): Promise<Course> => {
    const { data, error } = await supabase
      .from('courses')
      .insert(course)
      .select('*, educationLevel:education_levels(*)')
      .single();
    
    if (error) {
      console.error('Erro ao criar curso:', error);
      throw error;
    }
    
    return data;
  },
  
  // Atualizar curso existente
  update: async (id: number, course: Partial<InsertCourse>): Promise<Course> => {
    const { data, error } = await supabase
      .from('courses')
      .update(course)
      .eq('id', id)
      .select('*, educationLevel:education_levels(*)')
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar curso com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  }
};

// === DISCIPLINAS ===
export const subjectService = {
  // Listar todas as disciplinas
  getAll: async (): Promise<Subject[]> => {
    const { data, error } = await supabase
      .from('subjects')
      .select('*, course:courses(*)');
    
    if (error) {
      console.error('Erro ao buscar disciplinas:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar disciplina por ID
  getById: async (id: number): Promise<Subject | null> => {
    const { data, error } = await supabase
      .from('subjects')
      .select('*, course:courses(*)')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar disciplina com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Buscar disciplinas por curso
  getByCourse: async (courseId: number): Promise<Subject[]> => {
    const { data, error } = await supabase
      .from('subjects')
      .select('*, course:courses(*)')
      .eq('course_id', courseId);
    
    if (error) {
      console.error(`Erro ao buscar disciplinas do curso ${courseId}:`, error);
      throw error;
    }
    
    return data || [];
  },
  
  // Criar nova disciplina
  create: async (subject: InsertSubject): Promise<Subject> => {
    const { data, error } = await supabase
      .from('subjects')
      .insert(subject)
      .select('*, course:courses(*)')
      .single();
    
    if (error) {
      console.error('Erro ao criar disciplina:', error);
      throw error;
    }
    
    return data;
  },
  
  // Atualizar disciplina existente
  update: async (id: number, subject: Partial<InsertSubject>): Promise<Subject> => {
    const { data, error } = await supabase
      .from('subjects')
      .update(subject)
      .eq('id', id)
      .select('*, course:courses(*)')
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar disciplina com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  }
};

// === NÍVEIS DE ENSINO ===
export const educationLevelService = {
  // Listar todos os níveis de ensino
  getAll: async (): Promise<EducationLevel[]> => {
    const { data, error } = await supabase
      .from('education_levels')
      .select('*')
      .order('level_order', { ascending: true });
    
    if (error) {
      console.error('Erro ao buscar níveis de ensino:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar nível de ensino por ID
  getById: async (id: number): Promise<EducationLevel | null> => {
    const { data, error } = await supabase
      .from('education_levels')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar nível de ensino com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar novo nível de ensino
  create: async (educationLevel: InsertEducationLevel): Promise<EducationLevel> => {
    const { data, error } = await supabase
      .from('education_levels')
      .insert(educationLevel)
      .select()
      .single();
    
    if (error) {
      console.error('Erro ao criar nível de ensino:', error);
      throw error;
    }
    
    return data;
  },
  
  // Atualizar nível de ensino existente
  update: async (id: number, educationLevel: Partial<InsertEducationLevel>): Promise<EducationLevel> => {
    const { data, error } = await supabase
      .from('education_levels')
      .update(educationLevel)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar nível de ensino com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  }
};

// === TURMAS ===
export const classService = {
  // Listar todas as turmas
  getAll: async (): Promise<Class[]> => {
    const { data, error } = await supabase
      .from('classes')
      .select('*, educationLevel:education_levels(*)');
    
    if (error) {
      console.error('Erro ao buscar turmas:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar turma por ID
  getById: async (id: number): Promise<Class | null> => {
    const { data, error } = await supabase
      .from('classes')
      .select('*, educationLevel:education_levels(*)')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar turma com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar nova turma
  create: async (classData: InsertClass): Promise<Class> => {
    const { data, error } = await supabase
      .from('classes')
      .insert(classData)
      .select('*, educationLevel:education_levels(*)')
      .single();
    
    if (error) {
      console.error('Erro ao criar turma:', error);
      throw error;
    }
    
    return data;
  },
  
  // Atualizar turma existente
  update: async (id: number, classData: Partial<InsertClass>): Promise<Class> => {
    const { data, error } = await supabase
      .from('classes')
      .update(classData)
      .eq('id', id)
      .select('*, educationLevel:education_levels(*)')
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar turma com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  }
};

// === UNIVERSIDADES ===
export const universityService = {
  // Listar todas as universidades
  getAll: async (): Promise<University[]> => {
    const { data, error } = await supabase
      .from('universities')
      .select('*');
    
    if (error) {
      console.error('Erro ao buscar universidades:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar universidade por ID
  getById: async (id: number): Promise<University | null> => {
    const { data, error } = await supabase
      .from('universities')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar universidade com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar nova universidade
  create: async (university: InsertUniversity): Promise<University> => {
    const { data, error } = await supabase
      .from('universities')
      .insert(university)
      .select()
      .single();
    
    if (error) {
      console.error('Erro ao criar universidade:', error);
      throw error;
    }
    
    return data;
  },
  
  // Atualizar universidade existente
  update: async (id: number, university: Partial<InsertUniversity>): Promise<University> => {
    const { data, error } = await supabase
      .from('universities')
      .update(university)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar universidade com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  }
};

// === RECURSOS (BIBLIOTECA VIRTUAL) ===
export const resourceService = {
  // Listar todos os recursos
  getAll: async (options?: { limit?: number; featured?: boolean }): Promise<Resource[]> => {
    let query = supabase
      .from('resources')
      .select('*');
    
    if (options?.featured) {
      query = query.eq('featured', true);
    }
    
    if (options?.limit) {
      query = query.limit(options.limit);
    }
    
    const { data, error } = await query;
    
    if (error) {
      console.error('Erro ao buscar recursos:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar recurso por ID
  getById: async (id: number): Promise<Resource | null> => {
    const { data, error } = await supabase
      .from('resources')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar recurso com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar novo recurso
  create: async (resource: InsertResource): Promise<Resource> => {
    const { data, error } = await supabase
      .from('resources')
      .insert(resource)
      .select()
      .single();
    
    if (error) {
      console.error('Erro ao criar recurso:', error);
      throw error;
    }
    
    return data;
  },
  
  // Atualizar recurso existente
  update: async (id: number, resource: Partial<InsertResource>): Promise<Resource> => {
    const { data, error } = await supabase
      .from('resources')
      .update(resource)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar recurso com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  }
};

// === PROGRAMAS DE INTERCÂMBIO ===
export const exchangeProgramService = {
  // Listar todos os programas de intercâmbio
  getAll: async (): Promise<ExchangeProgram[]> => {
    const { data, error } = await supabase
      .from('exchange_programs')
      .select('*');
    
    if (error) {
      console.error('Erro ao buscar programas de intercâmbio:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar programa de intercâmbio por ID
  getById: async (id: number): Promise<ExchangeProgram | null> => {
    const { data, error } = await supabase
      .from('exchange_programs')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar programa de intercâmbio com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar novo programa de intercâmbio
  create: async (program: InsertExchangeProgram): Promise<ExchangeProgram> => {
    const { data, error } = await supabase
      .from('exchange_programs')
      .insert(program)
      .select()
      .single();
    
    if (error) {
      console.error('Erro ao criar programa de intercâmbio:', error);
      throw error;
    }
    
    return data;
  },
  
  // Atualizar programa de intercâmbio existente
  update: async (id: number, program: Partial<InsertExchangeProgram>): Promise<ExchangeProgram> => {
    const { data, error } = await supabase
      .from('exchange_programs')
      .update(program)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error(`Erro ao atualizar programa de intercâmbio com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  }
};

// === FORMULÁRIOS DE CONTATO ===
export const contactSubmissionService = {
  // Listar todos os formulários de contato
  getAll: async (): Promise<ContactSubmission[]> => {
    const { data, error } = await supabase
      .from('contact_submissions')
      .select('*')
      .order('submitted_at', { ascending: false });
    
    if (error) {
      console.error('Erro ao buscar formulários de contato:', error);
      throw error;
    }
    
    return data || [];
  },
  
  // Buscar formulário de contato por ID
  getById: async (id: number): Promise<ContactSubmission | null> => {
    const { data, error } = await supabase
      .from('contact_submissions')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error(`Erro ao buscar formulário de contato com ID ${id}:`, error);
      throw error;
    }
    
    return data;
  },
  
  // Criar novo formulário de contato
  create: async (submission: InsertContactSubmission): Promise<ContactSubmission> => {
    const { data, error } = await supabase
      .from('contact_submissions')
      .insert(submission)
      .select()
      .single();
    
    if (error) {
      console.error('Erro ao criar formulário de contato:', error);
      throw error;
    }
    
    return data;
  },
  
  // Marcar formulário como respondido
  markAsResponded: async (id: number): Promise<ContactSubmission> => {
    const { data, error } = await supabase
      .from('contact_submissions')
      .update({ responded: true })
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error(`Erro ao marcar formulário de contato ${id} como respondido:`, error);
      throw error;
    }
    
    return data;
  }
};

// Exportar todos os serviços em um único objeto
export const supabaseServices = {
  users: userService,
  students: studentService,
  teachers: teacherService,
  courses: courseService,
  subjects: subjectService,
  educationLevels: educationLevelService,
  classes: classService,
  universities: universityService,
  resources: resourceService,
  exchangePrograms: exchangeProgramService,
  contactSubmissions: contactSubmissionService
};