import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-[#333333] text-white pt-16 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center mb-6">
              <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                <span className="text-[hsl(var(--primary))] text-2xl font-bold">FT</span>
              </div>
              <div>
                <span className="font-bold text-xl">Fenda da Tundavala</span>
                <span className="block text-xs text-gray-400">Intercâmbio Angola-China</span>
              </div>
            </div>
            <p className="text-gray-400 mb-6">
              Formando cidadãos globais através da educação intercultural e do intercâmbio entre Angola e China.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-[hsl(var(--secondary))] transition">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-white hover:text-[hsl(var(--secondary))] transition">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-white hover:text-[hsl(var(--secondary))] transition">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-white hover:text-[hsl(var(--secondary))] transition">
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-6">Links Rápidos</h4>
            <ul className="space-y-3">
              <li><Link href="/" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Início</Link></li>
              <li><Link href="/about" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Sobre Nós</Link></li>
              <li><Link href="/exchange" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Programa de Intercâmbio</Link></li>
              <li><Link href="/library" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Biblioteca Virtual</Link></li>
              <li><Link href="/news" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Notícias e Eventos</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Contacto</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-6">Programas</h4>
            <ul className="space-y-3">
              <li><Link href="/exchange" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Intercâmbio Estudantil</Link></li>
              <li><Link href="/courses" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Cursos de Línguas</Link></li>
              <li><Link href="/programs" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Programas Acadêmicos</Link></li>
              <li><Link href="/scholarships" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Bolsas de Estudo</Link></li>
              <li><Link href="/events" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Eventos Culturais</Link></li>
              <li><Link href="/workshops" className="text-gray-400 hover:text-[hsl(var(--secondary))] transition">Workshops</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-6">Contacto</h4>
            <ul className="space-y-3 text-gray-400">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-3 text-[hsl(var(--secondary))]"></i>
                <span>Avenida Principal, Lubango, Huíla, Angola</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-phone-alt mt-1 mr-3 text-[hsl(var(--secondary))]"></i>
                <span>+244 123 456 789</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-envelope mt-1 mr-3 text-[hsl(var(--secondary))]"></i>
                <span>info@fendadatundavala.ao</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-clock mt-1 mr-3 text-[hsl(var(--secondary))]"></i>
                <span>Segunda a Sexta: 8:00 - 17:00<br/>Sábado: 8:00 - 12:00</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500">© {new Date().getFullYear()} Kenylson Lourenço. Todos os direitos reservados.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-gray-500 hover:text-[hsl(var(--secondary))] text-sm">Política de Privacidade</a>
            <a href="#" className="text-gray-500 hover:text-[hsl(var(--secondary))] text-sm">Termos de Uso</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
