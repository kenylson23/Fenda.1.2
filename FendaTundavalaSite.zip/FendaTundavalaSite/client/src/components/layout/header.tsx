import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import LanguageToggle from "@/components/ui/language-toggle";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  const navLinks = [
    { href: "/", label: "Início" },
    { href: "/about", label: "Sobre" },
    { href: "/exchange", label: "Intercâmbio" },
    { href: "/library", label: "Biblioteca Virtual" },
    { href: "/contact", label: "Contacto" },
  ];

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="bg-white shadow-md">
      {/* Top Bar with contact info and language toggle */}
      <div className="bg-[hsl(var(--primary))] text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-4 text-sm">
            <span><i className="fas fa-phone-alt mr-1"></i> +244 123 456 789</span>
            <span><i className="fas fa-envelope mr-1"></i> info@fendadatundavala.ao</span>
          </div>
          <div className="flex items-center space-x-3">
            <LanguageToggle />
            <div className="social-links hidden sm:flex space-x-2">
              <a href="#" aria-label="Facebook"><i className="fab fa-facebook-f"></i></a>
              <a href="#" aria-label="Instagram"><i className="fab fa-instagram"></i></a>
              <a href="#" aria-label="Twitter"><i className="fab fa-twitter"></i></a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Navigation */}
      <nav className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            {/* School logo with name */}
            <Link href="/" className="flex items-center">
              <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                <span className="text-[hsl(var(--primary))] text-2xl font-bold">FT</span>
              </div>
              <div>
                <span className="font-bold text-xl text-[hsl(var(--primary))]">Fenda da Tundavala</span>
                <span className="block text-xs text-[hsl(var(--secondary-blue))]">Intercâmbio Angola-China</span>
              </div>
            </Link>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={toggleMobileMenu} 
              className="text-[#333333] hover:text-[hsl(var(--primary))] focus:outline-none"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link 
                key={link.href}
                href={link.href}
                className={`font-medium ${
                  location === link.href 
                    ? "text-[hsl(var(--primary))] border-b-2 border-[hsl(var(--secondary))]" 
                    : "hover:text-[hsl(var(--primary))]"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link 
              href="/portal" 
              className="bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-4 py-2 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition"
            >
              Portal do Aluno
            </Link>
          </div>
        </div>
        
        {/* Mobile menu */}
        <div className={`md:hidden ${mobileMenuOpen ? "block" : "hidden"} mt-4 pb-4`}>
          <div className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              <Link 
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`font-medium ${
                  location === link.href 
                    ? "text-[hsl(var(--primary))]" 
                    : "hover:text-[hsl(var(--primary))]"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link 
              href="/portal" 
              onClick={() => setMobileMenuOpen(false)}
              className="bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-4 py-2 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition text-center"
            >
              Portal do Aluno
            </Link>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;
