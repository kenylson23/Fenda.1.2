import { useState } from "react";

const LanguageToggle = () => {
  const [currentLanguage, setCurrentLanguage] = useState<"PT" | "中文">("PT");

  const toggleLanguage = (lang: "PT" | "中文") => {
    setCurrentLanguage(lang);
    // In a real implementation, this would trigger language change throughout the app
  };

  return (
    <div className="language-toggle">
      <button 
        className={`text-sm font-medium px-2 py-1 rounded ${
          currentLanguage === "PT" 
            ? "bg-white bg-opacity-20 hover:bg-opacity-30" 
            : "hover:bg-white hover:bg-opacity-10"
        }`}
        onClick={() => toggleLanguage("PT")}
      >
        PT
      </button>
      <button 
        className={`text-sm font-medium px-2 py-1 rounded ${
          currentLanguage === "中文" 
            ? "bg-white bg-opacity-20 hover:bg-opacity-30" 
            : "hover:bg-white hover:bg-opacity-10"
        }`}
        onClick={() => toggleLanguage("中文")}
      >
        中文
      </button>
    </div>
  );
};

export default LanguageToggle;
