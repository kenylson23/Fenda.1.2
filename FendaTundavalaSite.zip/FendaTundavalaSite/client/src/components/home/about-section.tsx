import { Link } from "wouter";

const AboutSection = () => {
  return (
    <section id="about" className="py-20 mt-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block bg-[hsl(var(--secondary-yellow))] px-3 py-1 rounded-full text-[hsl(var(--primary))] text-sm font-semibold mb-3">
            Sobre Nós
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-[hsl(var(--primary))]">
            Nossa História e Missão
          </h2>
          <div className="w-16 h-1 bg-[hsl(var(--secondary))] mx-auto mt-4"></div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div>
            <h3 className="text-xl font-semibold mb-4 text-[hsl(var(--primary))]">
              A Fenda da Tundavala
            </h3>
            <p className="mb-4">
              Fundada em 2008, a nossa instituição leva o nome da majestosa formação geológica situada na província de Huíla, em Angola. Assim como a Fenda da Tundavala representa uma abertura para paisagens deslumbrantes, nossa escola abre horizontes educacionais para os nossos alunos.
            </p>
            <p className="mb-6">
              Somos uma instituição de ensino comprometida com a excelência acadêmica e o desenvolvimento integral dos nossos alunos, preparando-os para um mundo globalizado através do programa de intercâmbio Angola-China.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="flex items-start">
                <div className="bg-[hsl(var(--secondary-yellow))] p-2 rounded-lg mr-3">
                  <i className="fas fa-book text-[hsl(var(--primary))]"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-[hsl(var(--primary))]">Educação de Qualidade</h4>
                  <p className="text-sm">Currículo integrado com padrões internacionais</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-[hsl(var(--secondary-yellow))] p-2 rounded-lg mr-3">
                  <i className="fas fa-globe-africa text-[hsl(var(--primary))]"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-[hsl(var(--primary))]">Perspectiva Global</h4>
                  <p className="text-sm">Formação multicultural e multilíngue</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-[hsl(var(--secondary-yellow))] p-2 rounded-lg mr-3">
                  <i className="fas fa-handshake text-[hsl(var(--primary))]"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-[hsl(var(--primary))]">Valores Éticos</h4>
                  <p className="text-sm">Desenvolvimento de cidadãos responsáveis</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-[hsl(var(--secondary-yellow))] p-2 rounded-lg mr-3">
                  <i className="fas fa-lightbulb text-[hsl(var(--primary))]"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-[hsl(var(--primary))]">Inovação</h4>
                  <p className="text-sm">Metodologias modernas e tecnologia</p>
                </div>
              </div>
            </div>
            
            <Link href="/about" className="inline-block mt-2 text-[hsl(var(--primary))] font-medium hover:text-[hsl(var(--secondary-blue))]">
              <span>Saiba mais sobre nossa história</span>
              <i className="fas fa-arrow-right ml-2"></i>
            </Link>
          </div>
          
          <div className="relative">
            <img 
              src="https://pixabay.com/get/g7b595512f93e2ed136cf729c831cbdbdbbb1cb13390ad24121ae3fbb796cb94fa6f6d348841e4385ff4d93512d171062_1280.jpg" 
              alt="Vista da Fenda da Tundavala em Angola" 
              className="rounded-lg shadow-lg w-full h-auto object-cover" 
            />
            <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg hidden md:block">
              <div className="flex items-center">
                <div className="text-center mr-4">
                  <span className="block text-3xl font-bold text-[hsl(var(--primary))]">15</span>
                  <span className="text-sm">Anos de</span>
                  <span className="block text-sm">Excelência</span>
                </div>
                <div className="h-10 w-px bg-gray-300"></div>
                <div className="ml-4">
                  <div className="flex">
                    <i className="fas fa-star text-[hsl(var(--secondary))]"></i>
                    <i className="fas fa-star text-[hsl(var(--secondary))]"></i>
                    <i className="fas fa-star text-[hsl(var(--secondary))]"></i>
                    <i className="fas fa-star text-[hsl(var(--secondary))]"></i>
                    <i className="fas fa-star text-[hsl(var(--secondary))]"></i>
                  </div>
                  <p className="text-sm">Instituição Premiada</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
