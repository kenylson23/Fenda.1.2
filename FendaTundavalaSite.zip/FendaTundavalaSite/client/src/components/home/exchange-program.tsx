import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";

const ExchangeProgram = () => {
  const { data: universities } = useQuery({
    queryKey: ['/api/universities'],
    staleTime: Infinity,
  });

  return (
    <section id="exchange" className="py-20 bg-[hsl(var(--primary))] text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block bg-[hsl(var(--secondary))] px-3 py-1 rounded-full text-[hsl(var(--primary))] text-sm font-semibold mb-3">
            Programa de Intercâmbio
          </span>
          <h2 className="text-3xl md:text-4xl font-bold">
            Parceria Angola-China
          </h2>
          <div className="w-16 h-1 bg-[hsl(var(--secondary))] mx-auto mt-4"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <img 
              src="https://pixabay.com/get/gb225f71277549b658fafd9f5c5cc357e130468d8e4e4b66f37f1475736000ffecac845861959e3212f272f6686b0ebf19212056aa386c4f1079285c1ca3f9104_1280.jpg" 
              alt="Estudantes angolanos e chineses em cooperação acadêmica" 
              className="rounded-lg shadow-lg w-full h-auto" 
            />
            
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="bg-[hsl(var(--secondary-blue))] bg-opacity-50 rounded-lg p-4 text-center">
                <img 
                  src="https://images.unsplash.com/photo-1566888596782-c7f41cc184c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=120" 
                  alt="Campus universitário em Pequim" 
                  className="w-full h-24 object-cover rounded mb-2" 
                />
                <p className="font-semibold">Estudo na China</p>
              </div>
              <div className="bg-[hsl(var(--secondary-blue))] bg-opacity-50 rounded-lg p-4 text-center">
                <img 
                  src="https://pixabay.com/get/g97e02e0501492e36c90afd573f6866e4d86c95f9007ba9aff14e7776799dd8781fde1a151d26d2849bf08b76cf555858aa60c7f91911a85d20cff3284db42c37_1280.jpg" 
                  alt="Aula de mandarim para estudantes angolanos" 
                  className="w-full h-24 object-cover rounded mb-2" 
                />
                <p className="font-semibold">Imersão Cultural</p>
              </div>
            </div>
          </div>
          
          <div className="order-1 md:order-2">
            <h3 className="text-xl font-semibold mb-4">Intercâmbio Cultural e Acadêmico</h3>
            <p className="mb-4">
              A Fenda da Tundavala orgulha-se de ser uma instituição pioneira no programa de intercâmbio entre Angola e China, promovendo o entendimento mútuo e fortalecendo os laços entre os dois países.
            </p>
            <p className="mb-6">
              Nosso programa oferece aos estudantes a oportunidade de experimentar imersão cultural, aprendizagem de idiomas e educação de alta qualidade em ambos os países.
            </p>
            
            <div className="space-y-4 mb-6">
              <div className="bg-white bg-opacity-10 p-4 rounded-lg">
                <h4 className="text-[hsl(var(--secondary))] font-semibold mb-2">Bolsas de Estudo</h4>
                <p className="text-sm">
                  Oferecemos bolsas de estudo para alunos talentosos, permitindo que estudem em universidades parceiras na China.
                </p>
              </div>
              <div className="bg-white bg-opacity-10 p-4 rounded-lg">
                <h4 className="text-[hsl(var(--secondary))] font-semibold mb-2">Cursos de Línguas</h4>
                <p className="text-sm">
                  Programas intensivos de mandarim para estudantes angolanos e português para estudantes chineses.
                </p>
              </div>
              <div className="bg-white bg-opacity-10 p-4 rounded-lg">
                <h4 className="text-[hsl(var(--secondary))] font-semibold mb-2">Intercâmbio de Professores</h4>
                <p className="text-sm">
                  Educadores qualificados de ambos os países contribuem para nossa abordagem pedagógica diversificada.
                </p>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4">
              <Link 
                href="/exchange/apply" 
                className="bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-4 py-2 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition"
              >
                Inscrever-se
              </Link>
              <Link 
                href="/exchange" 
                className="border border-white px-4 py-2 rounded-lg font-medium hover:bg-white hover:bg-opacity-10 transition"
              >
                Saber Mais
              </Link>
            </div>
          </div>
        </div>
        
        <div className="mt-16">
          <h3 className="text-xl font-semibold mb-6 text-center">Nossas Universidades Parceiras</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {universities ? (
              universities.map((university: any) => (
                <div
                  key={university.id}
                  className="bg-white bg-opacity-10 p-4 rounded-lg flex items-center justify-center h-24 hover:bg-opacity-20 transition"
                >
                  <span className="text-center font-medium">{university.name}</span>
                </div>
              ))
            ) : (
              // Fallback if data isn't loaded yet
              Array(6).fill(0).map((_, index) => (
                <div
                  key={index}
                  className="bg-white bg-opacity-10 p-4 rounded-lg flex items-center justify-center h-24 hover:bg-opacity-20 transition"
                >
                  <span className="text-center font-medium">Carregando...</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExchangeProgram;
