const FeaturesSection = () => {
  const features = [
    {
      icon: "fas fa-graduation-cap",
      title: "Educação Bilíngue",
      description: "Programas educacionais em português e mandarim, preparando os alunos para um mundo globalizado."
    },
    {
      icon: "fas fa-users",
      title: "Corpo Docente Diversificado",
      description: "Professores angolanos e chineses altamente qualificados, trazendo perspectivas diversas para a sala de aula."
    },
    {
      icon: "fas fa-laptop",
      title: "Tecnologia Moderna",
      description: "Infraestrutura tecnológica atualizada, incluindo biblioteca virtual com milhares de recursos digitais."
    },
    {
      icon: "fas fa-globe",
      title: "Oportunidades Globais",
      description: "Acesso a programas de intercâmbio, visitas de estudo e colaborações internacionais exclusivas."
    },
    {
      icon: "fas fa-medal",
      title: "Excelência Acadêmica",
      description: "Altas taxas de aprovação em universidades prestigiadas e programas competitivos internacionalmente."
    },
    {
      icon: "fas fa-hands-helping",
      title: "Suporte Personalizado",
      description: "Acompanhamento individualizado para cada aluno, com foco no desenvolvimento acadêmico e pessoal."
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block bg-[hsl(var(--secondary-yellow))] px-3 py-1 rounded-full text-[hsl(var(--primary))] text-sm font-semibold mb-3">
            Características
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-[hsl(var(--primary))]">
            Por Que Escolher a Fenda da Tundavala?
          </h2>
          <div className="w-16 h-1 bg-[hsl(var(--secondary))] mx-auto mt-4"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="bg-[hsl(var(--secondary))] w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <i className={`${feature.icon} text-[hsl(var(--primary))] text-xl`}></i>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-[hsl(var(--primary))]">
                {feature.title}
              </h3>
              <p>{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
