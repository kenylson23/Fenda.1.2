import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";

const resourceCategories = [
  "Todas as categorias",
  "Livros Acadêmicos",
  "Revistas Científicas",
  "Material Didático",
  "Mídia Audiovisual"
];

const languages = ["Todos os idiomas", "Português", "Mandarim", "Inglês"];

const VirtualLibrary = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState(resourceCategories[0]);
  const [languageFilter, setLanguageFilter] = useState(languages[0]);

  const { data: featuredResources, isLoading } = useQuery({
    queryKey: ['/api/resources/featured'],
  });

  return (
    <section id="library" className="py-20 bg-gradient-to-r from-[hsl(var(--primary))] to-[hsl(var(--secondary-blue))] text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block bg-[hsl(var(--secondary))] px-3 py-1 rounded-full text-[hsl(var(--primary))] text-sm font-semibold mb-3">
            Biblioteca
          </span>
          <h2 className="text-3xl md:text-4xl font-bold">Biblioteca Virtual</h2>
          <div className="w-16 h-1 bg-[hsl(var(--secondary))] mx-auto mt-4"></div>
          <p className="max-w-2xl mx-auto mt-4">
            Acesse milhares de recursos educacionais em português e mandarim, incluindo livros, artigos científicos, vídeos e materiais didáticos.
          </p>
        </div>
        
        {/* Library Search Interface */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-10 text-[#333333]">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-grow">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Pesquisar por título, autor ou assunto..." 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))] focus:ring-opacity-30 focus:outline-none" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <button className="absolute right-3 top-3 text-gray-400 hover:text-[hsl(var(--primary))]">
                  <i className="fas fa-search"></i>
                </button>
              </div>
            </div>
            <div className="flex gap-2">
              <select 
                className="px-4 py-3 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:outline-none"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                {resourceCategories.map((category) => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
              <select 
                className="px-4 py-3 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:outline-none"
                value={languageFilter}
                onChange={(e) => setLanguageFilter(e.target.value)}
              >
                {languages.map((language) => (
                  <option key={language} value={language}>{language}</option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <span onClick={() => setSearchTerm("História de Angola")} className="inline-block px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-[#333333] cursor-pointer hover:bg-gray-200">
              História de Angola
            </span>
            <span onClick={() => setSearchTerm("Cultura Chinesa")} className="inline-block px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-[#333333] cursor-pointer hover:bg-gray-200">
              Cultura Chinesa
            </span>
            <span onClick={() => setSearchTerm("Ciências")} className="inline-block px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-[#333333] cursor-pointer hover:bg-gray-200">
              Ciências
            </span>
            <span onClick={() => setSearchTerm("Matemática")} className="inline-block px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-[#333333] cursor-pointer hover:bg-gray-200">
              Matemática
            </span>
            <span onClick={() => setSearchTerm("Literatura")} className="inline-block px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-[#333333] cursor-pointer hover:bg-gray-200">
              Literatura
            </span>
            <span onClick={() => setSearchTerm("Tecnologia")} className="inline-block px-3 py-1 bg-gray-100 rounded-full text-sm font-medium text-[#333333] cursor-pointer hover:bg-gray-200">
              Tecnologia
            </span>
          </div>
        </div>
        
        {/* Featured Resources */}
        <h3 className="text-xl font-semibold mb-6">Recursos em Destaque</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {isLoading ? (
            // Loading state - show skeletons
            Array(4).fill(0).map((_, index) => (
              <div key={index} className="bg-white bg-opacity-10 rounded-lg overflow-hidden animate-pulse">
                <div className="h-40 bg-white bg-opacity-5"></div>
                <div className="p-4">
                  <div className="h-5 w-16 bg-white bg-opacity-20 rounded-full mb-2"></div>
                  <div className="h-6 bg-white bg-opacity-20 rounded mb-2"></div>
                  <div className="h-4 w-24 bg-white bg-opacity-20 rounded mb-3"></div>
                  <div className="flex justify-between items-center">
                    <div className="h-4 w-20 bg-white bg-opacity-20 rounded"></div>
                    <div className="h-6 w-6 rounded-full bg-white bg-opacity-20"></div>
                  </div>
                </div>
              </div>
            ))
          ) : featuredResources ? (
            featuredResources.map((resource: any) => (
              <div 
                key={resource.id} 
                className="bg-white bg-opacity-10 rounded-lg overflow-hidden hover:bg-opacity-20 transition"
              >
                <div className="h-40 bg-[hsl(var(--primary))]">
                  <div className="w-full h-full flex items-center justify-center">
                    <i className={`fas ${
                      resource.type === 'Livro' ? 'fa-book' : 
                      resource.type === 'Artigo' ? 'fa-newspaper' :
                      resource.type === 'Vídeo' ? 'fa-video' : 'fa-file-alt'
                    } text-4xl text-[hsl(var(--secondary))]`}></i>
                  </div>
                </div>
                <div className="p-4">
                  <span className="text-xs bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-2 py-1 rounded-full">
                    {resource.type}
                  </span>
                  <h4 className="font-medium mt-2">{resource.title}</h4>
                  <p className="text-sm text-gray-300 mt-1">{resource.author}</p>
                  <div className="flex justify-between items-center mt-3">
                    <span className="text-xs">{resource.year} • {resource.language}</span>
                    <Link href={`/library/resource/${resource.id}`} className="text-[hsl(var(--secondary))] hover:text-[hsl(var(--secondary-yellow))]">
                      <i className="fas fa-arrow-right"></i>
                    </Link>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-4 text-center py-8">
              <p>Não foi possível carregar os recursos. Tente novamente mais tarde.</p>
            </div>
          )}
        </div>
        
        <div className="text-center mt-8">
          <Link 
            href="/library" 
            className="inline-block bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-6 py-3 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition"
          >
            Explorar Biblioteca Completa
          </Link>
        </div>
      </div>
    </section>
  );
};

export default VirtualLibrary;
