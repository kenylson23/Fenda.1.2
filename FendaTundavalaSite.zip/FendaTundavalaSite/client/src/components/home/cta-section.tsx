import { Link } from "wouter";

const CTASection = () => {
  return (
    <section className="py-16 bg-[hsl(var(--primary))] text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          Pronto para Iniciar sua Jornada Global?
        </h2>
        <p className="max-w-2xl mx-auto mb-8 text-lg">
          Junte-se à Fenda da Tundavala e faça parte do programa de intercâmbio Angola-China, ampliando seus horizontes acadêmicos e culturais.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link 
            href="/exchange/apply" 
            className="bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-6 py-3 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition"
          >
            Candidatar-se Agora
          </Link>
          <Link 
            href="/contact" 
            className="border border-white px-6 py-3 rounded-lg font-medium hover:bg-white hover:text-[hsl(var(--primary))] transition"
          >
            Agendar uma Visita
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
