import { useState } from "react";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

const ContactSection = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ContactFormData>();
  
  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/contact", data);
      toast({
        title: "Mensagem enviada",
        description: "Obrigado pelo seu contato. Responderemos o mais breve possível.",
      });
      reset();
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível enviar sua mensagem. Tente novamente mais tarde.",
        variant: "destructive",
      });
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="inline-block bg-[hsl(var(--secondary-yellow))] px-3 py-1 rounded-full text-[hsl(var(--primary))] text-sm font-semibold mb-3">
            Contacto
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-[hsl(var(--primary))]">
            Entre em Contacto
          </h2>
          <div className="w-16 h-1 bg-[hsl(var(--secondary))] mx-auto mt-4"></div>
          <p className="max-w-2xl mx-auto mt-4">
            Estamos disponíveis para responder a todas as suas perguntas sobre a nossa instituição e o programa de intercâmbio Angola-China.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-6 text-[hsl(var(--primary))]">Enviar Mensagem</h3>
              
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Nome Completo
                    </label>
                    <input 
                      id="name" 
                      {...register("name", { required: "Nome é obrigatório" })}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))] focus:ring-opacity-30 focus:outline-none" 
                    />
                    {errors.name && (
                      <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input 
                      type="email" 
                      id="email" 
                      {...register("email", { 
                        required: "Email é obrigatório",
                        pattern: {
                          value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                          message: "Endereço de email inválido"
                        }
                      })}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))] focus:ring-opacity-30 focus:outline-none" 
                    />
                    {errors.email && (
                      <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>
                    )}
                  </div>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                    Assunto
                  </label>
                  <select 
                    id="subject" 
                    {...register("subject", { required: "Assunto é obrigatório" })}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:outline-none"
                  >
                    <option value="Informações sobre Admissão">Informações sobre Admissão</option>
                    <option value="Programa de Intercâmbio">Programa de Intercâmbio</option>
                    <option value="Biblioteca Virtual">Biblioteca Virtual</option>
                    <option value="Parcerias Institucionais">Parcerias Institucionais</option>
                    <option value="Outros Assuntos">Outros Assuntos</option>
                  </select>
                  {errors.subject && (
                    <p className="text-red-500 text-xs mt-1">{errors.subject.message}</p>
                  )}
                </div>
                
                <div className="mb-4">
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                    Mensagem
                  </label>
                  <textarea 
                    id="message" 
                    rows={4} 
                    {...register("message", { 
                      required: "Mensagem é obrigatória",
                      minLength: {
                        value: 10,
                        message: "Mensagem deve ter pelo menos 10 caracteres"
                      }
                    })}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary))] focus:ring-opacity-30 focus:outline-none"
                  ></textarea>
                  {errors.message && (
                    <p className="text-red-500 text-xs mt-1">{errors.message.message}</p>
                  )}
                </div>
                
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="bg-[hsl(var(--primary))] text-white px-6 py-2 rounded-lg font-medium hover:bg-[hsl(var(--secondary-blue))] transition w-full disabled:opacity-70"
                >
                  {isSubmitting ? "Enviando..." : "Enviar Mensagem"}
                </button>
              </form>
            </div>
          </div>
          
          <div>
            <div className="bg-white p-6 rounded-lg shadow-md mb-6">
              <h3 className="text-xl font-semibold mb-4 text-[hsl(var(--primary))]">
                Informações de Contacto
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                    <i className="fas fa-map-marker-alt text-[hsl(var(--primary))]"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#333333]">Endereço</h4>
                    <p className="text-gray-600">Avenida Principal, Lubango, Huíla, Angola</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                    <i className="fas fa-phone-alt text-[hsl(var(--primary))]"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#333333]">Telefone</h4>
                    <p className="text-gray-600">+244 123 456 789</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                    <i className="fas fa-envelope text-[hsl(var(--primary))]"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#333333]">Email</h4>
                    <p className="text-gray-600">info@fendadatundavala.ao</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[hsl(var(--secondary))] p-2 rounded-lg mr-3">
                    <i className="fas fa-clock text-[hsl(var(--primary))]"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#333333]">Horário de Funcionamento</h4>
                    <p className="text-gray-600">Segunda a Sexta: 8:00 - 17:00</p>
                    <p className="text-gray-600">Sábado: 8:00 - 12:00</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex space-x-4">
                <a href="#" className="bg-[hsl(var(--primary))] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[hsl(var(--secondary-blue))] transition">
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a href="#" className="bg-[hsl(var(--primary))] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[hsl(var(--secondary-blue))] transition">
                  <i className="fab fa-instagram"></i>
                </a>
                <a href="#" className="bg-[hsl(var(--primary))] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[hsl(var(--secondary-blue))] transition">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="bg-[hsl(var(--primary))] text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-[hsl(var(--secondary-blue))] transition">
                  <i className="fab fa-linkedin-in"></i>
                </a>
              </div>
            </div>
            
            {/* Map Placeholder */}
            <div className="bg-white p-6 rounded-lg shadow-md h-64 flex items-center justify-center">
              <div className="text-center">
                <i className="fas fa-map-marked-alt text-4xl text-[hsl(var(--primary))] mb-3"></i>
                <p className="text-gray-600">Mapa interativo da localização da escola</p>
                <a href="#" className="text-[hsl(var(--primary))] hover:text-[hsl(var(--secondary-blue))] font-medium mt-2 inline-block">
                  Ver em tela cheia
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
