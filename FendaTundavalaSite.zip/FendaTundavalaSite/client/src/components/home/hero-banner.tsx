import { Link } from "wouter";

const HeroBanner = () => {
  return (
    <section className="relative bg-gradient-to-r from-[hsl(var(--primary))] to-[hsl(var(--secondary-blue))] text-white overflow-hidden">
      {/* Background overlay */}
      <div className="absolute inset-0 bg-black opacity-30 z-10"></div>
      <div 
        className="absolute inset-0 bg-cover bg-center z-0" 
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1561542320-9a18cd340469?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800')" }}
      ></div>
      
      <div className="container mx-auto px-4 py-20 md:py-32 lg:py-40 relative z-20">
        <div className="max-w-2xl">
          <span className="bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-3 py-1 rounded-full text-sm font-semibold inline-block mb-4">
            Excelência Educacional
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Fenda da Tundavala
          </h1>
          <p className="text-lg md:text-xl mb-8">
            Uma instituição de ensino de excelência dedicada ao intercâmbio cultural entre Angola e China, formando líderes globais para o futuro.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link 
              href="/about" 
              className="bg-[hsl(var(--secondary))] text-[hsl(var(--primary))] px-6 py-3 rounded-lg font-medium hover:bg-[hsl(var(--secondary-yellow))] transition"
            >
              Conheça Nossa Escola
            </Link>
            <Link 
              href="/exchange" 
              className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white px-6 py-3 rounded-lg font-medium transition"
            >
              Programa de Intercâmbio
            </Link>
          </div>
        </div>
      </div>
      
      {/* Floating stats cards */}
      <div className="container mx-auto px-4 relative z-20 -mb-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <span className="text-[hsl(var(--primary))] text-4xl font-bold">15+</span>
            <p className="text-[#333333] mt-2">Anos de Experiência</p>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <span className="text-[hsl(var(--primary))] text-4xl font-bold">500+</span>
            <p className="text-[#333333] mt-2">Alunos Intercambistas</p>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <span className="text-[hsl(var(--primary))] text-4xl font-bold">20+</span>
            <p className="text-[#333333] mt-2">Parcerias com Universidades</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroBanner;
