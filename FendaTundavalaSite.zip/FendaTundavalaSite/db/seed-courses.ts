import { db } from './index';
import { courses } from '../shared/schema';
import { eq } from 'drizzle-orm';

export async function seedCourses() {
  try {
    console.log('🌱 Semeando cursos...');
    
    // Verificar se já existem cursos
    const existingCourses = await db.query.courses.findMany();
    
    if (existingCourses.length > 0) {
      console.log('ℹ️ Cursos já existem, pulando a semeadura.');
      return;
    }

    // Verificar se existem níveis de educação
    const educationLevels = await db.query.educationLevels.findMany();
    
    if (educationLevels.length === 0) {
      console.log('⚠️ Nenhum nível de educação encontrado. Não é possível adicionar cursos sem níveis de educação.');
      return;
    }

    // Dados dos cursos a serem inseridos
    const cursosParaInserir = [
      {
        name: 'Engenharia Civil',
        code: 'ENG001',
        description: 'Curso de Engenharia Civil com ênfase em construção sustentável',
        educationLevelId: educationLevels[0].id,
        duration: '5 anos',
        coordinator: 'Prof. João Silva',
        active: true
      },
      {
        name: 'Medicina',
        code: 'MED001',
        description: 'Formação médica com foco em medicina comunitária',
        educationLevelId: educationLevels[0].id,
        duration: '6 anos',
        coordinator: 'Profa. Maria Santos',
        active: true
      },
      {
        name: 'Administração',
        code: 'ADM001',
        description: 'Curso de Administração com ênfase em gestão internacional',
        educationLevelId: educationLevels[0].id,
        duration: '4 anos',
        coordinator: 'Prof. Carlos Mendes',
        active: true
      },
      {
        name: 'Matemática Aplicada',
        code: 'MAT001',
        description: 'Estudo avançado de matemática com aplicações práticas',
        educationLevelId: educationLevels[0].id,
        duration: '4 anos',
        coordinator: 'Profa. Ana Ferreira',
        active: true
      }
    ];

    // Inserir cursos
    const insertedCourses = await db.insert(courses).values(cursosParaInserir).returning();
    
    console.log(`✅ ${insertedCourses.length} cursos inseridos com sucesso!`);
  } catch (error) {
    console.error('❌ Erro ao semear cursos:', error);
  }
}