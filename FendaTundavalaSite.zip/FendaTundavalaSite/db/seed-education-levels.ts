import { db } from "./index";
import { educationLevels } from "@shared/schema";
import { sql } from "drizzle-orm";

async function seedEducationLevels() {
  console.log("Seeding education levels...");
  
  // Check if education levels already exist
  const existingLevels = await db.select().from(educationLevels);
  
  if (existingLevels.length > 0) {
    console.log(`Skipping education levels seed, found ${existingLevels.length} existing records.`);
    return;
  }
  
  // Initial education levels
  const initialEducationLevels = [
    {
      name: "Ensino Fundamental I",
      description: "1º ao 5º ano do ensino fundamental, focado na alfabetização e desenvolvimento de habilidades básicas.",
      levelOrder: 1,
      active: true
    },
    {
      name: "Ensino Fundamental II",
      description: "6º ao 9º ano do ensino fundamental, ampliando conhecimentos e introduzindo disciplinas específicas.",
      levelOrder: 2,
      active: true
    },
    {
      name: "Ensino Médio",
      description: "1º ao 3º ano do ensino médio, preparando os alunos para o ensino superior e mercado de trabalho.",
      levelOrder: 3,
      active: true
    },
    {
      name: "Ensino Superior",
      description: "Cursos de graduação em diversas áreas do conhecimento.",
      levelOrder: 4,
      active: true
    },
    {
      name: "Pós-Graduação",
      description: "Especialização, mestrado e doutorado para aprofundamento em áreas específicas.",
      levelOrder: 5,
      active: true
    }
  ];
  
  // Insert education levels
  await db.insert(educationLevels).values(initialEducationLevels);
  
  console.log(`Added ${initialEducationLevels.length} education levels.`);
}

// Run the seed function
seedEducationLevels()
  .then(() => {
    console.log("Education levels seeding completed!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error seeding education levels:", error);
    process.exit(1);
  });