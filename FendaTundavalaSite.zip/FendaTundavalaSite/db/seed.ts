import { db } from "./index";
import * as schema from "@shared/schema";
import { educationLevels } from "@shared/schema";
import { seedCourses } from "./seed-courses";
import { seedSubjects } from "./seed-subjects";

async function seed() {
  try {
    console.log("Seeding database...");

    // Seed universities
    const universitiesData = [
      {
        name: "Universidade de Pequim",
        country: "China",
        city: "Pequim",
        description: "Uma das mais prestigiadas universidades da China, oferecendo programas de excelência em diversas áreas.",
        website: "https://www.pku.edu.cn"
      },
      {
        name: "Universidade de Tsinghua",
        country: "China",
        city: "Pequim",
        description: "Universidade de elite com foco em ciência e tecnologia, reconhecida internacionalmente.",
        website: "https://www.tsinghua.edu.cn"
      },
      {
        name: "Universidade de Fudan",
        country: "China",
        city: "Xangai",
        description: "Uma das universidades mais antigas e seletivas da China, com fortes programas de pesquisa.",
        website: "https://www.fudan.edu.cn"
      },
      {
        name: "Universidade Agostinho Neto",
        country: "Angola",
        city: "Luanda",
        description: "Principal universidade pública de Angola, oferecendo uma ampla gama de cursos de graduação e pós-graduação.",
        website: "https://www.uan.ao"
      },
      {
        name: "Universidade Mandume ya Ndemufayo",
        country: "Angola",
        city: "Lubango",
        description: "Instituição de ensino superior pública angolana com foco no desenvolvimento regional.",
        website: "https://www.umn.edu.ao"
      },
      {
        name: "Universidade de Zhejiang",
        country: "China",
        city: "Hangzhou",
        description: "Uma das universidades mais prestigiadas da China, com excelência em engenharia e tecnologia.",
        website: "https://www.zju.edu.cn"
      }
    ];

    const existingUniversities = await db.query.universities.findMany();
    if (existingUniversities.length === 0) {
      console.log("Seeding universities...");
      for (const university of universitiesData) {
        await db.insert(schema.universities).values(university);
      }
      console.log("Universities seeded successfully!");
    } else {
      console.log(`Skipping universities seed, found ${existingUniversities.length} existing records.`);
    }

    // Seed library resources
    const resourcesData = [
      {
        title: "História de Angola: Passado e Presente",
        author: "João Silva",
        type: "Livro",
        category: "História",
        language: "Português",
        year: 2020,
        description: "Uma análise abrangente da história angolana, desde o período pré-colonial até os dias atuais.",
        featured: true
      },
      {
        title: "Relações Econômicas China-África",
        author: "Li Wei, Maria Sousa",
        type: "Artigo",
        category: "Economia",
        language: "Bilíngue",
        year: 2022,
        description: "Análise aprofundada das relações econômicas entre a China e os países africanos, com foco em Angola.",
        featured: true
      },
      {
        title: "Introdução à Língua Mandarim",
        author: "Departamento de Línguas",
        type: "Vídeo",
        category: "Línguas",
        language: "Português",
        year: 2023,
        description: "Curso introdutório de mandarim para falantes de português, com foco em conversação básica.",
        featured: true
      },
      {
        title: "Guia de Intercâmbio Cultural",
        author: "Departamento Acadêmico",
        type: "Material",
        category: "Cultura",
        language: "Bilíngue",
        year: 2023,
        description: "Manual completo para estudantes participantes do programa de intercâmbio, com informações práticas e culturais.",
        featured: true
      },
      {
        title: "Matemática Aplicada para Engenharia",
        author: "Zhang Wei",
        type: "Livro",
        category: "Matemática",
        language: "Mandarim",
        year: 2021,
        description: "Livro-texto de matemática avançada direcionado a estudantes de engenharia, com exemplos práticos.",
        featured: false
      },
      {
        title: "Literatura Angolana Contemporânea",
        author: "Ana Cristina Oliveira",
        type: "Livro",
        category: "Literatura",
        language: "Português",
        year: 2019,
        description: "Análise das principais obras e autores da literatura angolana das últimas décadas.",
        featured: false
      },
      {
        title: "Desenvolvimento Tecnológico na China",
        author: "Li Jianping",
        type: "Artigo",
        category: "Tecnologia",
        language: "Inglês",
        year: 2022,
        description: "Panorama do avanço tecnológico chinês e suas implicações globais nos últimos anos.",
        featured: false
      },
      {
        title: "Cultura e Tradições Chinesas",
        author: "Instituto Cultural Sino-Angolano",
        type: "Vídeo",
        category: "Cultura",
        language: "Bilíngue",
        year: 2020,
        description: "Documentário sobre as principais tradições culturais chinesas, incluindo festivais e costumes.",
        featured: false
      }
    ];

    const existingResources = await db.query.resources.findMany();
    if (existingResources.length === 0) {
      console.log("Seeding library resources...");
      for (const resource of resourcesData) {
        await db.insert(schema.resources).values(resource);
      }
      console.log("Library resources seeded successfully!");
    } else {
      console.log(`Skipping resources seed, found ${existingResources.length} existing records.`);
    }

    // Seed testimonials
    const testimonialsData = [
      {
        name: "Maria Silva",
        role: "Intercambista 2022",
        rating: 5.0,
        testimonial: "A experiência de estudar na China mudou completamente minha perspectiva. Aprendi mandarim fluentemente e desenvolvi amizades que durarão a vida toda. O suporte da Fenda da Tundavala foi fundamental nesta jornada."
      },
      {
        name: "Li Wei",
        role: "Estudante Chinês em Angola",
        rating: 5.0,
        testimonial: "Estudar em Angola tem sido uma experiência incrível. A cultura é rica e acolhedora, e a equipe da Fenda da Tundavala proporcionou todo o suporte necessário para minha adaptação. Recomendo a todos!"
      },
      {
        name: "Paulo Domingos",
        role: "Aluno Graduado 2021",
        rating: 4.5,
        testimonial: "A formação bilíngue que recebi na Fenda da Tundavala abriu portas para minha carreira internacional. Hoje trabalho em uma empresa multinacional entre Angola e China, usando diariamente as habilidades que adquiri."
      }
    ];

    const existingTestimonials = await db.query.testimonials.findMany();
    if (existingTestimonials.length === 0) {
      console.log("Seeding testimonials...");
      for (const testimonial of testimonialsData) {
        await db.insert(schema.testimonials).values(testimonial);
      }
      console.log("Testimonials seeded successfully!");
    } else {
      console.log(`Skipping testimonials seed, found ${existingTestimonials.length} existing records.`);
    }

    // Seed exchange programs
    const exchangeProgramsData = [
      {
        title: "Graduação Internacional",
        description: "Programa completo de graduação em universidades parceiras na China, com suporte acadêmico e cultural contínuo.",
        duration: "3-4 anos",
        requirements: JSON.stringify([
          "Ensino médio completo",
          "Bom desempenho acadêmico",
          "Disponibilidade para residir na China",
          "Disposição para aprender mandarim"
        ]),
        benefits: JSON.stringify([
          "Diploma reconhecido internacionalmente",
          "Curso preparatório de mandarim",
          "Possibilidade de bolsas de estudo",
          "Suporte para acomodação e adaptação"
        ]),
        applicationDeadline: new Date("2024-04-30")
      },
      {
        title: "Intercâmbio Semestral",
        description: "Programa de intercâmbio de um semestre em universidades chinesas parceiras, mantendo vínculo com a instituição angolana.",
        duration: "6 meses",
        requirements: JSON.stringify([
          "Ser aluno regular de graduação",
          "Ter completado pelo menos 2 semestres",
          "Bom desempenho acadêmico",
          "Conhecimentos básicos de inglês"
        ]),
        benefits: JSON.stringify([
          "Imersão cultural intensa",
          "Aproveitamento de créditos acadêmicos",
          "Aulas de mandarim inclusas",
          "Participação em eventos culturais"
        ]),
        applicationDeadline: new Date("2024-05-15")
      },
      {
        title: "Curso Intensivo de Mandarim",
        description: "Programa de imersão linguística para desenvolver fluência em mandarim, ministrado por professores nativos.",
        duration: "1-12 meses",
        requirements: JSON.stringify([
          "Idade mínima de 18 anos",
          "Disponibilidade para estudo intensivo",
          "Motivação para aprender uma nova língua"
        ]),
        benefits: JSON.stringify([
          "Vários níveis disponíveis",
          "Preparação para certificação HSK",
          "Atividades culturais complementares",
          "Material didático incluso"
        ]),
        applicationDeadline: new Date("2024-06-30")
      },
      {
        title: "Estágio Profissional",
        description: "Oportunidade de estágio em empresas chinesas ou de cooperação sino-angolana para aplicação prática de conhecimentos.",
        duration: "2-6 meses",
        requirements: JSON.stringify([
          "Graduação em andamento ou concluída",
          "Conhecimentos básicos de inglês ou mandarim",
          "Competências na área de atuação desejada"
        ]),
        benefits: JSON.stringify([
          "Experiência profissional internacional",
          "Mentoria profissional",
          "Oportunidades em diversos setores",
          "Networking com profissionais da área"
        ]),
        applicationDeadline: new Date("2024-03-15")
      }
    ];

    const existingPrograms = await db.query.exchangePrograms.findMany();
    if (existingPrograms.length === 0) {
      console.log("Seeding exchange programs...");
      for (const program of exchangeProgramsData) {
        await db.insert(schema.exchangePrograms).values(program);
      }
      console.log("Exchange programs seeded successfully!");
    } else {
      console.log(`Skipping exchange programs seed, found ${existingPrograms.length} existing records.`);
    }

    // Seed education levels
    const educationLevelsData = [
      {
        name: "Ensino Fundamental I",
        description: "1º ao 5º ano do ensino fundamental, focado na alfabetização e desenvolvimento de habilidades básicas.",
        levelOrder: 1,
        active: true
      },
      {
        name: "Ensino Fundamental II",
        description: "6º ao 9º ano do ensino fundamental, ampliando conhecimentos e introduzindo disciplinas específicas.",
        levelOrder: 2,
        active: true
      },
      {
        name: "Ensino Médio",
        description: "1º ao 3º ano do ensino médio, preparando os alunos para o ensino superior e mercado de trabalho.",
        levelOrder: 3,
        active: true
      },
      {
        name: "Ensino Superior",
        description: "Cursos de graduação em diversas áreas do conhecimento.",
        levelOrder: 4,
        active: true
      },
      {
        name: "Pós-Graduação",
        description: "Especialização, mestrado e doutorado para aprofundamento em áreas específicas.",
        levelOrder: 5,
        active: true
      }
    ];

    const existingLevels = await db.query.educationLevels.findMany();
    if (existingLevels.length === 0) {
      console.log("Seeding education levels...");
      for (const level of educationLevelsData) {
        await db.insert(schema.educationLevels).values(level);
      }
      console.log("Education levels seeded successfully!");
    } else {
      console.log(`Skipping education levels seed, found ${existingLevels.length} existing records.`);
    }

    // Seed courses after education levels
    await seedCourses();
    
    // Seed subjects after courses
    await seedSubjects();
    
    console.log("Database seeding completed!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
