import { db } from "./index";
import * as schema from "@shared/schema";

async function seedAdmin() {
  try {
    console.log("Seeding admin user...");

    // Check if admin user already exists
    const existingAdmin = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, "admin")
    });

    if (!existingAdmin) {
      // Create admin user
      const adminUser = {
        username: "admin",
        password: "admin123", // In a real application, this should be hashed
        fullName: "Administrator",
        email: "admin@fendadatundavala.ao",
        userType: "admin",
        active: true
      };

      const [insertedAdmin] = await db.insert(schema.users).values(adminUser).returning();
      console.log("Admin user created successfully!");
      return insertedAdmin;
    } else {
      console.log("Admin user already exists, skipping creation.");
      return existingAdmin;
    }
  } catch (error) {
    console.error("Error seeding admin user:", error);
  }
}

seedAdmin();