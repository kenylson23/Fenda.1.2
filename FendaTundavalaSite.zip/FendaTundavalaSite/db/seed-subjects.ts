import { db } from './index';
import { subjects } from '../shared/schema';
import { eq } from 'drizzle-orm';

export async function seedSubjects() {
  try {
    console.log('🌱 Semeando disciplinas...');
    
    // Verificar se já existem disciplinas
    const existingSubjects = await db.query.subjects.findMany();
    
    if (existingSubjects.length > 0) {
      console.log('ℹ️ Disciplinas já existem, pulando a semeadura.');
      return;
    }

    // Buscar cursos para vincular disciplinas
    const existingCourses = await db.query.courses.findMany();
    
    if (existingCourses.length === 0) {
      console.log('⚠️ Nenhum curso encontrado. Não é possível adicionar disciplinas sem cursos.');
      return;
    }

    // Disciplinas para o curso de Engenharia Civil (assumindo que é o primeiro)
    const engenhariaId = existingCourses.find(c => c.code === 'ENG001')?.id;
    const medicinaId = existingCourses.find(c => c.code === 'MED001')?.id;
    const administracaoId = existingCourses.find(c => c.code === 'ADM001')?.id;
    const matematicaId = existingCourses.find(c => c.code === 'MAT001')?.id;

    // Lista de disciplinas para inserir
    const disciplinasParaInserir = [
      // Disciplinas de Engenharia Civil
      {
        name: 'Cálculo Estrutural',
        code: 'ENG101',
        description: 'Fundamentos de cálculo aplicados a estruturas de engenharia',
        courseId: engenhariaId || existingCourses[0].id,
        credits: 6,
        active: true
      },
      {
        name: 'Materiais de Construção',
        code: 'ENG102',
        description: 'Estudo dos materiais utilizados na construção civil',
        courseId: engenhariaId || existingCourses[0].id,
        credits: 4,
        active: true
      },
      {
        name: 'Hidráulica',
        code: 'ENG103',
        description: 'Princípios e aplicações da hidráulica em engenharia',
        courseId: engenhariaId || existingCourses[0].id,
        credits: 5,
        active: true
      },
      
      // Disciplinas de Medicina
      {
        name: 'Anatomia Humana',
        code: 'MED101',
        description: 'Estudo da estrutura do corpo humano',
        courseId: medicinaId || (existingCourses[1]?.id || existingCourses[0].id),
        credits: 8,
        active: true
      },
      {
        name: 'Fisiologia',
        code: 'MED102',
        description: 'Funcionamento dos sistemas do corpo humano',
        courseId: medicinaId || (existingCourses[1]?.id || existingCourses[0].id),
        credits: 6,
        active: true
      },
      
      // Disciplinas de Administração
      {
        name: 'Gestão Estratégica',
        code: 'ADM101',
        description: 'Fundamentos de estratégia empresarial',
        courseId: administracaoId || (existingCourses[2]?.id || existingCourses[0].id),
        credits: 4,
        active: true
      },
      {
        name: 'Marketing Internacional',
        code: 'ADM102',
        description: 'Estratégias de marketing em contexto global',
        courseId: administracaoId || (existingCourses[2]?.id || existingCourses[0].id),
        credits: 4,
        active: true
      },
      
      // Disciplinas de Matemática Aplicada
      {
        name: 'Análise Numérica',
        code: 'MAT101',
        description: 'Métodos numéricos para resolução de problemas matemáticos',
        courseId: matematicaId || (existingCourses[3]?.id || existingCourses[0].id),
        credits: 5,
        active: true
      },
      {
        name: 'Estatística Avançada',
        code: 'MAT102',
        description: 'Métodos estatísticos para análise de dados complexos',
        courseId: matematicaId || (existingCourses[3]?.id || existingCourses[0].id),
        credits: 6,
        active: true
      }
    ];

    // Inserir disciplinas
    const insertedSubjects = await db.insert(subjects).values(disciplinasParaInserir).returning();
    
    console.log(`✅ ${insertedSubjects.length} disciplinas inseridas com sucesso!`);
  } catch (error) {
    console.error('❌ Erro ao semear disciplinas:', error);
  }
}