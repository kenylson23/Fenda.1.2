import { pgTable, text, serial, integer, boolean, timestamp, varchar, decimal, date } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
  userType: text("user_type").default("student").notNull(), // "admin", "student", "teacher"
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Courses table
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull(),
  description: text("description"),
  educationLevelId: integer("education_level_id").references(() => educationLevels.id).notNull(),
  duration: text("duration").notNull(),
  coordinator: text("coordinator"),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Courses relations
export const coursesRelations = relations(courses, ({ one, many }) => ({
  educationLevel: one(educationLevels, {
    fields: [courses.educationLevelId],
    references: [educationLevels.id]
  }),
  subjects: many(subjects)
}));

// Course validation schema
export const insertCourseSchema = createInsertSchema(courses, {
  name: (schema) => schema.min(3, "Nome deve ter pelo menos 3 caracteres"),
  code: (schema) => schema.min(2, "Código deve ter pelo menos 2 caracteres"),
  duration: (schema) => schema.min(2, "Duração deve ser especificada")
}).omit({
  id: true,
  createdAt: true
});

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;

// Subjects table
export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull(),
  description: text("description"),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  credits: integer("credits").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Subjects relations
export const subjectsRelations = relations(subjects, ({ one }) => ({
  course: one(courses, {
    fields: [subjects.courseId],
    references: [courses.id]
  })
}));

// Subject validation schema
export const insertSubjectSchema = createInsertSchema(subjects, {
  name: (schema) => schema.min(3, "Nome deve ter pelo menos 3 caracteres"),
  code: (schema) => schema.min(2, "Código deve ter pelo menos 2 caracteres")
}).omit({
  id: true,
  createdAt: true
});

export type InsertSubject = z.infer<typeof insertSubjectSchema>;
export type Subject = typeof subjects.$inferSelect;

export const insertUserSchema = createInsertSchema(users, {
  username: (schema) => schema.min(3, "Username must be at least 3 characters"),
  password: (schema) => schema.min(6, "Password must be at least 6 characters"),
  email: (schema) => schema.email("Must be a valid email address")
}).omit({
  id: true,
  createdAt: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Students table for additional student information
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  enrollmentNumber: text("enrollment_number").notNull().unique(),
  dateOfBirth: timestamp("date_of_birth"),
  address: text("address"),
  phoneNumber: text("phone_number"),
  course: text("course"),
  semester: integer("semester"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const studentsRelations = relations(students, ({ one }) => ({
  user: one(users, {
    fields: [students.userId],
    references: [users.id]
  })
}));

export const insertStudentSchema = createInsertSchema(students, {
  enrollmentNumber: (schema) => schema.min(5, "Enrollment number must be at least 5 characters"),
}).omit({
  id: true,
  createdAt: true
});

export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;

// Teachers table for additional teacher information
export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  employeeId: text("employee_id").notNull().unique(),
  department: text("department"),
  position: text("position"),
  specialization: text("specialization"),
  education: text("education"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const teachersRelations = relations(teachers, ({ one }) => ({
  user: one(users, {
    fields: [teachers.userId],
    references: [users.id]
  })
}));

export const insertTeacherSchema = createInsertSchema(teachers, {
  employeeId: (schema) => schema.min(5, "Employee ID must be at least 5 characters"),
}).omit({
  id: true,
  createdAt: true
});

export type InsertTeacher = z.infer<typeof insertTeacherSchema>;
export type Teacher = typeof teachers.$inferSelect;

// Universities table
export const universities = pgTable("universities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  country: text("country").notNull(),
  city: text("city").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  website: text("website"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUniversitySchema = createInsertSchema(universities, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters"),
  country: (schema) => schema.min(2, "Country must be at least 2 characters"),
  city: (schema) => schema.min(2, "City must be at least 2 characters"),
  description: (schema) => schema.min(10, "Description must be at least 10 characters"),
});

export type InsertUniversity = z.infer<typeof insertUniversitySchema>;
export type University = typeof universities.$inferSelect;

// Resources table for Virtual Library
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  author: text("author").notNull(),
  type: text("type").notNull(), // "Livro", "Artigo", "Vídeo", "Material"
  category: text("category").notNull(),
  language: text("language").notNull(),
  year: integer("year").notNull(),
  description: text("description").notNull(),
  contentUrl: text("content_url"),
  thumbnailUrl: text("thumbnail_url"),
  featured: boolean("featured").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertResourceSchema = createInsertSchema(resources, {
  title: (schema) => schema.min(2, "Title must be at least 2 characters"),
  author: (schema) => schema.min(2, "Author must be at least 2 characters"),
  description: (schema) => schema.min(10, "Description must be at least 10 characters"),
});

export type InsertResource = z.infer<typeof insertResourceSchema>;
export type Resource = typeof resources.$inferSelect;

// Testimonials table
export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  rating: decimal("rating", { precision: 2, scale: 1 }).notNull(),
  testimonial: text("testimonial").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTestimonialSchema = createInsertSchema(testimonials, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters"),
  role: (schema) => schema.min(2, "Role must be at least 2 characters"),
  testimonial: (schema) => schema.min(10, "Testimonial must be at least 10 characters"),
});

export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonials.$inferSelect;

// Exchange Programs table
export const exchangePrograms = pgTable("exchange_programs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  duration: text("duration").notNull(),
  requirements: text("requirements").notNull(), // Stored as JSON string
  benefits: text("benefits").notNull(), // Stored as JSON string
  applicationDeadline: timestamp("application_deadline").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertExchangeProgramSchema = createInsertSchema(exchangePrograms, {
  title: (schema) => schema.min(2, "Title must be at least 2 characters"),
  description: (schema) => schema.min(10, "Description must be at least 10 characters"),
  duration: (schema) => schema.min(2, "Duration must be at least 2 characters"),
});

export type InsertExchangeProgram = z.infer<typeof insertExchangeProgramSchema>;
export type ExchangeProgram = typeof exchangePrograms.$inferSelect;

// Exchange Applications table
export const exchangeApplications = pgTable("exchange_applications", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  nationality: text("nationality").notNull(),
  programId: integer("program_id").notNull(),
  educationLevel: text("education_level").notNull(),
  motivation: text("motivation").notNull(),
  status: text("status").default("pending").notNull(), // "pending", "approved", "rejected"
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
});

export const exchangeApplicationsRelations = relations(exchangeApplications, ({ one }) => ({
  program: one(exchangePrograms, {
    fields: [exchangeApplications.programId],
    references: [exchangePrograms.id],
  }),
}));

export const insertExchangeApplicationSchema = createInsertSchema(exchangeApplications, {
  fullName: (schema) => schema.min(2, "Full name must be at least 2 characters"),
  email: (schema) => schema.email("Must provide a valid email"),
  phone: (schema) => schema.min(5, "Phone number must be at least 5 characters"),
  motivation: (schema) => schema.min(50, "Motivation must be at least 50 characters"),
});

export type InsertExchangeApplication = z.infer<typeof insertExchangeApplicationSchema>;
export type ExchangeApplication = typeof exchangeApplications.$inferSelect;

// Contact Form Submissions
export const contactSubmissions = pgTable("contact_submissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
  responded: boolean("responded").default(false).notNull(),
});

export const insertContactSubmissionSchema = createInsertSchema(contactSubmissions, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters"),
  email: (schema) => schema.email("Must provide a valid email"),
  subject: (schema) => schema.min(2, "Subject must be at least 2 characters"),
  message: (schema) => schema.min(10, "Message must be at least 10 characters"),
});

export type InsertContactSubmission = z.infer<typeof insertContactSubmissionSchema>;
export type ContactSubmission = typeof contactSubmissions.$inferSelect;

// Education Levels (Níveis de Ensino) table
export const educationLevels = pgTable("education_levels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  levelOrder: integer("level_order").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertEducationLevelSchema = createInsertSchema(educationLevels, {
  name: (schema) => schema.min(2, "Nome do nível de ensino deve ter pelo menos 2 caracteres"),
  description: (schema) => schema.min(10, "Descrição deve ter pelo menos 10 caracteres"),
}).omit({
  id: true,
  createdAt: true
});

export type InsertEducationLevel = z.infer<typeof insertEducationLevelSchema>;
export type EducationLevel = typeof educationLevels.$inferSelect;

// Classes (Turmas) table
export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  year: integer("year").notNull(),
  semester: text("semester").notNull(), // "1º Semestre", "2º Semestre", etc.
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  description: text("description"),
  status: text("status").default("active").notNull(), // "active", "completed", "canceled"
  maxStudents: integer("max_students").notNull(),
  educationLevelId: integer("education_level_id").references(() => educationLevels.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertClassSchema = createInsertSchema(classes, {
  name: (schema) => schema.min(2, "Nome da turma deve ter pelo menos 2 caracteres"),
  description: (schema) => schema.min(10, "Descrição deve ter pelo menos 10 caracteres"),
}).omit({
  id: true,
  createdAt: true
});

export type InsertClass = z.infer<typeof insertClassSchema>;
export type Class = typeof classes.$inferSelect;

// Class Teachers (Professores de Turma) table
export const classTeachers = pgTable("class_teachers", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").notNull().references(() => classes.id),
  teacherId: integer("teacher_id").notNull().references(() => teachers.id),
  isMainTeacher: boolean("is_main_teacher").default(false).notNull(),
  assignedAt: timestamp("assigned_at").defaultNow().notNull(),
});

export const classTeachersRelations = relations(classTeachers, ({ one }) => ({
  class: one(classes, {
    fields: [classTeachers.classId],
    references: [classes.id]
  }),
  teacher: one(teachers, {
    fields: [classTeachers.teacherId],
    references: [teachers.id]
  })
}));

export const insertClassTeacherSchema = createInsertSchema(classTeachers).omit({
  id: true,
  assignedAt: true
});

export type InsertClassTeacher = z.infer<typeof insertClassTeacherSchema>;
export type ClassTeacher = typeof classTeachers.$inferSelect;

// Class Students (Alunos de Turma) table
export const classStudents = pgTable("class_students", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").notNull().references(() => classes.id),
  studentId: integer("student_id").notNull().references(() => students.id),
  enrollmentDate: timestamp("enrollment_date").defaultNow().notNull(),
  status: text("status").default("enrolled").notNull(), // "enrolled", "completed", "withdrawn"
  finalGrade: decimal("final_grade", { precision: 4, scale: 2 }),
});

export const classStudentsRelations = relations(classStudents, ({ one }) => ({
  class: one(classes, {
    fields: [classStudents.classId],
    references: [classes.id]
  }),
  student: one(students, {
    fields: [classStudents.studentId],
    references: [students.id]
  })
}));

export const insertClassStudentSchema = createInsertSchema(classStudents).omit({
  id: true,
  enrollmentDate: true
});

export type InsertClassStudent = z.infer<typeof insertClassStudentSchema>;
export type ClassStudent = typeof classStudents.$inferSelect;

// Class Subjects (Disciplinas da Turma) table
export const classSubjects = pgTable("class_subjects", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").notNull().references(() => classes.id),
  name: text("name").notNull(),
  description: text("description"),
  credits: integer("credits").notNull(),
  schedule: text("schedule").notNull(), // "Segunda 10:00-12:00, Quarta 10:00-12:00"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const classSubjectsRelations = relations(classSubjects, ({ one }) => ({
  class: one(classes, {
    fields: [classSubjects.classId],
    references: [classes.id]
  })
}));

export const insertClassSubjectSchema = createInsertSchema(classSubjects, {
  name: (schema) => schema.min(2, "Nome da disciplina deve ter pelo menos 2 caracteres"),
  description: (schema) => schema.min(10, "Descrição deve ter pelo menos 10 caracteres"),
}).omit({
  id: true,
  createdAt: true
});

export type InsertClassSubject = z.infer<typeof insertClassSubjectSchema>;
export type ClassSubject = typeof classSubjects.$inferSelect;

// Relations for classes table
export const classesRelations = relations(classes, ({ one, many }) => ({
  educationLevel: one(educationLevels, {
    fields: [classes.educationLevelId],
    references: [educationLevels.id],
  }),
  teachers: many(classTeachers),
  students: many(classStudents),
  subjects: many(classSubjects),
}));
