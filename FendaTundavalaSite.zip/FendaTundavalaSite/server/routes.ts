import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";
import { 
  insertContactSubmissionSchema, 
  insertExchangeApplicationSchema,
  insertUserSchema,
  insertStudentSchema,
  insertTeacherSchema,
  insertClassSchema,
  insertClassTeacherSchema,
  insertClassStudentSchema,
  insertClassSubjectSchema,
  insertEducationLevelSchema,
  insertCourseSchema,
  insertSubjectSchema
} from "@shared/schema";
import { eq } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes - prefix all routes with /api
  const apiPrefix = "/api";

  // Authentication Routes
  
  // Register a new user
  app.post(`${apiPrefix}/auth/register`, async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Nome de usuário já está em uso" });
      }
      
      // Create user
      const user = await storage.createUser(validatedData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error registering user:", error);
      return res.status(500).json({ message: "Erro ao registrar usuário" });
    }
  });
  
  // Login
  app.post(`${apiPrefix}/auth/login`, async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Nome de usuário e senha são obrigatórios" });
      }
      
      // Get user by username
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      // Check password (in a real app, you would use bcrypt to hash and compare)
      if (user.password !== password) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      // Remove password from response
      const { password: userPassword, ...userWithoutPassword } = user;
      
      return res.status(200).json({
        user: userWithoutPassword,
        message: "Login realizado com sucesso"
      });
    } catch (error) {
      console.error("Error logging in:", error);
      return res.status(500).json({ message: "Erro ao fazer login" });
    }
  });
  
  // User Management Routes
  
  // Get all users
  app.get(`${apiPrefix}/users`, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Remove passwords from response
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      return res.status(200).json(usersWithoutPasswords);
    } catch (error) {
      console.error("Error fetching users:", error);
      return res.status(500).json({ message: "Erro ao buscar usuários" });
    }
  });
  
  // Get user by ID
  app.get(`${apiPrefix}/users/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de usuário inválido" });
      }
      
      const user = await storage.getUserById(id);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      return res.status(500).json({ message: "Erro ao buscar usuário" });
    }
  });
  
  // Student Management Routes
  
  // Create student
  app.post(`${apiPrefix}/students`, async (req, res) => {
    try {
      const { userData, studentData } = req.body;
      
      // Validate user data
      const validatedUserData = insertUserSchema.parse(userData);
      
      // Validate student data
      const validatedStudentData = insertStudentSchema.omit({ userId: true }).parse(studentData);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedUserData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Nome de usuário já está em uso" });
      }
      
      // Create student with user
      const result = await storage.createStudent(validatedUserData, validatedStudentData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = result.user;
      
      return res.status(201).json({
        user: userWithoutPassword,
        student: result.student
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating student:", error);
      return res.status(500).json({ message: "Erro ao criar aluno" });
    }
  });
  
  // Get all students
  app.get(`${apiPrefix}/students`, async (req, res) => {
    try {
      const students = await storage.getAllStudents();
      
      // Remove passwords from response
      const studentsWithoutPasswords = students.map(student => {
        const { user, ...studentData } = student;
        const { password, ...userWithoutPassword } = user;
        
        return {
          ...studentData,
          user: userWithoutPassword
        };
      });
      
      return res.status(200).json(studentsWithoutPasswords);
    } catch (error) {
      console.error("Error fetching students:", error);
      return res.status(500).json({ message: "Erro ao buscar alunos" });
    }
  });
  
  // Get student by ID
  app.get(`${apiPrefix}/students/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de aluno inválido" });
      }
      
      const student = await storage.getStudentById(id);
      if (!student) {
        return res.status(404).json({ message: "Aluno não encontrado" });
      }
      
      // Remove password from response
      const { user, ...studentData } = student;
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json({
        ...studentData,
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Error fetching student:", error);
      return res.status(500).json({ message: "Erro ao buscar aluno" });
    }
  });
  
  // Teacher Management Routes
  
  // Create teacher
  app.post(`${apiPrefix}/teachers`, async (req, res) => {
    try {
      const { userData, teacherData } = req.body;
      
      // Validate user data
      const validatedUserData = insertUserSchema.parse(userData);
      
      // Validate teacher data
      const validatedTeacherData = insertTeacherSchema.omit({ userId: true }).parse(teacherData);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedUserData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Nome de usuário já está em uso" });
      }
      
      // Create teacher with user
      const result = await storage.createTeacher(validatedUserData, validatedTeacherData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = result.user;
      
      return res.status(201).json({
        user: userWithoutPassword,
        teacher: result.teacher
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating teacher:", error);
      return res.status(500).json({ message: "Erro ao criar professor" });
    }
  });
  
  // Get all teachers
  app.get(`${apiPrefix}/teachers`, async (req, res) => {
    try {
      const teachers = await storage.getAllTeachers();
      
      // Remove passwords from response
      const teachersWithoutPasswords = teachers.map(teacher => {
        const { user, ...teacherData } = teacher;
        const { password, ...userWithoutPassword } = user;
        
        return {
          ...teacherData,
          user: userWithoutPassword
        };
      });
      
      return res.status(200).json(teachersWithoutPasswords);
    } catch (error) {
      console.error("Error fetching teachers:", error);
      return res.status(500).json({ message: "Erro ao buscar professores" });
    }
  });
  
  // Get teacher by ID
  app.get(`${apiPrefix}/teachers/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de professor inválido" });
      }
      
      const teacher = await storage.getTeacherById(id);
      if (!teacher) {
        return res.status(404).json({ message: "Professor não encontrado" });
      }
      
      // Remove password from response
      const { user, ...teacherData } = teacher;
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json({
        ...teacherData,
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Error fetching teacher:", error);
      return res.status(500).json({ message: "Erro ao buscar professor" });
    }
  });

  // Get all universities
  app.get(`${apiPrefix}/universities`, async (req, res) => {
    try {
      const universities = await storage.getAllUniversities();
      return res.status(200).json(universities);
    } catch (error) {
      console.error("Error fetching universities:", error);
      return res.status(500).json({ message: "Error fetching universities" });
    }
  });

  // Get featured resources for the homepage
  app.get(`${apiPrefix}/resources/featured`, async (req, res) => {
    try {
      const featuredResources = await storage.getFeaturedResources();
      return res.status(200).json(featuredResources);
    } catch (error) {
      console.error("Error fetching featured resources:", error);
      return res.status(500).json({ message: "Error fetching featured resources" });
    }
  });

  // Get all resources with filtering options
  app.get(`${apiPrefix}/resources`, async (req, res) => {
    try {
      const {
        search = "",
        type = "Todos os tipos",
        category = "Todas as categorias",
        language = "Todos os idiomas",
        page = "1",
        limit = "12"
      } = req.query;

      const parsedPage = parseInt(page as string) || 1;
      const parsedLimit = parseInt(limit as string) || 12;

      const resources = await storage.getResources({
        search: search as string,
        type: type as string,
        category: category as string,
        language: language as string,
        page: parsedPage,
        limit: parsedLimit
      });

      return res.status(200).json(resources);
    } catch (error) {
      console.error("Error fetching resources:", error);
      return res.status(500).json({ message: "Error fetching resources" });
    }
  });

  // Get resource by ID
  app.get(`${apiPrefix}/resources/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid resource ID" });
      }

      const resource = await storage.getResourceById(id);
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }

      return res.status(200).json(resource);
    } catch (error) {
      console.error("Error fetching resource:", error);
      return res.status(500).json({ message: "Error fetching resource" });
    }
  });

  // Get all testimonials
  app.get(`${apiPrefix}/testimonials`, async (req, res) => {
    try {
      const testimonials = await storage.getAllTestimonials();
      return res.status(200).json(testimonials);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
      return res.status(500).json({ message: "Error fetching testimonials" });
    }
  });

  // Get all exchange programs
  app.get(`${apiPrefix}/exchange-programs`, async (req, res) => {
    try {
      const programs = await storage.getAllExchangePrograms();
      return res.status(200).json(programs);
    } catch (error) {
      console.error("Error fetching exchange programs:", error);
      return res.status(500).json({ message: "Error fetching exchange programs" });
    }
  });

  // Get exchange program by ID
  app.get(`${apiPrefix}/exchange-programs/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid program ID" });
      }

      const program = await storage.getExchangeProgramById(id);
      if (!program) {
        return res.status(404).json({ message: "Program not found" });
      }

      return res.status(200).json(program);
    } catch (error) {
      console.error("Error fetching exchange program:", error);
      return res.status(500).json({ message: "Error fetching exchange program" });
    }
  });

  // Submit exchange application
  app.post(`${apiPrefix}/exchange-applications`, async (req, res) => {
    try {
      const validatedData = insertExchangeApplicationSchema.parse(req.body);
      const application = await storage.createExchangeApplication(validatedData);
      return res.status(201).json(application);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating exchange application:", error);
      return res.status(500).json({ message: "Error submitting application" });
    }
  });

  // Submit contact form
  app.post(`${apiPrefix}/contact`, async (req, res) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      const submission = await storage.createContactSubmission(validatedData);
      return res.status(201).json(submission);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating contact submission:", error);
      return res.status(500).json({ message: "Error submitting contact form" });
    }
  });

  // ===== Class Management Routes =====
  
  // Get all classes
  app.get(`${apiPrefix}/classes`, async (req, res) => {
    try {
      const classes = await storage.getAllClasses();
      return res.status(200).json(classes);
    } catch (error) {
      console.error("Error fetching classes:", error);
      return res.status(500).json({ message: "Erro ao buscar turmas" });
    }
  });

  // Get class by ID
  app.get(`${apiPrefix}/classes/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de turma inválido" });
      }

      const classData = await storage.getClassById(id);
      if (!classData) {
        return res.status(404).json({ message: "Turma não encontrada" });
      }

      return res.status(200).json(classData);
    } catch (error) {
      console.error("Error fetching class:", error);
      return res.status(500).json({ message: "Erro ao buscar turma" });
    }
  });

  // Create a new class
  app.post(`${apiPrefix}/classes`, async (req, res) => {
    try {
      const validatedData = insertClassSchema.parse(req.body);
      const newClass = await storage.createClass(validatedData);
      return res.status(201).json(newClass);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating class:", error);
      return res.status(500).json({ message: "Erro ao criar turma" });
    }
  });

  // Update a class
  app.put(`${apiPrefix}/classes/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de turma inválido" });
      }

      const validatedData = insertClassSchema.partial().parse(req.body);
      const updatedClass = await storage.updateClass(id, validatedData);
      
      if (!updatedClass) {
        return res.status(404).json({ message: "Turma não encontrada" });
      }

      return res.status(200).json(updatedClass);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error updating class:", error);
      return res.status(500).json({ message: "Erro ao atualizar turma" });
    }
  });

  // Delete a class
  app.delete(`${apiPrefix}/classes/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de turma inválido" });
      }

      const deletedClass = await storage.deleteClass(id);
      
      if (!deletedClass) {
        return res.status(404).json({ message: "Turma não encontrada" });
      }

      return res.status(200).json({ message: "Turma excluída com sucesso" });
    } catch (error) {
      console.error("Error deleting class:", error);
      return res.status(500).json({ message: "Erro ao excluir turma" });
    }
  });

  // ===== Class Teachers Routes =====
  
  // Get teachers for a class
  app.get(`${apiPrefix}/classes/:id/teachers`, async (req, res) => {
    try {
      const classId = parseInt(req.params.id);
      if (isNaN(classId)) {
        return res.status(400).json({ message: "ID de turma inválido" });
      }

      const teachers = await storage.getClassTeachers(classId);
      return res.status(200).json(teachers);
    } catch (error) {
      console.error("Error fetching class teachers:", error);
      return res.status(500).json({ message: "Erro ao buscar professores da turma" });
    }
  });

  // Add teachers to a class
  app.post(`${apiPrefix}/classes/:id/teachers`, async (req, res) => {
    try {
      const classId = parseInt(req.params.id);
      if (isNaN(classId)) {
        return res.status(400).json({ message: "ID de turma inválido" });
      }

      const { teacherIds } = req.body;
      if (!Array.isArray(teacherIds) || teacherIds.length === 0) {
        return res.status(400).json({ message: "A lista de professores é obrigatória" });
      }

      const results = [];
      for (const teacherId of teacherIds) {
        if (typeof teacherId !== 'number') continue;
        
        const data = {
          classId,
          teacherId,
          isMainTeacher: false
        };
        
        const result = await storage.addTeacherToClass(data);
        results.push(result);
      }

      return res.status(201).json(results);
    } catch (error) {
      console.error("Error adding teachers to class:", error);
      return res.status(500).json({ message: "Erro ao adicionar professores à turma" });
    }
  });

  // Remove a teacher from a class
  app.delete(`${apiPrefix}/classes/:classId/teachers/:teacherId`, async (req, res) => {
    try {
      const classId = parseInt(req.params.classId);
      const teacherId = parseInt(req.params.teacherId);
      
      if (isNaN(classId) || isNaN(teacherId)) {
        return res.status(400).json({ message: "IDs inválidos" });
      }

      const result = await storage.removeTeacherFromClass(classId, teacherId);
      
      if (!result) {
        return res.status(404).json({ message: "Relacionamento não encontrado" });
      }

      return res.status(200).json({ message: "Professor removido da turma com sucesso" });
    } catch (error) {
      console.error("Error removing teacher from class:", error);
      return res.status(500).json({ message: "Erro ao remover professor da turma" });
    }
  });

  // ===== Class Students Routes =====
  
  // Get students for a class
  app.get(`${apiPrefix}/classes/:id/students`, async (req, res) => {
    try {
      const classId = parseInt(req.params.id);
      if (isNaN(classId)) {
        return res.status(400).json({ message: "ID de turma inválido" });
      }

      const students = await storage.getClassStudents(classId);
      return res.status(200).json(students);
    } catch (error) {
      console.error("Error fetching class students:", error);
      return res.status(500).json({ message: "Erro ao buscar alunos da turma" });
    }
  });

  // Add students to a class
  app.post(`${apiPrefix}/classes/:id/students`, async (req, res) => {
    try {
      const classId = parseInt(req.params.id);
      if (isNaN(classId)) {
        return res.status(400).json({ message: "ID de turma inválido" });
      }

      const { studentIds } = req.body;
      if (!Array.isArray(studentIds) || studentIds.length === 0) {
        return res.status(400).json({ message: "A lista de alunos é obrigatória" });
      }

      const results = [];
      for (const studentId of studentIds) {
        if (typeof studentId !== 'number') continue;
        
        const data = {
          classId,
          studentId,
          status: "enrolled"
        };
        
        const result = await storage.addStudentToClass(data);
        results.push(result);
      }

      return res.status(201).json(results);
    } catch (error) {
      console.error("Error adding students to class:", error);
      return res.status(500).json({ message: "Erro ao adicionar alunos à turma" });
    }
  });

  // Remove a student from a class
  app.delete(`${apiPrefix}/classes/:classId/students/:studentId`, async (req, res) => {
    try {
      const classId = parseInt(req.params.classId);
      const studentId = parseInt(req.params.studentId);
      
      if (isNaN(classId) || isNaN(studentId)) {
        return res.status(400).json({ message: "IDs inválidos" });
      }

      const result = await storage.removeStudentFromClass(classId, studentId);
      
      if (!result) {
        return res.status(404).json({ message: "Relacionamento não encontrado" });
      }

      return res.status(200).json({ message: "Aluno removido da turma com sucesso" });
    } catch (error) {
      console.error("Error removing student from class:", error);
      return res.status(500).json({ message: "Erro ao remover aluno da turma" });
    }
  });

  // Update student status in a class
  app.patch(`${apiPrefix}/classes/:classId/students/:studentId`, async (req, res) => {
    try {
      const classId = parseInt(req.params.classId);
      const studentId = parseInt(req.params.studentId);
      
      if (isNaN(classId) || isNaN(studentId)) {
        return res.status(400).json({ message: "IDs inválidos" });
      }

      const { status, finalGrade } = req.body;
      if (!status) {
        return res.status(400).json({ message: "Status é obrigatório" });
      }

      const result = await storage.updateStudentClassStatus(classId, studentId, status, finalGrade);
      
      if (!result) {
        return res.status(404).json({ message: "Relacionamento não encontrado" });
      }

      return res.status(200).json(result);
    } catch (error) {
      console.error("Error updating student status:", error);
      return res.status(500).json({ message: "Erro ao atualizar status do aluno" });
    }
  });

  // ===== Class Subjects Routes =====
  
  // Get subjects for a class
  app.get(`${apiPrefix}/classes/:id/subjects`, async (req, res) => {
    try {
      const classId = parseInt(req.params.id);
      if (isNaN(classId)) {
        return res.status(400).json({ message: "ID de turma inválido" });
      }

      const subjects = await storage.getClassSubjects(classId);
      return res.status(200).json(subjects);
    } catch (error) {
      console.error("Error fetching class subjects:", error);
      return res.status(500).json({ message: "Erro ao buscar disciplinas da turma" });
    }
  });

  // Add a subject to a class
  app.post(`${apiPrefix}/classes/:id/subjects`, async (req, res) => {
    try {
      const classId = parseInt(req.params.id);
      if (isNaN(classId)) {
        return res.status(400).json({ message: "ID de turma inválido" });
      }

      const data = insertClassSubjectSchema.parse({
        ...req.body,
        classId
      });
      
      const newSubject = await storage.addSubjectToClass(data);
      return res.status(201).json(newSubject);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error adding subject to class:", error);
      return res.status(500).json({ message: "Erro ao adicionar disciplina à turma" });
    }
  });

  // Update a subject
  app.put(`${apiPrefix}/classes/:classId/subjects/:subjectId`, async (req, res) => {
    try {
      const subjectId = parseInt(req.params.subjectId);
      if (isNaN(subjectId)) {
        return res.status(400).json({ message: "ID de disciplina inválido" });
      }

      const data = insertClassSubjectSchema.partial().parse(req.body);
      delete data.classId; // Não permitir alteração da turma
      
      const updatedSubject = await storage.updateClassSubject(subjectId, data);
      
      if (!updatedSubject) {
        return res.status(404).json({ message: "Disciplina não encontrada" });
      }

      return res.status(200).json(updatedSubject);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error updating subject:", error);
      return res.status(500).json({ message: "Erro ao atualizar disciplina" });
    }
  });

  // Remove a subject from a class
  app.delete(`${apiPrefix}/classes/:classId/subjects/:subjectId`, async (req, res) => {
    try {
      const subjectId = parseInt(req.params.subjectId);
      if (isNaN(subjectId)) {
        return res.status(400).json({ message: "ID de disciplina inválido" });
      }

      const result = await storage.removeSubjectFromClass(subjectId);
      
      if (!result) {
        return res.status(404).json({ message: "Disciplina não encontrada" });
      }

      return res.status(200).json({ message: "Disciplina removida com sucesso" });
    } catch (error) {
      console.error("Error removing subject:", error);
      return res.status(500).json({ message: "Erro ao remover disciplina" });
    }
  });

  // ===== Education Levels (Níveis de Ensino) Routes =====
  
  // Get all education levels
  app.get(`${apiPrefix}/education-levels`, async (req, res) => {
    try {
      const levels = await storage.getAllEducationLevels();
      return res.status(200).json(levels);
    } catch (error) {
      console.error("Error fetching education levels:", error);
      return res.status(500).json({ message: "Erro ao buscar níveis de ensino" });
    }
  });
  
  // Get education level by ID
  app.get(`${apiPrefix}/education-levels/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de nível de ensino inválido" });
      }
      
      const level = await storage.getEducationLevelById(id);
      if (!level) {
        return res.status(404).json({ message: "Nível de ensino não encontrado" });
      }
      
      return res.status(200).json(level);
    } catch (error) {
      console.error("Error fetching education level:", error);
      return res.status(500).json({ message: "Erro ao buscar nível de ensino" });
    }
  });
  
  // Create a new education level
  app.post(`${apiPrefix}/education-levels`, async (req, res) => {
    try {
      const validatedData = insertEducationLevelSchema.parse(req.body);
      const newLevel = await storage.createEducationLevel(validatedData);
      return res.status(201).json(newLevel);
    } catch (error) {
      console.error("Error creating education level:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Erro ao criar nível de ensino" });
    }
  });
  
  // Update an education level
  app.put(`${apiPrefix}/education-levels/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de nível de ensino inválido" });
      }
      
      const validatedData = insertEducationLevelSchema.partial().parse(req.body);
      const updatedLevel = await storage.updateEducationLevel(id, validatedData);
      if (!updatedLevel) {
        return res.status(404).json({ message: "Nível de ensino não encontrado" });
      }
      
      return res.status(200).json(updatedLevel);
    } catch (error) {
      console.error("Error updating education level:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Erro ao atualizar nível de ensino" });
    }
  });
  
  // Delete an education level
  app.delete(`${apiPrefix}/education-levels/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de nível de ensino inválido" });
      }
      
      const deletedLevel = await storage.deleteEducationLevel(id);
      return res.status(200).json(deletedLevel);
    } catch (error) {
      console.error("Error deleting education level:", error);
      if (error.message && error.message.includes("não pode ser excluído")) {
        return res.status(400).json({ message: error.message });
      }
      return res.status(500).json({ message: "Erro ao excluir nível de ensino" });
    }
  });
  
  // Get classes by education level
  app.get(`${apiPrefix}/education-levels/:id/classes`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de nível de ensino inválido" });
      }
      
      const classes = await storage.getClassesByEducationLevel(id);
      return res.status(200).json(classes);
    } catch (error) {
      console.error("Error fetching classes by education level:", error);
      return res.status(500).json({ message: "Erro ao buscar turmas por nível de ensino" });
    }
  });
  
  // ===== Teachers and Students Routes =====
  
  // Get all teachers
  app.get(`${apiPrefix}/teachers`, async (req, res) => {
    try {
      const teachers = await storage.getAllTeachers();
      return res.status(200).json(teachers);
    } catch (error) {
      console.error("Error fetching teachers:", error);
      return res.status(500).json({ message: "Erro ao buscar professores" });
    }
  });

  // Get all students
  app.get(`${apiPrefix}/students`, async (req, res) => {
    try {
      const students = await storage.getAllStudents();
      return res.status(200).json(students);
    } catch (error) {
      console.error("Error fetching students:", error);
      return res.status(500).json({ message: "Erro ao buscar alunos" });
    }
  });
  
  // Courses routes
  // Get all courses
  app.get(`${apiPrefix}/courses`, async (req, res) => {
    try {
      const courses = await storage.getAllCourses();
      return res.status(200).json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      return res.status(500).json({ message: "Erro ao buscar cursos" });
    }
  });

  // Get course by ID
  app.get(`${apiPrefix}/courses/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de curso inválido" });
      }
      
      const course = await storage.getCourseById(id);
      if (!course) {
        return res.status(404).json({ message: "Curso não encontrado" });
      }
      
      return res.status(200).json(course);
    } catch (error) {
      console.error("Error fetching course:", error);
      return res.status(500).json({ message: "Erro ao buscar curso" });
    }
  });

  // Get courses by education level
  app.get(`${apiPrefix}/education-levels/:id/courses`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de nível de ensino inválido" });
      }
      
      const courses = await storage.getCoursesByEducationLevel(id);
      return res.status(200).json(courses);
    } catch (error) {
      console.error("Error fetching courses by education level:", error);
      return res.status(500).json({ message: "Erro ao buscar cursos por nível de ensino" });
    }
  });

  // Create course
  app.post(`${apiPrefix}/courses`, async (req, res) => {
    try {
      const validatedData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(validatedData);
      
      return res.status(201).json(course);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating course:", error);
      return res.status(500).json({ message: "Erro ao criar curso" });
    }
  });

  // Update course
  app.patch(`${apiPrefix}/courses/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de curso inválido" });
      }
      
      const course = await storage.getCourseById(id);
      if (!course) {
        return res.status(404).json({ message: "Curso não encontrado" });
      }
      
      const validatedData = insertCourseSchema.partial().parse(req.body);
      const updatedCourse = await storage.updateCourse(id, validatedData);
      
      return res.status(200).json(updatedCourse);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error updating course:", error);
      return res.status(500).json({ message: "Erro ao atualizar curso" });
    }
  });

  // Delete course
  app.delete(`${apiPrefix}/courses/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de curso inválido" });
      }
      
      const course = await storage.getCourseById(id);
      if (!course) {
        return res.status(404).json({ message: "Curso não encontrado" });
      }
      
      try {
        const deletedCourse = await storage.deleteCourse(id);
        return res.status(200).json(deletedCourse);
      } catch (deleteError) {
        if (deleteError instanceof Error) {
          return res.status(400).json({ message: deleteError.message });
        }
        throw deleteError;
      }
    } catch (error) {
      console.error("Error deleting course:", error);
      return res.status(500).json({ message: "Erro ao excluir curso" });
    }
  });

  // Subjects routes
  // Get all subjects
  app.get(`${apiPrefix}/subjects`, async (req, res) => {
    try {
      const subjects = await storage.getAllSubjects();
      return res.status(200).json(subjects);
    } catch (error) {
      console.error("Error fetching subjects:", error);
      return res.status(500).json({ message: "Erro ao buscar disciplinas" });
    }
  });

  // Get subject by ID
  app.get(`${apiPrefix}/subjects/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de disciplina inválido" });
      }
      
      const subject = await storage.getSubjectById(id);
      if (!subject) {
        return res.status(404).json({ message: "Disciplina não encontrada" });
      }
      
      return res.status(200).json(subject);
    } catch (error) {
      console.error("Error fetching subject:", error);
      return res.status(500).json({ message: "Erro ao buscar disciplina" });
    }
  });

  // Get subjects by course
  app.get(`${apiPrefix}/courses/:id/subjects`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de curso inválido" });
      }
      
      const subjects = await storage.getSubjectsByCourse(id);
      return res.status(200).json(subjects);
    } catch (error) {
      console.error("Error fetching subjects by course:", error);
      return res.status(500).json({ message: "Erro ao buscar disciplinas por curso" });
    }
  });

  // Create subject
  app.post(`${apiPrefix}/subjects`, async (req, res) => {
    try {
      const validatedData = insertSubjectSchema.parse(req.body);
      const subject = await storage.createSubject(validatedData);
      
      return res.status(201).json(subject);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating subject:", error);
      return res.status(500).json({ message: "Erro ao criar disciplina" });
    }
  });

  // Update subject
  app.patch(`${apiPrefix}/subjects/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de disciplina inválido" });
      }
      
      const subject = await storage.getSubjectById(id);
      if (!subject) {
        return res.status(404).json({ message: "Disciplina não encontrada" });
      }
      
      const validatedData = insertSubjectSchema.partial().parse(req.body);
      const updatedSubject = await storage.updateSubject(id, validatedData);
      
      return res.status(200).json(updatedSubject);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error updating subject:", error);
      return res.status(500).json({ message: "Erro ao atualizar disciplina" });
    }
  });

  // Delete subject
  app.delete(`${apiPrefix}/subjects/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de disciplina inválido" });
      }
      
      const subject = await storage.getSubjectById(id);
      if (!subject) {
        return res.status(404).json({ message: "Disciplina não encontrada" });
      }
      
      try {
        const deletedSubject = await storage.deleteSubject(id);
        return res.status(200).json(deletedSubject);
      } catch (deleteError) {
        if (deleteError instanceof Error) {
          return res.status(400).json({ message: deleteError.message });
        }
        throw deleteError;
      }
    } catch (error) {
      console.error("Error deleting subject:", error);
      return res.status(500).json({ message: "Erro ao excluir disciplina" });
    }
  });

  const httpServer = createServer(app);
  
  return httpServer;
}
