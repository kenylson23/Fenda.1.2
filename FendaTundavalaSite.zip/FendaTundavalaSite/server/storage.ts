import { db } from "@db";
import { and, desc, eq, like, or } from "drizzle-orm";
import {
  universities,
  resources,
  testimonials,
  exchangePrograms,
  exchangeApplications,
  contactSubmissions,
  users,
  students,
  teachers,
  classes,
  classTeachers,
  classStudents,
  classSubjects,
  educationLevels,
  courses,
  subjects,
  type InsertExchangeApplication,
  type InsertContactSubmission,
  type InsertUser,
  type InsertStudent,
  type InsertTeacher,
  type InsertClass,
  type InsertClassTeacher,
  type InsertClassStudent,
  type InsertClassSubject,
  type InsertEducationLevel,
  type InsertCourse,
  type InsertSubject
} from "@shared/schema";

interface ResourceFilterOptions {
  search: string;
  type: string;
  category: string;
  language: string;
  page: number;
  limit: number;
}

export const storage = {
  // Courses methods
  async getAllCourses() {
    return await db.query.courses.findMany({
      orderBy: [courses.name],
      with: {
        educationLevel: true
      }
    });
  },

  async getCourseById(id: number) {
    return await db.query.courses.findFirst({
      where: eq(courses.id, id),
      with: {
        educationLevel: true
      }
    });
  },

  async getCoursesByEducationLevel(educationLevelId: number) {
    return await db.query.courses.findMany({
      where: eq(courses.educationLevelId, educationLevelId),
      orderBy: [courses.name]
    });
  },

  async createCourse(data: InsertCourse) {
    const [course] = await db.insert(courses).values(data).returning();
    return course;
  },

  async updateCourse(id: number, data: Partial<InsertCourse>) {
    const [updated] = await db
      .update(courses)
      .set(data)
      .where(eq(courses.id, id))
      .returning();
    
    return updated;
  },

  async deleteCourse(id: number) {
    // Verificar se existem disciplinas relacionadas
    const subjectsCount = await db.query.subjects.findMany({
      where: eq(subjects.courseId, id)
    });
    
    if (subjectsCount.length > 0) {
      throw new Error("Não é possível excluir um curso que possui disciplinas associadas.");
    }

    // Verificar se existem turmas relacionadas
    const classesCount = await db.query.classes.findMany({
      where: eq(classes.courseId, id)
    });
    
    if (classesCount.length > 0) {
      throw new Error("Não é possível excluir um curso que possui turmas associadas.");
    }
    
    const [deleted] = await db
      .delete(courses)
      .where(eq(courses.id, id))
      .returning();
    
    return deleted;
  },

  // Subjects methods
  async getAllSubjects() {
    return await db.query.subjects.findMany({
      orderBy: [subjects.name],
      with: {
        course: true
      }
    });
  },

  async getSubjectById(id: number) {
    return await db.query.subjects.findFirst({
      where: eq(subjects.id, id),
      with: {
        course: true
      }
    });
  },

  async getSubjectsByCourse(courseId: number) {
    return await db.query.subjects.findMany({
      where: eq(subjects.courseId, courseId),
      orderBy: [subjects.name]
    });
  },

  async createSubject(data: InsertSubject) {
    const [subject] = await db.insert(subjects).values(data).returning();
    return subject;
  },

  async updateSubject(id: number, data: Partial<InsertSubject>) {
    const [updated] = await db
      .update(subjects)
      .set(data)
      .where(eq(subjects.id, id))
      .returning();
    
    return updated;
  },

  async deleteSubject(id: number) {
    // Verificar se a disciplina está associada a alguma turma
    const classSubjectsCount = await db.query.classSubjects.findMany({
      where: eq(classSubjects.subjectId, id)
    });
    
    if (classSubjectsCount.length > 0) {
      throw new Error("Não é possível excluir uma disciplina que está associada a turmas.");
    }
    
    const [deleted] = await db
      .delete(subjects)
      .where(eq(subjects.id, id))
      .returning();
    
    return deleted;
  },
  
  // Class (Turma) methods
  async getAllClasses() {
    return await db.query.classes.findMany({
      orderBy: [desc(classes.year), classes.name]
    });
  },

  async getClassById(id: number) {
    return await db.query.classes.findFirst({
      where: eq(classes.id, id)
    });
  },

  async createClass(data: InsertClass) {
    const [newClass] = await db.insert(classes).values(data).returning();
    return newClass;
  },

  async updateClass(id: number, data: Partial<InsertClass>) {
    const [updatedClass] = await db.update(classes)
      .set(data)
      .where(eq(classes.id, id))
      .returning();
    return updatedClass;
  },

  async deleteClass(id: number) {
    // First delete all relationships
    await db.delete(classTeachers).where(eq(classTeachers.classId, id));
    await db.delete(classStudents).where(eq(classStudents.classId, id));
    await db.delete(classSubjects).where(eq(classSubjects.classId, id));
    
    // Then delete the class
    const [deletedClass] = await db.delete(classes)
      .where(eq(classes.id, id))
      .returning();
    return deletedClass;
  },

  // Class Teachers methods
  async getClassTeachers(classId: number) {
    const classTeachersData = await db.query.classTeachers.findMany({
      where: eq(classTeachers.classId, classId),
      with: {
        teacher: {
          with: {
            user: true
          }
        }
      }
    });

    // Flatten the data structure for easier consumption by the frontend
    return classTeachersData.map(ct => ({
      ...ct.teacher,
      user: ct.teacher.user
    }));
  },

  async addTeacherToClass(data: InsertClassTeacher) {
    // Check if the teacher is already in the class
    const existingTeacher = await db.query.classTeachers.findFirst({
      where: and(
        eq(classTeachers.classId, data.classId),
        eq(classTeachers.teacherId, data.teacherId)
      )
    });

    if (existingTeacher) {
      return existingTeacher;
    }

    const [newClassTeacher] = await db.insert(classTeachers).values(data).returning();
    return newClassTeacher;
  },

  async removeTeacherFromClass(classId: number, teacherId: number) {
    const [removedTeacher] = await db.delete(classTeachers)
      .where(
        and(
          eq(classTeachers.classId, classId),
          eq(classTeachers.teacherId, teacherId)
        )
      )
      .returning();
    return removedTeacher;
  },

  // Class Students methods
  async getClassStudents(classId: number) {
    const classStudentsData = await db.query.classStudents.findMany({
      where: eq(classStudents.classId, classId),
      with: {
        student: {
          with: {
            user: true
          }
        }
      }
    });

    // Flatten the data structure for easier consumption by the frontend
    return classStudentsData.map(cs => ({
      ...cs.student,
      user: cs.student.user,
      enrollmentStatus: cs.status,
      finalGrade: cs.finalGrade
    }));
  },

  async addStudentToClass(data: InsertClassStudent) {
    // Check if the student is already in the class
    const existingStudent = await db.query.classStudents.findFirst({
      where: and(
        eq(classStudents.classId, data.classId),
        eq(classStudents.studentId, data.studentId)
      )
    });

    if (existingStudent) {
      return existingStudent;
    }

    const [newClassStudent] = await db.insert(classStudents).values(data).returning();
    return newClassStudent;
  },

  async removeStudentFromClass(classId: number, studentId: number) {
    const [removedStudent] = await db.delete(classStudents)
      .where(
        and(
          eq(classStudents.classId, classId),
          eq(classStudents.studentId, studentId)
        )
      )
      .returning();
    return removedStudent;
  },

  async updateStudentClassStatus(classId: number, studentId: number, status: string, finalGrade?: number) {
    const updateData: any = { status };
    if (finalGrade !== undefined) {
      updateData.finalGrade = finalGrade.toString(); // Converter para string para compatibilidade
    }
    
    const [updatedStudent] = await db.update(classStudents)
      .set(updateData)
      .where(
        and(
          eq(classStudents.classId, classId),
          eq(classStudents.studentId, studentId)
        )
      )
      .returning();
    return updatedStudent;
  },

  // Class Subjects methods
  async getClassSubjects(classId: number) {
    return await db.query.classSubjects.findMany({
      where: eq(classSubjects.classId, classId),
      orderBy: [classSubjects.name]
    });
  },

  async addSubjectToClass(data: InsertClassSubject) {
    const [newSubject] = await db.insert(classSubjects).values(data).returning();
    return newSubject;
  },

  async updateClassSubject(id: number, data: Partial<InsertClassSubject>) {
    const [updatedSubject] = await db.update(classSubjects)
      .set(data)
      .where(eq(classSubjects.id, id))
      .returning();
    return updatedSubject;
  },

  async removeSubjectFromClass(id: number) {
    const [removedSubject] = await db.delete(classSubjects)
      .where(eq(classSubjects.id, id))
      .returning();
    return removedSubject;
  },

  // Education Levels (Níveis de Ensino) methods
  async getAllEducationLevels() {
    return await db.query.educationLevels.findMany({
      orderBy: [educationLevels.levelOrder]
    });
  },

  async getEducationLevelById(id: number) {
    return await db.query.educationLevels.findFirst({
      where: eq(educationLevels.id, id)
    });
  },

  async createEducationLevel(data: InsertEducationLevel) {
    const [newLevel] = await db.insert(educationLevels).values(data).returning();
    return newLevel;
  },

  async updateEducationLevel(id: number, data: Partial<InsertEducationLevel>) {
    const [updatedLevel] = await db.update(educationLevels)
      .set(data)
      .where(eq(educationLevels.id, id))
      .returning();
    return updatedLevel;
  },

  async deleteEducationLevel(id: number) {
    // Check if the level is being used by any class
    const relatedClasses = await db.query.classes.findMany({
      where: eq(classes.educationLevelId, id)
    });

    if (relatedClasses.length > 0) {
      throw new Error("Este nível de ensino está sendo usado por turmas e não pode ser excluído.");
    }

    const [deletedLevel] = await db.delete(educationLevels)
      .where(eq(educationLevels.id, id))
      .returning();
    return deletedLevel;
  },

  // Returns classes by education level
  async getClassesByEducationLevel(educationLevelId: number) {
    return await db.query.classes.findMany({
      where: eq(classes.educationLevelId, educationLevelId),
      orderBy: [desc(classes.year), classes.name]
    });
  },

  // University methods
  // University methods
  async getAllUniversities() {
    return await db.query.universities.findMany({
      orderBy: [universities.name]
    });
  },

  // Resource methods
  async getFeaturedResources() {
    return await db.query.resources.findMany({
      where: eq(resources.featured, true),
      limit: 4
    });
  },

  async getResources(options: ResourceFilterOptions) {
    const { search, type, category, language, page, limit } = options;
    
    let query = db.select().from(resources);
    
    // Apply filters
    const filters = [];
    
    // Search filter
    if (search) {
      filters.push(
        or(
          like(resources.title, `%${search}%`),
          like(resources.author, `%${search}%`),
          like(resources.description, `%${search}%`)
        )
      );
    }
    
    // Type filter
    if (type && type !== "Todos os tipos") {
      filters.push(eq(resources.type, type));
    }
    
    // Category filter
    if (category && category !== "Todas as categorias") {
      filters.push(eq(resources.category, category));
    }
    
    // Language filter
    if (language && language !== "Todos os idiomas") {
      filters.push(eq(resources.language, language));
    }
    
    // Apply all filters if any
    if (filters.length > 0) {
      query = query.where(and(...filters));
    }
    
    // Apply pagination
    query = query
      .limit(limit)
      .offset((page - 1) * limit)
      .orderBy(desc(resources.createdAt));
    
    return await query;
  },

  async getResourceById(id: number) {
    return await db.query.resources.findFirst({
      where: eq(resources.id, id)
    });
  },

  // Testimonial methods
  async getAllTestimonials() {
    return await db.query.testimonials.findMany();
  },

  // Exchange Program methods
  async getAllExchangePrograms() {
    return await db.query.exchangePrograms.findMany({
      orderBy: [exchangePrograms.applicationDeadline]
    });
  },

  async getExchangeProgramById(id: number) {
    return await db.query.exchangePrograms.findFirst({
      where: eq(exchangePrograms.id, id)
    });
  },

  // Exchange Application methods
  async createExchangeApplication(data: InsertExchangeApplication) {
    const [application] = await db
      .insert(exchangeApplications)
      .values(data)
      .returning();
    
    return application;
  },

  // Contact submission methods
  async createContactSubmission(data: InsertContactSubmission) {
    const [submission] = await db
      .insert(contactSubmissions)
      .values(data)
      .returning();
    
    return submission;
  },

  // User methods
  async getUserByUsername(username: string) {
    return await db.query.users.findFirst({
      where: eq(users.username, username)
    });
  },

  async createUser(data: InsertUser) {
    const [user] = await db
      .insert(users)
      .values(data)
      .returning();
    
    return user;
  },

  async getAllUsers() {
    return await db.query.users.findMany({
      orderBy: [users.createdAt]
    });
  },
  
  async getUserById(id: number) {
    return await db.query.users.findFirst({
      where: eq(users.id, id)
    });
  },
  
  async updateUser(id: number, data: Partial<InsertUser>) {
    const [updatedUser] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
      
    return updatedUser;
  },
  
  async deleteUser(id: number) {
    const [deletedUser] = await db
      .delete(users)
      .where(eq(users.id, id))
      .returning();
      
    return deletedUser;
  },
  
  // Student methods
  async createStudent(userData: InsertUser, studentData: Omit<InsertStudent, "userId">) {
    // Create user first
    userData.userType = "student";
    const user = await this.createUser(userData);
    
    // Create student with the user ID
    const [student] = await db
      .insert(students)
      .values({
        ...studentData,
        userId: user.id
      })
      .returning();
      
    return { user, student };
  },
  
  async getAllStudents() {
    return await db.query.students.findMany({
      with: {
        user: true
      },
      orderBy: [students.createdAt]
    });
  },
  
  async getStudentById(id: number) {
    return await db.query.students.findFirst({
      where: eq(students.id, id),
      with: {
        user: true
      }
    });
  },
  
  async updateStudent(
    studentId: number, 
    studentData: Partial<Omit<InsertStudent, "userId">>,
    userData?: Partial<InsertUser>
  ) {
    let updatedUser;
    const student = await this.getStudentById(studentId);
    
    if (!student) {
      throw new Error("Student not found");
    }
    
    // Update user data if provided
    if (userData && Object.keys(userData).length > 0) {
      updatedUser = await this.updateUser(student.userId, userData);
    }
    
    // Update student data
    if (Object.keys(studentData).length > 0) {
      const [updatedStudent] = await db
        .update(students)
        .set(studentData)
        .where(eq(students.id, studentId))
        .returning();
        
      return { 
        user: updatedUser || student.user, 
        student: updatedStudent 
      };
    }
    
    return { 
      user: updatedUser || student.user, 
      student: student 
    };
  },
  
  async deleteStudent(id: number) {
    const student = await this.getStudentById(id);
    
    if (!student) {
      throw new Error("Student not found");
    }
    
    // Delete student
    const [deletedStudent] = await db
      .delete(students)
      .where(eq(students.id, id))
      .returning();
      
    // Delete associated user
    const deletedUser = await this.deleteUser(student.userId);
    
    return { user: deletedUser, student: deletedStudent };
  },
  
  // Teacher methods
  async createTeacher(userData: InsertUser, teacherData: Omit<InsertTeacher, "userId">) {
    // Create user first
    userData.userType = "teacher";
    const user = await this.createUser(userData);
    
    // Create teacher with the user ID
    const [teacher] = await db
      .insert(teachers)
      .values({
        ...teacherData,
        userId: user.id
      })
      .returning();
      
    return { user, teacher };
  },
  
  async getAllTeachers() {
    return await db.query.teachers.findMany({
      with: {
        user: true
      },
      orderBy: [teachers.createdAt]
    });
  },
  
  async getTeacherById(id: number) {
    return await db.query.teachers.findFirst({
      where: eq(teachers.id, id),
      with: {
        user: true
      }
    });
  },
  
  async updateTeacher(
    teacherId: number, 
    teacherData: Partial<Omit<InsertTeacher, "userId">>,
    userData?: Partial<InsertUser>
  ) {
    let updatedUser;
    const teacher = await this.getTeacherById(teacherId);
    
    if (!teacher) {
      throw new Error("Teacher not found");
    }
    
    // Update user data if provided
    if (userData && Object.keys(userData).length > 0) {
      updatedUser = await this.updateUser(teacher.userId, userData);
    }
    
    // Update teacher data
    if (Object.keys(teacherData).length > 0) {
      const [updatedTeacher] = await db
        .update(teachers)
        .set(teacherData)
        .where(eq(teachers.id, teacherId))
        .returning();
        
      return { 
        user: updatedUser || teacher.user, 
        teacher: updatedTeacher 
      };
    }
    
    return { 
      user: updatedUser || teacher.user, 
      teacher: teacher 
    };
  },
  
  async deleteTeacher(id: number) {
    const teacher = await this.getTeacherById(id);
    
    if (!teacher) {
      throw new Error("Teacher not found");
    }
    
    // Delete teacher
    const [deletedTeacher] = await db
      .delete(teachers)
      .where(eq(teachers.id, id))
      .returning();
      
    // Delete associated user
    const deletedUser = await this.deleteUser(teacher.userId);
    
    return { user: deletedUser, teacher: deletedTeacher };
  }
};
